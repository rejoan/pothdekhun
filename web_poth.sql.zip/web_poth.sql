--
-- Database: `web_poth`
--

-- --------------------------------------------------------

--
-- Table structure for table `edited_routes`
--

CREATE TABLE `edited_routes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `route_id` bigint(20) UNSIGNED NOT NULL,
  `country` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `from_place` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `to_place` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `vehicle_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `departure_place` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `departure_time` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `rent` int(11) NOT NULL,
  `evidence` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `edited_by` bigint(20) UNSIGNED NOT NULL,
  `submitted_at` datetime NOT NULL,
  `language_e` enum('bn','en') COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `edited_stoppages`
--

CREATE TABLE `edited_stoppages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `place_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `comments` text COLLATE utf8_unicode_ci NOT NULL,
  `rent` int(11) NOT NULL,
  `route_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `id` bigint(20) NOT NULL,
  `first_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `occupation` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `sex` enum('Male','Female','Other') COLLATE utf8_unicode_ci NOT NULL,
  `birth_date` datetime NOT NULL,
  `about` text COLLATE utf8_unicode_ci NOT NULL,
  `thana` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `district` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `routes`
--

CREATE TABLE `routes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `country` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `from_place` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `to_place` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `vehicle_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `departure_place` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `departure_time` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `rent` int(11) NOT NULL,
  `evidence` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `added` datetime NOT NULL,
  `added_by` bigint(20) UNSIGNED NOT NULL,
  `is_publish` int(11) NOT NULL DEFAULT '0' COMMENT '0=not published,1=published'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `routes`
--

INSERT INTO `routes` (`id`, `country`, `from_place`, `to_place`, `type`, `vehicle_name`, `departure_place`, `departure_time`, `rent`, `evidence`, `added`, `added_by`, `is_publish`) VALUES
(1, 'Bangladesh', 'মোহাম্মদপুর, ঢাকা', 'নতুন বাজার, বাড্ডা', 'বাস', 'তেতুলিয়া পরিবহন', 'তাজমহল রোড', 'কিছুক্ষর পরপর', 35, '', '2015-12-07 18:36:21', 2, 0),
(2, 'Bangladesh', 'মোহাম্মদপুর', 'কাকলী', 'বাস', 'ভূইয়া পরিবহন', 'জাপান গার্ডেন, মোহাম্মদপুর', 'কিছুক্ষর পরপর', 25, '', '2015-12-08 09:33:55', 2, 0),
(3, 'Bangladesh', 'রংপুর', 'ঢাকা', 'বাস', 'TR পরিবহন', 'কামারপাড়া', 'সকালে ৩টা এবং রাতে ৫ টা', 550, '', '2015-12-11 11:19:04', 2, 0),
(4, 'Bangladesh', 'মোহাম্মাদপুর, ঢাকা', 'মতিঝিল, ঢাকা', 'বাস', 'দীপন সিএনজি', 'কবরস্থান', 'কিছুক্ষর পরপর', 30, '', '2015-12-22 08:47:14', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `route_translation`
--

CREATE TABLE `route_translation` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `route_id` bigint(20) UNSIGNED NOT NULL,
  `from_place` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `to_place` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `vehicle_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `departure_place` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `departure_time` varchar(150) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stoppages`
--

CREATE TABLE `stoppages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `place_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `comments` text COLLATE utf8_unicode_ci NOT NULL,
  `rent` int(11) NOT NULL,
  `route_id` bigint(20) UNSIGNED NOT NULL,
  `position` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `stoppages`
--

INSERT INTO `stoppages` (`id`, `place_name`, `comments`, `rent`, `route_id`, `position`) VALUES
(1, 'ফার্মগেট', '', 25, 1, 1),
(2, 'কাওরান বাজার', '', 30, 1, 2),
(29, 'চান্দুরা', 'একই ভাড়া নিবে', 550, 3, 1),
(30, 'সাভার', 'একই ভাড়া নিবে', 550, 3, 2),
(31, 'টেকনিকাল', 'একই ভাড়া নিবে', 550, 3, 3),
(32, 'মহাখালি', '', 20, 2, 1),
(33, 'চেয়ারমেন বাড়ি', '', 20, 2, 2),
(34, 'আমতলী', 'একই ভাড়া', 25, 2, 3),
(35, 'ফার্মগেট', '', 20, 4, 1),
(36, 'শাহবাগ', '', 15, 4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `stoppage_translation`
--

CREATE TABLE `stoppage_translation` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `route_id` bigint(20) UNSIGNED NOT NULL,
  `place_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `comment` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `mobile` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` datetime NOT NULL,
  `last_logged` datetime NOT NULL,
  `type` int(11) NOT NULL DEFAULT '1' COMMENT '1=user, 2= supervisor, 3 = admin',
  `reputation` int(11) NOT NULL,
  `avatar` varchar(150) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `mobile`, `reg_date`, `last_logged`, `type`, `reputation`, `avatar`) VALUES
(1, 'রেজওয়ান', '81dc9bdb52d04dc20036dbd8313ed055', 'rejoan.er@gmail.com', '', '2015-12-03 10:07:24', '0000-00-00 00:00:00', 3, 0, ''),
(2, 'rejoan', '81dc9bdb52d04dc20036dbd8313ed055', 'rejoan.epr@gmail.com', '01961349181', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `verifications`
--

CREATE TABLE `verifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `route_id` bigint(20) UNSIGNED NOT NULL,
  `verified_by` bigint(20) UNSIGNED NOT NULL,
  `verified_at` datetime NOT NULL,
  `comments` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `edited_routes`
--
ALTER TABLE `edited_routes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_edited_routes_routes` (`route_id`),
  ADD KEY `FK_edited_routes_users` (`edited_by`);

--
-- Indexes for table `edited_stoppages`
--
ALTER TABLE `edited_stoppages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK__routes` (`route_id`);

--
-- Indexes for table `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_profiles_users` (`user_id`);

--
-- Indexes for table `routes`
--
ALTER TABLE `routes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_routes_users` (`added_by`),
  ADD KEY `from` (`from_place`),
  ADD KEY `to` (`to_place`);

--
-- Indexes for table `route_translation`
--
ALTER TABLE `route_translation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_route_translation_routes` (`route_id`);

--
-- Indexes for table `stoppages`
--
ALTER TABLE `stoppages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_stopages_routes` (`route_id`);

--
-- Indexes for table `stoppage_translation`
--
ALTER TABLE `stoppage_translation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK__stoppages` (`route_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `type` (`type`);

--
-- Indexes for table `verifications`
--
ALTER TABLE `verifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_verifications_routes` (`route_id`),
  ADD KEY `FK_verifications_users` (`verified_by`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `edited_routes`
--
ALTER TABLE `edited_routes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `edited_stoppages`
--
ALTER TABLE `edited_stoppages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `routes`
--
ALTER TABLE `routes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `route_translation`
--
ALTER TABLE `route_translation`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `stoppages`
--
ALTER TABLE `stoppages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT for table `stoppage_translation`
--
ALTER TABLE `stoppage_translation`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `verifications`
--
ALTER TABLE `verifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `edited_routes`
--
ALTER TABLE `edited_routes`
  ADD CONSTRAINT `FK_edited_routes_routes` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_edited_routes_users` FOREIGN KEY (`edited_by`) REFERENCES `users` (`id`) ON UPDATE NO ACTION;

--
-- Constraints for table `edited_stoppages`
--
ALTER TABLE `edited_stoppages`
  ADD CONSTRAINT `FK__routes` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON UPDATE NO ACTION;

--
-- Constraints for table `profiles`
--
ALTER TABLE `profiles`
  ADD CONSTRAINT `FK_profiles_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE NO ACTION;

--
-- Constraints for table `routes`
--
ALTER TABLE `routes`
  ADD CONSTRAINT `FK_routes_users` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON UPDATE NO ACTION;

--
-- Constraints for table `route_translation`
--
ALTER TABLE `route_translation`
  ADD CONSTRAINT `FK_route_translation_routes` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `stoppages`
--
ALTER TABLE `stoppages`
  ADD CONSTRAINT `FK_stoppages_routes` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON UPDATE NO ACTION;

--
-- Constraints for table `stoppage_translation`
--
ALTER TABLE `stoppage_translation`
  ADD CONSTRAINT `FK__stoppages` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON UPDATE NO ACTION;

--
-- Constraints for table `verifications`
--
ALTER TABLE `verifications`
  ADD CONSTRAINT `FK_verifications_routes` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_verifications_users` FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`) ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
