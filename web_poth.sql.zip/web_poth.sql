--
-- Database: `web_poth`
--

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `id` bigint(20) NOT NULL,
  `first_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `sex` enum('Male','Female','Other') COLLATE utf8_unicode_ci NOT NULL,
  `birth_date` datetime NOT NULL,
  `about` text COLLATE utf8_unicode_ci NOT NULL,
  `thana` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `district` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `routes`
--

CREATE TABLE `routes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `from_place` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `to_place` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `vehicle_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `departure_place` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `departure_time` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `rent` int(11) NOT NULL,
  `evidence` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `is_verified` int(11) NOT NULL DEFAULT '0' COMMENT '0=not varified, 1=verified',
  `added` datetime NOT NULL,
  `added_by` bigint(20) UNSIGNED NOT NULL,
  `is_publish` int(11) NOT NULL DEFAULT '0' COMMENT '0=not published,1=published'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `route_translation`
--

CREATE TABLE `route_translation` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `route_id` bigint(20) UNSIGNED NOT NULL,
  `from_eng` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `to_eng` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `vehicle_name_eng` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `departure_pl_eng` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `departure_time_eng` varchar(150) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stoppages`
--

CREATE TABLE `stoppages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `place_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `comments` text COLLATE utf8_unicode_ci NOT NULL,
  `rent` int(11) NOT NULL,
  `route_id` bigint(20) UNSIGNED NOT NULL,
  `position` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stoppage_translation`
--

CREATE TABLE `stoppage_translation` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `stoppage_id` bigint(20) UNSIGNED NOT NULL,
  `place_name_eng` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `comment_eng` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `mobile` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` datetime NOT NULL,
  `last_logged` datetime NOT NULL,
  `type` int(11) NOT NULL DEFAULT '2' COMMENT '1=admin, 2= user',
  `reputaion` int(11) NOT NULL,
  `avatar` varchar(150) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_profiles_users` (`user_id`);

--
-- Indexes for table `routes`
--
ALTER TABLE `routes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `is_verified` (`is_verified`),
  ADD KEY `FK_routes_users` (`added_by`),
  ADD KEY `from` (`from_place`),
  ADD KEY `to` (`to_place`);

--
-- Indexes for table `route_translation`
--
ALTER TABLE `route_translation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_route_translation_routes` (`route_id`);

--
-- Indexes for table `stoppages`
--
ALTER TABLE `stoppages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_stopages_routes` (`route_id`);

--
-- Indexes for table `stoppage_translation`
--
ALTER TABLE `stoppage_translation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK__stoppages` (`stoppage_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `type` (`type`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `routes`
--
ALTER TABLE `routes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `route_translation`
--
ALTER TABLE `route_translation`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `stoppages`
--
ALTER TABLE `stoppages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `stoppage_translation`
--
ALTER TABLE `stoppage_translation`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `profiles`
--
ALTER TABLE `profiles`
  ADD CONSTRAINT `FK_profiles_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE NO ACTION;

--
-- Constraints for table `routes`
--
ALTER TABLE `routes`
  ADD CONSTRAINT `FK_routes_users` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON UPDATE NO ACTION;

--
-- Constraints for table `route_translation`
--
ALTER TABLE `route_translation`
  ADD CONSTRAINT `FK_route_translation_routes` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `stoppages`
--
ALTER TABLE `stoppages`
  ADD CONSTRAINT `FK_stoppages_routes` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON UPDATE NO ACTION;

--
-- Constraints for table `stoppage_translation`
--
ALTER TABLE `stoppage_translation`
  ADD CONSTRAINT `FK__stoppages` FOREIGN KEY (`stoppage_id`) REFERENCES `stoppages` (`id`) ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
