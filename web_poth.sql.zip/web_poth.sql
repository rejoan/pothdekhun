--
-- Database: `web_poth`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `route_id` bigint(20) UNSIGNED NOT NULL,
  `comment` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `position` enum('left','right') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'left',
  `added` datetime NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE `contact_us` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `counter_address`
--

CREATE TABLE `counter_address` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `address` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `district` int(10) UNSIGNED NOT NULL,
  `thana` int(10) UNSIGNED NOT NULL,
  `poribohon_id` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `counter_address`
--

INSERT INTO `counter_address` (`id`, `address`, `district`, `thana`, `poribohon_id`) VALUES
(3, 'gabtoli', 1, 493, 23),
(4, 'majar road', 1, 493, 23),
(5, 'Majar Road, Nabil Poribohon', 1, 520, 25),
(6, 'Kamar para bu stand, Nabil Poribohon', 32, 444, 25),
(7, 'Address:114 Malibagh DIT Road\r\nPhone:9344477,01711612433', 1, 497, 15),
(8, 'Near Khaleque Pump, Kallyanpur\r\nPhone:8055902', 1, 520, 15),
(9, 'Majar road, gabtoli', 1, 493, 20),
(10, 'dada mor, ghoshpara', 28, 415, 20),
(12, '+৮৮-০১১৬৭৮-০১২৫৫০, ০১৬৭০-১০৪৭২৫, ০১৮১৯-২০৬৭৫১, ০১৮১৯-২১৭৭৪৩', 1, 493, 46),
(16, 'tesrt', 1, 493, 40),
(17, 'asdsad', 1, 493, 40);

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

CREATE TABLE `districts` (
  `id` int(2) UNSIGNED NOT NULL,
  `name` varchar(30) NOT NULL,
  `bn_name` varchar(50) NOT NULL,
  `lat` double NOT NULL,
  `lon` double NOT NULL,
  `website` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`id`, `name`, `bn_name`, `lat`, `lon`, `website`) VALUES
(1, 'Dhaka', 'ঢাকা', 23.7115253, 90.4111451, 'www.dhaka.gov.bd'),
(2, 'Faridpur', 'ফরিদপুর', 23.6070822, 89.8429406, 'www.faridpur.gov.bd'),
(3, 'Gazipur', 'গাজীপুর', 24.0022858, 90.4264283, 'www.gazipur.gov.bd'),
(4, 'Gopalganj', 'গোপালগঞ্জ', 23.0050857, 89.8266059, 'www.gopalganj.gov.bd'),
(5, 'Jamalpur', 'জামালপুর', 24.937533, 89.937775, 'www.jamalpur.gov.bd'),
(6, 'Kishoreganj', 'কিশোরগঞ্জ', 24.444937, 90.776575, 'www.kishoreganj.gov.bd'),
(7, 'Madaripur', 'মাদারীপুর', 23.164102, 90.1896805, 'www.madaripur.gov.bd'),
(8, 'Manikganj', 'মানিকগঞ্জ', 0, 0, 'www.manikganj.gov.bd'),
(9, 'Munshiganj', 'মুন্সিগঞ্জ', 0, 0, 'www.munshiganj.gov.bd'),
(10, 'Mymensingh', 'ময়মনসিং', 0, 0, 'www.mymensingh.gov.bd'),
(11, 'Narayanganj', 'নারায়াণগঞ্জ', 23.63366, 90.496482, 'www.narayanganj.gov.bd'),
(12, 'Narsingdi', 'নরসিংদী', 23.932233, 90.71541, 'www.narsingdi.gov.bd'),
(13, 'Netrokona', 'নেত্রকোনা', 24.870955, 90.727887, 'www.netrokona.gov.bd'),
(14, 'Rajbari', 'রাজবাড়ি', 23.7574305, 89.6444665, 'www.rajbari.gov.bd'),
(15, 'Shariatpur', 'শরীয়তপুর', 0, 0, 'www.shariatpur.gov.bd'),
(16, 'Sherpur', 'শেরপুর', 25.0204933, 90.0152966, 'www.sherpur.gov.bd'),
(17, 'Tangail', 'টাঙ্গাইল', 0, 0, 'www.tangail.gov.bd'),
(18, 'Bogra', 'বগুড়া', 24.8465228, 89.377755, 'www.bogra.gov.bd'),
(19, 'Joypurhat', 'জয়পুরহাট', 0, 0, 'www.joypurhat.gov.bd'),
(20, 'Naogaon', 'নওগাঁ', 0, 0, 'www.naogaon.gov.bd'),
(21, 'Natore', 'নাটোর', 24.420556, 89.000282, 'www.natore.gov.bd'),
(22, 'Nawabganj', 'নবাবগঞ্জ', 24.5965034, 88.2775122, 'www.chapainawabganj.gov.bd'),
(23, 'Pabna', 'পাবনা', 23.998524, 89.233645, 'www.pabna.gov.bd'),
(24, 'Rajshahi', 'রাজশাহী', 0, 0, 'www.rajshahi.gov.bd'),
(25, 'Sirajgonj', 'সিরাজগঞ্জ', 24.4533978, 89.7006815, 'www.sirajganj.gov.bd'),
(26, 'Dinajpur', 'দিনাজপুর', 25.6217061, 88.6354504, 'www.dinajpur.gov.bd'),
(27, 'Gaibandha', 'গাইবান্ধা', 25.328751, 89.528088, 'www.gaibandha.gov.bd'),
(28, 'Kurigram', 'কুড়িগ্রাম', 25.805445, 89.636174, 'www.kurigram.gov.bd'),
(29, 'Lalmonirhat', 'লালমনিরহাট', 0, 0, 'www.lalmonirhat.gov.bd'),
(30, 'Nilphamari', 'নীলফামারী', 25.931794, 88.856006, 'www.nilphamari.gov.bd'),
(31, 'Panchagarh', 'পঞ্চগড়', 26.3411, 88.5541606, 'www.panchagarh.gov.bd'),
(32, 'Rangpur', 'রংপুর', 25.7558096, 89.244462, 'www.rangpur.gov.bd'),
(33, 'Thakurgaon', 'ঠাকুরগাঁও', 26.0336945, 88.4616834, 'www.thakurgaon.gov.bd'),
(34, 'Barguna', 'বরগুনা', 0, 0, 'www.barguna.gov.bd'),
(35, 'Barisal', 'বরিশাল', 0, 0, 'www.barisal.gov.bd'),
(36, 'Bhola', 'ভোলা', 22.685923, 90.648179, 'www.bhola.gov.bd'),
(37, 'Jhalokati', 'ঝালকাঠি', 0, 0, 'www.jhalakathi.gov.bd'),
(38, 'Patuakhali', 'পটুয়াখালী', 22.3596316, 90.3298712, 'www.patuakhali.gov.bd'),
(39, 'Pirojpur', 'পিরোজপুর', 0, 0, 'www.pirojpur.gov.bd'),
(40, 'Bandarban', 'বান্দরবান', 22.1953275, 92.2183773, 'www.bandarban.gov.bd'),
(41, 'Brahmanbaria', 'ব্রাহ্মণবাড়িয়া', 23.9570904, 91.1119286, 'www.brahmanbaria.gov.bd'),
(42, 'Chandpur', 'চাঁদপুর', 23.2332585, 90.6712912, 'www.chandpur.gov.bd'),
(43, 'Chittagong', 'চট্টগ্রাম', 22.335109, 91.834073, 'www.chittagong.gov.bd'),
(44, 'Comilla', 'কুমিল্লা', 23.4682747, 91.1788135, 'www.comilla.gov.bd'),
(45, 'Cox''s Bazar', 'কক্স বাজার', 0, 0, 'www.coxsbazar.gov.bd'),
(46, 'Feni', 'ফেনী', 23.023231, 91.3840844, 'www.feni.gov.bd'),
(47, 'Khagrachari', 'খাগড়াছড়ি', 23.119285, 91.984663, 'www.khagrachhari.gov.bd'),
(48, 'Lakshmipur', 'লক্ষ্মীপুর', 22.942477, 90.841184, 'www.lakshmipur.gov.bd'),
(49, 'Noakhali', 'নোয়াখালী', 22.869563, 91.099398, 'www.noakhali.gov.bd'),
(50, 'Rangamati', 'রাঙ্গামাটি', 0, 0, 'www.rangamati.gov.bd'),
(51, 'Habiganj', 'হবিগঞ্জ', 24.374945, 91.41553, 'www.habiganj.gov.bd'),
(52, 'Maulvibazar', 'মৌলভীবাজার', 24.482934, 91.777417, 'www.moulvibazar.gov.bd'),
(53, 'Sunamganj', 'সুনামগঞ্জ', 25.0658042, 91.3950115, 'www.sunamganj.gov.bd'),
(54, 'Sylhet', 'সিলেট', 24.8897956, 91.8697894, 'www.sylhet.gov.bd'),
(55, 'Bagerhat', 'বাগেরহাট', 22.651568, 89.785938, 'www.bagerhat.gov.bd'),
(56, 'Chuadanga', 'চুয়াডাঙ্গা', 23.6401961, 88.841841, 'www.chuadanga.gov.bd'),
(57, 'Jessore', 'যশোর', 23.16643, 89.2081126, 'www.jessore.gov.bd'),
(58, 'Jhenaidah', 'ঝিনাইদহ', 23.5448176, 89.1539213, 'www.jhenaidah.gov.bd'),
(59, 'Khulna', 'খুলনা', 22.815774, 89.568679, 'www.khulna.gov.bd'),
(60, 'Kushtia', 'কুষ্টিয়া', 23.901258, 89.120482, 'www.kushtia.gov.bd'),
(61, 'Magura', 'মাগুরা', 23.487337, 89.419956, 'www.magura.gov.bd'),
(62, 'Meherpur', 'মেহেরপুর', 23.762213, 88.631821, 'www.meherpur.gov.bd'),
(63, 'Narail', 'নড়াইল', 23.172534, 89.512672, 'www.narail.gov.bd'),
(64, 'Satkhira', 'সাতক্ষীরা', 0, 0, 'www.satkhira.gov.bd');

-- --------------------------------------------------------

--
-- Table structure for table `drivers`
--

CREATE TABLE `drivers` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(250) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `edited_counters`
--

CREATE TABLE `edited_counters` (
  `id` int(10) UNSIGNED NOT NULL,
  `address` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `district` int(10) UNSIGNED NOT NULL,
  `thana` int(10) UNSIGNED NOT NULL,
  `poribohon_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `edited_poribohons`
--

CREATE TABLE `edited_poribohons` (
  `id` int(10) UNSIGNED NOT NULL,
  `poribohon_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `bn_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `total_vehicles` int(11) NOT NULL,
  `added_by` bigint(20) UNSIGNED NOT NULL,
  `added` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `edited_routes`
--

CREATE TABLE `edited_routes` (
  `id` int(10) UNSIGNED NOT NULL,
  `from_district` int(10) UNSIGNED NOT NULL,
  `from_thana` int(10) UNSIGNED NOT NULL,
  `from_place` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `to_district` int(10) UNSIGNED NOT NULL,
  `to_thana` int(10) UNSIGNED NOT NULL,
  `to_place` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `transport_type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `departure_time` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `route_id` bigint(20) UNSIGNED NOT NULL,
  `poribohon_id` int(11) UNSIGNED NOT NULL,
  `rent` int(11) NOT NULL,
  `evidence` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `evidence2` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `added_by` bigint(20) UNSIGNED NOT NULL,
  `added` datetime NOT NULL,
  `lang_code` enum('bn','en') COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `edited_stoppages`
--

CREATE TABLE `edited_stoppages` (
  `id` int(10) UNSIGNED NOT NULL,
  `place_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `comments` text COLLATE utf8_unicode_ci NOT NULL,
  `rent` int(11) NOT NULL,
  `route_id` int(10) UNSIGNED NOT NULL,
  `position` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` int(11) UNSIGNED NOT NULL,
  `lang_code` varchar(2) NOT NULL,
  `lang_name` varchar(30) NOT NULL,
  `lang_flag` varchar(60) NOT NULL,
  `lang_order` int(11) NOT NULL,
  `lang_status` tinyint(4) NOT NULL DEFAULT '1',
  `lang_createDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `lang_code`, `lang_name`, `lang_flag`, `lang_order`, `lang_status`, `lang_createDate`) VALUES
(1, 'bn', 'bengali', 'Bangladesh', 0, 1, '0000-00-00 00:00:00'),
(2, 'en', 'english', 'England', 0, 1, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `point_paid`
--

CREATE TABLE `point_paid` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `paid_mobile` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `point_amount` int(11) NOT NULL,
  `paid_at` datetime NOT NULL,
  `verification_code` varchar(250) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `poribohons`
--

CREATE TABLE `poribohons` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `bn_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `total_vehicles` int(11) NOT NULL,
  `is_publish` int(11) NOT NULL DEFAULT '0',
  `added_by` bigint(20) UNSIGNED NOT NULL,
  `added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `poribohons`
--

INSERT INTO `poribohons` (`id`, `name`, `bn_name`, `total_vehicles`, `is_publish`, `added_by`, `added`) VALUES
(1, 'Tetulia Paribahan', 'তেতুলিয়া পরিবহন', 40, 1, 2, '2017-01-23 21:33:26'),
(2, 'TR Paribahan', 'টিআর পরিবহন', 0, 1, 4, '2016-11-30 11:25:31'),
(3, 'Dipon Transport', 'দীপন ট্রান্সপোর্ট', 15, 1, 4, '2017-02-02 03:45:52'),
(4, 'Haque Special', 'হক স্পেশাল', 15, 1, 4, '2016-11-11 10:35:59'),
(6, 'Bikash Paribahan', 'বিকাশ পরিবহন', 20, 1, 4, '2016-11-30 11:25:40'),
(7, 'Projapoti Paribahan', 'প্রজাপতি পরিবহন', 0, 1, 4, '2016-11-30 11:20:29'),
(8, 'Bhuyian Paribahan', 'ভূইয়া পরিবহন', 0, 1, 4, '2017-01-02 17:10:12'),
(9, 'Bengal Motors', 'বেঙ্গল মটরস', 0, 1, 4, '2017-01-03 01:19:49'),
(12, 'Sadhin Bangla', 'স্বাধীন বাংলা', 0, 1, 4, '2017-01-03 14:41:11'),
(14, 'RangDhanu Paribahan', 'রংধনু পরিবহন', 0, 1, 2, '2017-01-11 21:47:19'),
(15, 'Shohagh Paribahan', 'সোহাগ পরিবহন', 20, 1, 2, '2017-01-24 16:09:37'),
(16, 'Himachol Enterprise', 'হিমাচল এন্টারপ্রাইজ', 0, 1, 2, '2017-01-18 14:20:16'),
(17, 'Dhaka Paribahan', 'ঢাকা পরিবহন', 0, 1, 2, '2017-01-18 15:07:19'),
(18, 'Prottoy Transport', 'প্রত্যয় ট্রান্সপোর্ট', 0, 1, 2, '2017-01-19 18:13:50'),
(19, 'Gabtoli link', 'গাবতলী লিংক', 0, 1, 2, '2017-01-19 19:22:17'),
(20, 'Nabil Paribahan', 'নাবিল পরিবহন', 10, 1, 2, '2017-01-25 13:45:23'),
(21, 'Hanif Paribahan', 'হানিফ', 100, 1, 4, '2017-01-23 13:55:04'),
(22, 'Eagle Paribahan', 'ঈগল পরিবহন', 100, 1, 4, '2017-01-23 13:56:39'),
(23, 'Shamoly Paribahan', 'শ্যামলী', 0, 1, 4, '2017-01-23 13:58:47'),
(24, 'Labbayak Paribahan', 'লাব্বাইক পরিবহন', 0, 1, 2, '2017-01-23 21:41:13'),
(25, 'Nabil Scania', 'নাবিল স্কানিয়া', 2, 1, 2, '2017-01-24 15:15:28'),
(26, 'Jabale Nur Paribahan', 'জাবালে নুর পরিবহন', 0, 1, 2, '2017-01-24 14:32:29'),
(27, 'ETC Transport Co. Ltd', 'ইটিসি ট্রান্সপোর্ট কো. লি.', 0, 1, 2, '2017-01-24 16:20:46'),
(28, 'Bihongo Paribahan', 'বিহঙ্গ পরিবহন', 0, 1, 2, '2017-01-25 01:05:23'),
(29, 'Torongo Plus Transpot Ltd', 'তরঙ্গ প্লাস ট্রান্সপোর্ট লি.', 0, 1, 2, '2017-01-25 01:20:51'),
(30, 'Torongo bus co.', 'তরঙ্গ বাস কো.', 0, 1, 2, '2017-01-25 01:32:02'),
(31, 'Raja City Paribahan', 'রাজা সিটি পরিবহন', 0, 1, 2, '2017-01-25 13:56:55'),
(32, 'Tanjil Paribahan', 'তানজিল পরিবহন', 0, 1, 2, '2017-01-25 14:03:16'),
(33, '6 no motijheel banani transport', '৬ নং মতিঝিল বনানী ট্রান্সপোর্ট লি.', 0, 1, 2, '2017-01-25 14:17:49'),
(34, 'Shikor Paribahan', 'শিকড় পরিবহন', 0, 1, 2, '2017-01-28 16:03:33'),
(35, 'Mirpur United Service Ltd', 'Mirpur United Service Ltd', 0, 1, 6, '2017-01-28 16:05:25'),
(36, 'Silk City Service', 'Silk City Service', 0, 1, 6, '2017-01-28 16:05:29'),
(37, 'Balaka Service', 'বলাকা সার্ভিস', 0, 1, 2, '2017-01-27 15:30:00'),
(38, 'Basumoti Transport', 'বসুমতি ট্রান্সপোর্ট', 0, 1, 2, '2017-01-27 15:40:02'),
(39, 'Provati Banasree Paribahan', 'প্রভাতী বনশ্রী', 150, 1, 2, '2017-01-28 07:56:01'),
(40, 'Satabdi Paribahan', 'Satabdi Paribahan', 15, 1, 6, '2017-01-29 19:30:44'),
(41, '7 no bus', '৭ নং বাস', 0, 1, 2, '2017-01-27 20:59:52'),
(42, 'Turag', 'তুরাগ', 0, 1, 2, '2017-01-28 08:42:39'),
(43, 'Thikana Express Ltd.', 'ঠিকানা এক্সপ্রেস লি.', 0, 1, 2, '2017-01-28 08:54:42'),
(44, 'Su Provat CIty Service', 'সুপ্রভাত সিটি সার্ভিস', 0, 1, 2, '2017-01-28 09:04:06'),
(45, 'Sky Line', 'স্কাই লাইন', 0, 1, 6, '2017-01-29 02:54:38'),
(46, 'Moitri Paribahan Ltd', 'মৈত্রী পরিবহন লি.', 25, 1, 6, '2017-01-28 16:03:57'),
(47, 'BRTC Double Decker', 'বিআরটিসি ডাবল ডেকার', 0, 1, 6, '2017-01-29 02:54:45'),
(48, 'ATCL', 'এটিসিএল', 0, 1, 6, '2017-01-29 02:55:13'),
(49, 'Suchona', 'সূচনা', 0, 1, 2, '2017-01-28 22:45:18'),
(50, 'Malancha Transport', 'মালঞ্চ ট্রান্সপোর্ট', 0, 1, 6, '2017-01-30 22:06:43'),
(51, 'Safety Sitting Service', 'সেফটি সিটিং সার্ভিস', 0, 1, 2, '2017-01-30 07:24:06'),
(52, 'Winner Transport', 'উইনার ট্রান্সপোর্ট', 0, 1, 2, '2017-02-01 01:35:36'),
(53, 'Kanak Paribahan Ltd', 'কনক পরিবহন লি.', 0, 1, 2, '2017-02-01 03:51:46'),
(54, 'Falgun Transport', 'ফাল্গুন ট্রান্সপোর্ট', 0, 1, 2, '2017-02-01 04:08:43'),
(55, 'Agomony Express RM2', 'আগমনী এক্সপ্রেস', 0, 1, 2, '2017-02-01 23:58:37'),
(56, 'Ena Transport', 'এনা ট্রান্সপোর্ট', 0, 1, 2, '2017-02-02 00:50:49'),
(57, 'Sokolpo Paribahan', 'স্বকল্প পরিবহন', 0, 1, 2, '2017-02-02 01:35:54'),
(58, 'Bikolpo Auto Service', 'বিকল্প অটো সার্ভিস', 0, 1, 2, '2017-02-02 02:59:44'),
(59, 'Ekushe Paribahan Ltd', 'একুশে পরিবহন লি.', 0, 1, 2, '2017-02-02 03:07:04'),
(60, 'Midway Paribahan Ltd', 'মিডওয়ে পরিবহন লি.', 0, 1, 2, '2017-02-02 03:22:23'),
(61, 'Bahon Paribahan Ltd', 'বাহন পরিবহন লি', 0, 1, 2, '2017-02-02 03:37:32'),
(62, 'My Line', 'মাই লাইন', 0, 1, 2, '2017-02-02 04:00:17'),
(63, 'SB Paribahan', 'এসবি পরিবহন', 0, 1, 2, '2017-02-01 18:56:07'),
(64, 'Alif Enterprise', 'আলিফ এন্টারপ্রাইজ', 0, 1, 2, '2017-02-02 16:22:28'),
(65, 'Pallabi Local Service', 'পল্লবী লোকাল সার্ভিস', 0, 1, 2, '2017-02-02 17:20:13'),
(66, 'Rob Rob Paribahan', 'রব রব পরিবহন', 0, 1, 2, '2017-02-02 17:40:39'),
(67, 'Trans Silva Ltd.', 'ট্রান্স সিলভা', 0, 1, 2, '2017-02-02 19:04:50'),
(68, 'New Vision', 'নিউ ভিশন', 0, 1, 2, '2017-02-02 19:20:10'),
(69, 'Rupkotha Paribahan Ltd', 'রুপকথা পরিবহন লি.', 0, 1, 2, '2017-02-02 19:27:29'),
(70, 'Choice (Choyej) Transport', 'চয়েজ ট্রান্সপোর্ট', 0, 1, 2, '2017-02-02 19:36:40'),
(71, 'Best Transport', 'বেস্ট ট্রান্সপোর্ট', 0, 1, 2, '2017-02-02 20:41:55'),
(72, 'Jatayat Paribahan', 'যাতায়াত পরিবহন', 0, 1, 2, '2017-02-02 20:50:38'),
(73, 'Anannya Paribahan', 'অনন্যা পরিবহন', 0, 1, 2, '2017-02-02 20:58:01'),
(74, 'Badsha Paribahan', 'বাদশা পরিবহন', 0, 1, 2, '2017-02-02 21:04:20'),
(75, 'Chalanbil Paribahan', 'চলনবিল পরিবহন', 10, 1, 2, '2017-02-02 21:07:59'),
(76, 'D.Link Ltd', 'ডি লিংক', 0, 1, 2, '2017-02-02 22:27:52'),
(77, 'Many Owers Leguna', 'বিভিন্ন মালিকের লেগুনা', 0, 1, 2, '2017-02-04 02:39:41'),
(78, 'Boishakhi Paribahan', 'বৈশাখী পরিবহন', 0, 1, 2, '2017-02-04 04:20:33'),
(79, 'Dishari Paribahan Ltd', 'দিশারী পরিবহন', 0, 1, 2, '2017-02-04 04:34:27'),
(80, 'Ajmeri Glory', 'আজমেরী গ্লোরী', 0, 1, 2, '2017-02-04 04:43:27'),
(81, 'Nur-E-Makka Paribahan', 'নুর-ই-মক্কা পরিবহন', 0, 1, 2, '2017-02-04 04:53:58'),
(82, 'Akik Paribahan Ltd', 'আকিক পরিবহন', 30, 1, 2, '2017-02-04 05:02:15'),
(83, 'Cantonment Mini Service', 'ক্যান্টনমেন্ট মিনি সার্ভিস', 0, 1, 2, '2017-02-04 08:51:36'),
(84, 'Welcome Transport', 'ওয়েলকাম ট্রান্সপোর্ট', 0, 1, 2, '2017-02-04 09:00:54'),
(85, 'Rajdhani Express', 'রাজধানী এক্সপ্রেস', 0, 1, 2, '2017-02-04 09:09:11'),
(86, 'Itihas Paribahan', 'ইতিহাস পরিবহন', 0, 1, 2, '2017-02-04 09:18:43');

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `id` bigint(20) NOT NULL,
  `first_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `occupation` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `sex` enum('Male','Female','Other') COLLATE utf8_unicode_ci NOT NULL,
  `birth_date` datetime NOT NULL,
  `about` text COLLATE utf8_unicode_ci NOT NULL,
  `thana` int(10) UNSIGNED NOT NULL,
  `district` int(10) UNSIGNED NOT NULL,
  `country` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`id`, `first_name`, `last_name`, `occupation`, `sex`, `birth_date`, `about`, `thana`, `district`, `country`, `user_id`) VALUES
(2, 'Rejoan', 'Alam', '', '', '0000-00-00 00:00:00', 'qweqw', 493, 1, '', 2),
(3, 'Rejoanul', 'Alam', '', '', '0000-00-00 00:00:00', 'Test user', 493, 1, '', 6),
(4, 'Faisal', 'Alam', '', '', '0000-00-00 00:00:00', '', 493, 1, '', 9);

-- --------------------------------------------------------

--
-- Table structure for table `routes`
--

CREATE TABLE `routes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `from_district` int(11) UNSIGNED NOT NULL,
  `from_thana` int(11) UNSIGNED NOT NULL,
  `from_place` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `to_place` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `to_district` int(11) UNSIGNED NOT NULL,
  `to_thana` int(11) UNSIGNED NOT NULL,
  `from_latlong` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `to_latlong` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `transport_type` enum('bus','train','launch','leguna','biman','others') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'bus',
  `poribohon_id` int(11) UNSIGNED NOT NULL,
  `departure_time` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `rent` int(11) NOT NULL,
  `evidence` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `evidence2` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `added` datetime NOT NULL,
  `added_by` bigint(20) UNSIGNED NOT NULL,
  `is_publish` int(11) NOT NULL DEFAULT '0' COMMENT '0=not published,1=published',
  `distance` int(11) NOT NULL,
  `duration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `routes`
--

INSERT INTO `routes` (`id`, `from_district`, `from_thana`, `from_place`, `to_place`, `to_district`, `to_thana`, `from_latlong`, `to_latlong`, `transport_type`, `poribohon_id`, `departure_time`, `rent`, `evidence`, `evidence2`, `added`, `added_by`, `is_publish`, `distance`, `duration`) VALUES
(1, 1, 520, 'Mirpur-1', 'Jhigatola', 1, 510, '23.7956037,90.3536548', '23.7414675,90.3702192', 'leguna', 12, '1', 23, '', '', '2017-02-04 07:30:39', 2, 1, 8084, 1831),
(2, 1, 493, 'Japan Garden City', 'AbdullahPur', 1, 537, '23.7641178,90.3582533', '23.8932542,90.387477', 'bus', 8, '1', 40, '', '', '2017-02-04 07:28:48', 2, 1, 20543, 3173),
(3, 1, 520, 'Mirpur-1', 'AbdullahPur', 1, 537, '23.7956037,90.3536548', '23.8932542,90.387477', 'bus', 9, '1', 40, '', '', '2017-01-30 20:17:49', 2, 1, 15986, 2291),
(4, 28, 415, 'Ghosh Para', 'Asad gate', 1, 493, '25.7970092,89.6381096', '23.7601309,90.3727895', 'bus', 4, 'Daily moring and night', 550, '', '', '2017-02-02 21:31:52', 2, 1, 343519, 27628),
(5, 1, 493, 'Japan Garden City', 'AbdullahPur', 1, 537, '23.7653461,90.3571495', '23.8932542,90.387477', 'bus', 1, '1', 40, '1485185049Tetulia.jpg', '', '2017-01-23 21:27:01', 2, 1, 20439, 3149),
(6, 1, 493, 'Japan Garden City', 'Postagola', 1, 532, '23.7641178,90.3582533', '23.6927717,90.4301942', 'bus', 14, '1', 40, '', '', '2017-01-18 14:05:57', 2, 1, 15585, 2929),
(8, 1, 520, 'Kallyanpur', 'Jessore', 57, 286, '23.7822036,90.3595372', '23.3560954,89.3469894', 'bus', 15, '1', 550, '', '', '2017-01-24 02:37:41', 2, 1, 169492, 18449),
(9, 1, 493, 'Bossila', 'AbdullahPur', 1, 537, '23.754687,90.3589489', '23.8932542,90.387477', 'bus', 7, '1', 40, '', '', '2017-01-23 22:27:46', 2, 1, 21133, 3322),
(10, 1, 493, 'Tajmohol Road', 'Motijheel', 1, 521, '23.7632068,90.3617656', '23.7329724,90.417231', 'bus', 3, '1', 30, '1485985689dipon.JPG', '', '2017-02-02 03:48:09', 2, 1, 8614, 1625),
(11, 1, 520, 'Mirpur-1', 'Khilgoan', 1, 516, '23.7956037,90.3536548', '23.7566389,90.4643906', 'bus', 16, '1', 45, '', '', '2017-01-18 14:45:02', 2, 1, 17110, 3203),
(12, 1, 521, 'Shapla chottor', 'Gazipur', 3, 159, '23.7266278,90.4216667', '24.0958171,90.4125181', 'bus', 17, '1', 50, '', '', '2017-01-18 15:08:13', 2, 1, 48488, 6255),
(13, 1, 520, 'Gabtoli', 'Mohakhali', 1, 534, '23.7837257,90.3442449', '23.7776282,90.4054498', 'leguna', 18, '1', 15, '', '', '2017-01-19 18:42:23', 2, 1, 9368, 1823),
(14, 1, 520, 'Gabtoli', 'Sadar ghat', 1, 518, '23.7837257,90.3442449', '23.7047113,90.4160527', 'bus', 19, '1', 30, '1485184602transport2_(1).jpg', '', '2017-01-23 21:16:42', 2, 1, 15021, 2989),
(15, 28, 415, 'Ghosh Para', 'Gabtoli', 1, 520, '25.7970092,89.6381096', '23.7837257,90.3442449', 'bus', 20, 'Daily morning and night', 550, '', '', '2017-01-21 14:04:06', 2, 1, 339277, 26704),
(16, 1, 520, 'Majar road, Gabtoli', 'Purbasa Hall, Dada mor', 28, 415, '23.7832255,90.3472139', '25.8281684,89.6816208', 'bus', 21, 'Daily morning and night', 550, '', '', '2017-02-01 19:03:45', 2, 1, 349329, 28090),
(17, 1, 520, 'Majar road, Gabtoli', 'Kamar para bus stand', 32, 444, '23.7832255,90.3472139', '25.7318144,89.2277026', 'bus', 21, '1', 550, '1486172405Hanif-Paribahan.jpg', '', '2017-02-04 07:40:05', 2, 1, 294664, 23029),
(18, 1, 149, 'Savar', 'Signboard', 1, 511, '23.8701334,90.2713944', '23.6918777,90.4814999', 'bus', 24, '1', 50, '1485186073Labbayak.JPG', '', '2017-01-23 21:42:00', 2, 1, 38956, 5300),
(19, 32, 444, 'Kamar para bus stand', 'Technical', 1, 520, '25.7318144,89.2277026', '23.7805468,90.3523314', 'bus', 25, '1', 1400, '1485245286nabil_scania.jpg', '1485245286nabil_scania_front.jpg', '2017-01-25 13:44:21', 2, 1, 294203, 23456),
(20, 1, 493, 'Agargaon', 'AbdullahPur', 1, 537, '23.7791954,90.3736584', '23.8932542,90.387477', 'bus', 26, '1', 30, '1485246749Jabale-e-nur-bus.jpg', '', '2017-01-24 14:33:00', 2, 1, 21258, 2897),
(21, 1, 520, 'Mirpur-12', 'Gulistan', 1, 509, '23.7702886,90.3561731', '23.7227747,90.4140338', 'bus', 27, '1', 30, '1485253246ETC_Transport.jpg', '', '2017-01-24 17:00:23', 2, 1, 11124, 2229),
(22, 1, 520, 'Duaripara', 'Victoria Park', 1, 509, '23.8260874,90.3565959', '23.7093699,90.4123708', 'bus', 28, '1', 25, '1485284723Bihongo.jpg', '', '2017-01-25 01:05:56', 2, 1, 16266, 3521),
(23, 1, 493, 'Mohammadpur bus stand', 'Banasree', 1, 539, '23.757741,90.3624389', '23.7619353,90.433141', 'bus', 29, '1', 35, '', '', '2017-01-25 01:21:17', 2, 1, 9767, 2031),
(24, 1, 493, 'Mohammadpur bus stand', 'Natun Bazar', 1, 497, '23.757741,90.3624389', '23.7851549,90.3563036', 'bus', 30, '1', 25, '1486053105Torongo.JPG', '', '2017-02-02 22:31:45', 2, 1, 5132, 1086),
(25, 1, 493, 'Asad gate', 'Notredame college, arambag', 1, 540, '23.7601309,90.3727895', '23.7306729,90.4210948', 'bus', 31, '1', 20, '1485331015Raja_city.JPG', '', '2017-01-25 13:57:28', 2, 1, 7910, 1530),
(26, 1, 520, 'Mirpur-1 (chiriakhana)', 'Sadar ghat', 1, 518, '23.8124802,90.3471922', '23.7047113,90.4160527', 'bus', 32, '1', 25, '1485331396tanjil_poribohon.JPG', '', '2017-01-26 14:02:29', 2, 1, 18072, 3630),
(27, 1, 521, 'Motijheel', 'Natun bazar', 1, 497, '23.7329724,90.417231', '23.7849928,90.3593901', 'bus', 33, '1', 25, '1485332269motijheel_6_banani.jpg', '', '2017-01-25 14:19:35', 2, 1, 10756, 1875),
(28, 1, 520, 'Mirpur-12', 'Signboard', 1, 511, '23.7702886,90.3561731', '23.6918777,90.4814999', 'bus', 34, '1', 35, '1485959884Shikor_poribohon.jpg', '', '2017-02-01 09:38:04', 2, 1, 18581, 2852),
(29, 1, 520, 'Pallabi (Mirpur-12)', 'Sadar ghat', 1, 518, '23.8225698,90.3749734', '23.7047113,90.4160527', 'bus', 35, '1', 30, '1486160199mirpur_united.JPG', '1486175967mirpur_united.jpg', '2017-02-04 08:39:27', 2, 1, 18837, 3283),
(30, 1, 520, 'Pallabi (BDR shooping master counter)', 'Jatrabari', 1, 509, '23.7658444,90.3583606', '23.715422,90.4232021', 'bus', 36, '1', 35, '', '', '2017-01-28 09:18:11', 2, 1, 11440, 2165),
(31, 1, 511, 'Saidabad', 'Shibbari', 3, 159, '23.7136051,90.427837', '23.9982721,90.4178774', 'bus', 37, '1', 40, '1485509400Balaka_service.jpg', '', '2017-01-27 15:30:47', 2, 1, 52069, 6165),
(32, 1, 520, 'Gabtoli', 'Gazipur', 3, 159, '23.7837257,90.3442449', '24.0958171,90.4125181', 'bus', 38, '1', 40, '1485510002bosumati_side.jpg', '1485510002bosumoti.jpg', '2017-01-27 15:40:26', 2, 1, 42628, 5413),
(33, 1, 541, 'Fulbaria', 'Kaliakoir', 1, 509, '24.6249931,90.266699', '24.119897,90.2807868', 'bus', 39, '1', 45, '1485523518provati_banasree.jpg', '1485984634provati__banasree.jpg', '2017-02-02 03:30:34', 2, 1, 79913, 8650),
(34, 1, 520, 'Mirpur-14', 'Motijheel', 1, 521, '23.7510806,90.3782897', '23.7329724,90.417231', 'bus', 40, '1', 35, '1485524223Shotabdi_poribohon.JPG', '', '2017-01-27 19:37:23', 2, 1, 5671, 1118),
(35, 1, 520, 'Gabtoli', 'Sadar ghat', 1, 518, '23.7837257,90.3442449', '23.7047113,90.4160527', 'bus', 41, '1', 25, '1485529192transport2_(1).jpg', '14860501057no_bus.jpg', '2017-02-02 21:41:45', 2, 1, 15021, 2989),
(36, 1, 511, 'Jatrabari', 'Cherag Ali', 3, 164, '23.715422,90.4232021', '23.9055035,90.3995977', 'bus', 42, '1', 35, '1485571359Turag.jpg', '', '2017-01-28 08:42:51', 2, 1, 27331, 4169),
(37, 1, 149, 'Jirani', 'Signboard', 1, 509, '23.8701334,90.2713944', '23.6918777,90.4814999', 'bus', 43, '1', 50, '1485572082Thikana.jpg', '', '2017-02-04 00:25:21', 2, 1, 38956, 5300),
(38, 1, 518, 'Sadar ghat', 'Gazipur', 3, 159, '23.7047113,90.4160527', '24.0958171,90.4125181', 'bus', 44, '1', 30, '1485572646suprovat.JPG', '1486053185suprovat_city_service.jpg', '2017-02-02 22:33:05', 2, 1, 50730, 7118),
(39, 1, 518, 'Sadar ghat', 'Cherag Ali', 3, 164, '23.7047113,90.4160527', '23.9055035,90.3995977', 'bus', 45, '1', 40, '1485573071sky_line.JPG', '', '2017-01-28 09:38:44', 2, 1, 27575, 4667),
(40, 1, 493, 'Town Hall', 'Notredame college, arambag', 1, 540, '23.759646,90.3657975', '23.7306729,90.4210948', 'bus', 46, '1', 20, '', '', '2017-01-28 16:10:19', 6, 1, 8660, 1751),
(41, 1, 493, 'Mohammadpur bus stand', 'Natun Bazar', 1, 497, '23.757741,90.3624389', '23.7849928,90.3593901', 'bus', 47, '1', 30, '1486171460brtc_double.jpg', '', '2017-02-04 07:24:20', 6, 1, 4484, 1019),
(42, 1, 493, 'Mohammadpur bus stand', 'Notredame college, arambag', 1, 540, '23.757741,90.3624389', '23.7306729,90.4210948', 'bus', 48, '1', 25, '1486203852atcl.jpg', '', '2017-02-04 16:24:12', 6, 1, 9022, 1854),
(43, 1, 523, 'Palashi Etimkhana', 'HouseBuilding', 1, 537, '23.7330788,90.383972', '23.7302329,90.4114247', 'bus', 49, '1', 35, '1486049856suchona.JPG', '', '2017-02-02 21:37:36', 2, 1, 3183, 908),
(44, 1, 493, 'Mohammadpur bus stand', 'Dhupkhola', 1, 508, '23.757741,90.3624389', '23.7065203,90.422008', 'bus', 50, '1', 23, '', '', '2017-01-30 22:07:07', 6, 1, 11272, 2306),
(45, 1, 520, 'Mirpur-12', 'Azimpur Etimkhana', 1, 523, '23.7702886,90.3561731', '23.722621,90.3874582', 'bus', 51, '1', 20, '', '', '2017-01-30 07:24:24', 2, 1, 7753, 1895),
(46, 1, 523, 'Eden College', 'Kuril Bishwa Road', 1, 509, '23.7276244,90.386517', '23.8211887,90.4195458', 'bus', 52, '1', 25, '1485930936Winner.JPG', '', '2017-02-01 01:42:22', 6, 1, 13801, 2236),
(47, 1, 520, 'Pallabi (Mirpur-12)', 'AbdullahPur', 1, 537, '23.8225698,90.3749734', '23.8932542,90.387477', 'bus', 53, '1', 35, '1485939106konok.jpg', '', '2017-02-01 03:52:13', 2, 1, 15010, 1970),
(48, 1, 493, 'Azimpur', 'Uttara Housebuiding', 1, 537, '23.7285918,90.38543', '23.8737218,90.4007328', 'bus', 54, '1', 30, '1486160074falgun.JPG', '', '2017-02-04 04:14:34', 2, 1, 20024, 3050),
(49, 32, 444, 'Jahaj company', 'Kallyanpur', 1, 520, '25.7484497,89.2541232', '23.7822036,90.3595372', 'bus', 55, 'Daily morning and night', 780, '1485971916agomony.jpg', '1485971916agomony_front.jpg', '2017-02-01 23:58:48', 2, 1, 294881, 23682),
(50, 1, 520, 'Mirpur-12', 'Shapla chottor', 1, 521, '23.7702886,90.3561731', '23.7266278,90.4216667', 'bus', 56, '1', 26, '1485976473ena.JPG', '', '2017-02-02 01:14:46', 2, 1, 10439, 2082),
(51, 1, 520, 'Mirpur-1 (chiriakhana)', 'Kamlapur', 1, 521, '23.8124802,90.3471922', '23.7336922,90.4260691', 'bus', 57, '1', 25, '', '', '2017-02-02 01:36:10', 2, 1, 15023, 3024),
(52, 1, 520, 'Mirpur-12', 'Motijheel', 1, 521, '23.7702886,90.3561731', '23.7329724,90.417231', 'bus', 58, '1', 25, '1485982784bikolpo.jpg', '1485982784bikolpo2jpg.jpg', '2017-02-02 03:00:05', 2, 1, 9908, 1972),
(53, 1, 520, 'Gabtoli', 'Khidmah Hospital (Khilgaon)', 1, 509, '23.7837257,90.3442449', '23.7490582,90.4201353', 'bus', 59, '1', 30, '', '', '2017-02-02 03:07:17', 2, 1, 10580, 2192),
(54, 1, 493, 'Mohammadpur bus stand', 'Khilgoan', 1, 516, '23.757741,90.3624389', '23.7566389,90.4643906', 'bus', 60, '1', 40, '', '', '2017-02-02 03:22:36', 2, 1, 14093, 2687),
(55, 1, 520, 'Mirpur-14', 'Taltola khilgaon', 1, 516, '23.7510806,90.3782897', '23.7519151,90.4257745', 'bus', 61, '1', 40, '1485985052bahon.JPG', '', '2017-02-02 03:37:45', 2, 1, 7800, 1569),
(56, 1, 520, 'Bhasantek Mirpur', 'Taltola khilgaon', 1, 516, '23.8057416,90.3875471', '23.7519151,90.4257745', 'bus', 62, '1', 40, '', '', '2017-02-02 04:00:28', 2, 1, 11190, 2473),
(57, 1, 493, 'Asad gate', 'Dada mor', 28, 415, '23.7601309,90.3727895', '25.8281684,89.6816208', 'bus', 63, '1', 550, '', '', '2017-02-01 18:56:22', 2, 1, 352848, 28541),
(58, 1, 493, 'Khejur Bagan, Farmgate', 'Chandra Savar', 1, 149, '23.7658444,90.3583606', '23.9181893,90.2605391', 'bus', 64, '1', 40, '1486030948alif.jpg', '1486030948alif2.jpg', '2017-02-02 17:07:16', 2, 1, 26416, 3278),
(59, 1, 520, 'Pallabi (Mirpur-12)', 'Dhakeswari Mandir (Azimpur)', 1, 523, '23.8225698,90.3749734', '23.7330788,90.383972', 'bus', 65, '1', 30, '', '', '2017-02-02 17:21:15', 2, 1, 14565, 2600),
(60, 1, 520, 'Gabtoli', 'Badda link road, Rampura', 1, 527, '23.7837257,90.3442449', '23.7807869,90.423427', 'bus', 66, '1', 30, '1486035639robrob_side.jpg', '1486035639robrob_side2.jpg', '2017-02-02 17:52:05', 2, 1, 10836, 2196),
(61, 1, 520, 'Boishakhi Market (Mirpur-1)', 'Gol Chattor, Jatrabari', 1, 511, '23.7989488,90.3543467', '23.715422,90.4232021', 'bus', 67, '1', 30, '', '', '2017-02-02 19:10:15', 2, 1, 14451, 2670),
(62, 1, 520, 'Mirpur-1 (chiriakhana)', 'Ittefaq, Motijheel', 1, 521, '23.8124802,90.3471922', '23.7213087,90.4205365', 'bus', 68, '1', 25, '1486041610new_vision.jpg', '', '2017-02-02 19:20:22', 2, 1, 15618, 3108),
(63, 1, 520, 'Gabtoli', 'AbdullahPur', 1, 537, '23.7837257,90.3442449', '23.8932542,90.387477', 'bus', 69, '1', 35, '1486042049Rupkotha.JPG', '', '2017-02-02 19:27:38', 2, 1, 16449, 2306),
(64, 1, 520, 'Mirpur-12', 'Rayerbag (Jatrabari)', 1, 511, '23.7702886,90.3561731', '23.6964312,90.4599828', 'bus', 70, '1', 30, '1486042600choice.JPG', '', '2017-02-02 19:36:53', 2, 1, 16466, 2739),
(65, 1, 520, 'Duaripara Pallabi', 'demraghat', 1, 506, '23.8260874,90.3565959', '23.7212645,90.4963468', 'bus', 71, '1', 30, '1486046515best.JPG', '', '2017-02-02 20:42:04', 2, 1, 24013, 3859),
(66, 6, 185, 'Kishoreganj town', 'Saidabad Bus stand', 1, 511, '24.4331227,90.7865655', '23.7161814,90.4259241', 'bus', 72, '1', 300, '', '', '2017-02-02 20:50:53', 2, 1, 114474, 11359),
(67, 6, 185, 'Kishoreganj town', 'Mohakhali Bus Stand', 1, 511, '24.4331227,90.7865655', '23.7782392,90.3977394', 'bus', 73, '1', 300, '', '', '2017-02-02 20:58:12', 2, 1, 116516, 11596),
(68, 6, 180, 'Bhairab Bus Stand', 'Mohakhali Bus Stand', 1, 534, '24.0553208,90.9828472', '23.7782392,90.3977394', 'bus', 74, '1', 200, '', '', '2017-02-02 21:20:00', 2, 1, 83929, 7515),
(69, 6, 180, 'Bhairab Bus Stand', 'Mohakhali Bus Stand', 1, 534, '24.0553208,90.9828472', '23.7782392,90.3977394', 'bus', 75, '1', 200, '', '', '2017-02-02 21:19:09', 2, 1, 83929, 7515),
(70, 1, 145, 'Dhamrai', 'Fulbaria Gulistan', 1, 541, '23.9148319,90.2174318', '23.7233763,90.4101366', 'bus', 76, '1', 50, '1486052872dlink_gulistan_dhamrai.JPG', '', '2017-02-02 22:28:11', 2, 1, 39448, 5469),
(71, 1, 493, 'Mohammadpur bus stand', 'Gulshan', 1, 509, '23.757741,90.3624389', '23.7924961,90.4078058', 'leguna', 77, '1', 15, '', '', '2017-02-04 02:40:20', 2, 1, 7879, 1437),
(72, 1, 149, 'Savar Bus Stand', 'Natun Bazar (Badda)', 1, 497, '23.8473757,90.2571957', '23.7849928,90.3593901', 'bus', 78, '1', 35, '', '', '2017-02-04 04:20:44', 2, 1, 16276, 2158),
(73, 1, 520, 'Mirpur-1 (chiriakhana)', 'Babu bazar breeze', 1, 147, '23.8124802,90.3471922', '23.7081108,90.401172', 'bus', 79, '1', 35, '1486175932dishari.jpg', '', '2017-02-04 08:38:52', 2, 1, 16814, 3464),
(74, 1, 518, 'Sadar ghat', 'Chandra', 3, 159, '23.7047113,90.4160527', '23.9917345,90.4195876', 'bus', 80, '1', 50, '', '', '2017-02-04 04:43:35', 2, 1, 52253, 6373),
(75, 1, 520, 'Mirpur-1 (chiriakhana)', 'Rampura Banasree', 1, 539, '23.8124802,90.3471922', '23.7619353,90.433141', 'bus', 81, '1', 30, '1486162438Nur-E_Mecca.jpg', '', '2017-02-04 04:54:06', 2, 1, 15064, 3109),
(76, 1, 520, 'Mirpur-1 (chiriakhana)', 'Rampura Banasree', 1, 539, '23.8124802,90.3471922', '23.7619353,90.433141', 'bus', 82, '1', 30, '1486163001akik.jpg', '', '2017-02-04 05:03:21', 2, 1, 15064, 3109),
(77, 1, 520, 'Mirpur-14', 'Kakoli', 1, 542, '23.7510806,90.3782897', '23.7461029,90.4002044', 'bus', 83, '1', 20, '1486176696cantonment_mini.jpg', '', '2017-02-04 08:51:47', 2, 1, 2916, 648),
(78, 1, 149, 'EPZ', 'Shapla chottor', 1, 521, '23.7442469,90.3843981', '23.7266278,90.4216667', 'bus', 84, '1', 45, '', '', '2017-02-04 09:01:05', 2, 1, 5934, 1273),
(79, 1, 493, 'Shia Mashjid', 'Rayerbag (Jatrabari)', 1, 511, '23.7622634,90.3591327', '23.6964312,90.4599828', 'bus', 85, '1', 40, '', '', '2017-02-04 09:11:54', 2, 1, 15458, 2495),
(80, 1, 149, 'EPZ', 'Mirpur-14 bus stand', 1, 520, '23.7442469,90.3843981', '23.7982444,90.3873646', 'bus', 86, '1', 30, '1486178323itihas.jpg', '', '2017-02-04 09:19:04', 2, 1, 9752, 1824);

-- --------------------------------------------------------

--
-- Table structure for table `route_bn`
--

CREATE TABLE `route_bn` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `route_id` bigint(20) UNSIGNED NOT NULL,
  `from_place` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `to_place` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `departure_time` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `translation_status` enum('1','2','3') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1' COMMENT '1=incomplete,2=partial,3=complete'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `route_bn`
--

INSERT INTO `route_bn` (`id`, `route_id`, `from_place`, `to_place`, `departure_time`, `translation_status`) VALUES
(1, 1, 'মিরপুর-১', 'ঝিগাতলা', '1', '1'),
(2, 2, 'জাপান গার্ডেন সিটি', 'আব্দুল্লাহপুর', '1', '1'),
(3, 3, 'মিরপুর-১', 'আব্দুল্লাহপুর', '1', '1'),
(4, 4, 'ঘোষপাড়া', 'আসাদ গেট', 'প্রতিদিন সকাল এবং রাতে', '1'),
(5, 5, 'জাপান গার্ডেন সিটি', 'আব্দুল্লাহপুর', '1', '1'),
(6, 6, 'জাপান গার্ডেন সিটি', 'পোস্তাগোলা', '1', '1'),
(8, 8, 'কল্যানপুর', 'যশোর', '1', '1'),
(9, 9, 'বসিলা', 'আব্দুল্লাহপুর', '1', '1'),
(10, 10, 'তাজমহল রোড', 'মতিঝিল', '1', '1'),
(11, 11, 'মিরপুর-১', 'খিলগাও', '1', '1'),
(12, 12, 'শাপলা চত্তর', 'গাজিপুর', '1', '1'),
(13, 13, 'গাবতলী', 'মহাখালী', '1', '1'),
(14, 14, 'গাবতলী', 'সদরঘাট', '1', '1'),
(15, 15, 'Ghosh Para', 'Gabtoli', 'Daily morning and night', '1'),
(16, 16, 'মাজার রোড, গাবতলী', 'পূর্বাশা হল', 'প্রতিদিন সকাল এবং রাতে', '1'),
(17, 17, 'মাজার রোড, গাবতলী', 'কামার পাড়া বাসস্টান্ড', '1', '1'),
(18, 18, 'সাভার', 'সাইনবোর্ড', '1', '1'),
(19, 19, 'কামার পাড়া বাসস্টান্ড', 'টেকনিকাল', '1', '1'),
(20, 20, 'আগারগাও', 'আব্দুল্লাহপুর', '1', '1'),
(21, 21, 'মিরপুর-১২', 'গুলিস্তান', '1', '1'),
(22, 22, 'দুয়ারীপাড়া', 'ভিক্টোরিয়াপার্ক', '1', '1'),
(23, 23, 'মোহাম্মদপুর বাস স্টান্ড', 'বনশ্রী', '1', '1'),
(24, 24, 'মোহাম্মদপুর বাস স্টান্ড', 'নতুন বাজার', '1', '1'),
(25, 25, 'আসাদ গেট', 'নটরডেম কলেজ, আরামবাগ', '1', '1'),
(26, 26, 'মিরপুর-১ (চিড়িয়াখানা)', 'সদরঘাট', '1', '1'),
(27, 27, 'মতিঝিল', 'নতুন বাজার', '1', '1'),
(28, 28, 'মিরপুর-১২', 'সাইনবোর্ড', '1', '1'),
(29, 29, 'Pallabi (Mirpur-12)', 'Sadar ghat', '1', '1'),
(30, 30, 'Pallabi (BDR shooping master counter)', 'Jatrabari', '1', '1'),
(31, 31, 'সায়দাবাদ', 'শীববাড়ী', '1', '1'),
(32, 32, 'গাবতলী', 'গাজীপুর', '1', '1'),
(33, 33, 'ফুলবাড়িয়া', 'কালিয়াকৈর', '1', '1'),
(34, 34, 'Mirpur-14', 'Motijheel', '1', '1'),
(35, 35, 'গাবতলী', 'সদরঘাট', '1', '1'),
(36, 36, 'যাত্রাবাড়ী', 'চেরাগ আলী', '1', '1'),
(37, 37, 'জিরানী', 'সাইনবোর্ড', '1', '1'),
(38, 38, 'সদরঘাট', 'গাজীপুর', '1', '1'),
(39, 39, 'সদরঘাট', 'চেরাগ আলী', '1', '1'),
(40, 40, 'টাউন হল', 'নটরডেম কলেজ, আরামবাগ', '1', '1'),
(41, 41, 'মোহাম্মদপুর বাস স্টান্ড', 'নতুন বাজার', '1', '1'),
(42, 42, 'মোহাম্মদপুর বাস স্টান্ড', 'নটরডেম কলেজ, আরামবাগ', '1', '1'),
(43, 43, 'পলাশী এতিমখানা', 'হাউজবিল্ডিং', '1', '1'),
(44, 44, 'মোহাম্মদপুর বাস স্টান্ড', 'ধুপখোলা', '1', '1'),
(45, 45, 'মিরপুর-১২', 'আজিমপুর এতিমখানা', '1', '1'),
(46, 46, 'ইডেন কলেজ', 'কড়িল বিশ্বরোড', '1', '1'),
(47, 47, 'পল্লবী (মিরপুর-১২)', 'আব্দুল্লাহপুর', '1', '1'),
(48, 48, 'আজিমপুর', 'উত্তরা হাউজবিল্ডিং', '1', '1'),
(49, 49, 'জাহাজ কোম্পানী', 'কল্যানপুর', 'প্রতিদিন সকাল এবং রাতে', '1'),
(50, 50, 'মিরপুর-১২', 'শাপলা চত্তর', '1', '1'),
(51, 51, 'মিরপুর-১ (চিড়িয়াখানা)', 'কমলাপুর', '1', '1'),
(52, 52, 'মিরপুর-১২', 'মতিঝিল', '1', '1'),
(53, 53, 'গাবতলী', 'খিদমাহ হসপিটাল', '1', '1'),
(54, 54, 'মোহাম্মদপুর বাস স্টান্ড', 'খিলগাও', '1', '1'),
(55, 55, 'মিরপুর-১৪', 'তালতলা খিলগাও', '1', '1'),
(56, 56, 'ভাষানটেক মিরপুর', 'তালতলা খিলগাও', '1', '1'),
(57, 57, 'আসাদ গেট', 'দাদা মোড়', '1', '1'),
(58, 58, 'খেজুর বাগান ফার্মগেট', 'চন্দ্রা সাভার', '1', '1'),
(59, 59, 'পল্লবী (মিরপুর-১২)', 'ঢাকেশ্বরী মন্দির (আজিমপুর)', '1', '1'),
(60, 60, 'গাবতলী', 'বাড্ডা লিংক রোড', '1', '1'),
(61, 61, 'বৈশাখী মার্কেট (মিরুপর-১)', 'গোল চত্তর (যাত্রাবাড়ী)', '1', '1'),
(62, 62, 'মিরপুর-১ (চিড়িয়াখানা)', 'ইত্তেফাক (মতিঝিল)', '1', '1'),
(63, 63, 'গাবতলী', 'আব্দুল্লাহপুর', '1', '1'),
(64, 64, 'মিরপুর-১২', 'রায়েরবাগ (যাত্রাবাড়ী)', '1', '1'),
(65, 65, 'দুয়ারীপাড়া পল্লবী', 'ডেমরাঘাট', '1', '1'),
(66, 66, 'কিশোরগন্জ শহর', 'সায়দাবাদ বাস স্ট্রান্ড', '1', '1'),
(67, 67, 'কিশোরগন্জ শহর', 'মহাখালী বাস স্টান্ড', '1', '1'),
(68, 69, 'ভৈরব বাস স্টান্ড', 'মহাখালী বাস স্টান্ড', '1', '1'),
(69, 68, 'ভৈরব বাস স্টান্ড', 'মহাখালী বাস স্টান্ড', '1', '1'),
(70, 70, 'ধামরাই', 'ফুলবাড়িয়া গুলিস্তান', '1', '1'),
(71, 71, 'মোহাম্মদপুর বাস স্টান্ড', 'গুলশান', '1', '1'),
(72, 72, 'সাভার বাস স্টান্ড', 'নতুন বাজার', '1', '1'),
(73, 73, 'মিরপুর-১ (চিড়িয়াখানা)', 'বাবু বাজার ব্রিজ', '1', '1'),
(74, 74, 'সদরঘাট', 'চন্দ্রা', '1', '1'),
(75, 75, 'মিরপুর-১ (চিড়িয়াখানা)', 'রামপুরা বনশ্রী', '1', '1'),
(76, 76, 'মিরপুর-১ (চিড়িয়াখানা)', 'রামপুরা বনশ্রী', '1', '1'),
(77, 77, 'মিরপুর-১৪', 'কাকলী', '1', '1'),
(78, 78, 'ইপিজেড', 'শাপলা চত্তর', '1', '1'),
(79, 79, 'শিয়া মসজিদ', 'রায়েরবাগ (যাত্রাবাড়ী)', '1', '1'),
(80, 80, 'ইপিজেড', 'মিরপুর-১৪ বাসস্টান্ড', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `route_complains`
--

CREATE TABLE `route_complains` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `route_id` bigint(20) UNSIGNED NOT NULL,
  `fare_upvote` int(11) NOT NULL,
  `fare_downvote` int(11) NOT NULL,
  `distance` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `duration` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `route_points`
--

CREATE TABLE `route_points` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `route_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `point` tinyint(4) NOT NULL,
  `note` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `happened_at` datetime NOT NULL,
  `read` tinyint(4) NOT NULL DEFAULT '0',
  `notification_msg` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `action` enum('add','edit','translate') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'add'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `route_points`
--

INSERT INTO `route_points` (`id`, `route_id`, `user_id`, `point`, `note`, `happened_at`, `read`, `notification_msg`, `action`) VALUES
(1, 46, 6, 20, '', '2017-02-01 01:42:22', 0, 'Eearned <strong>20</strong> point for add route', 'add');

-- --------------------------------------------------------

--
-- Table structure for table `stoppages`
--

CREATE TABLE `stoppages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `place_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `comments` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `lat_long` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `rent` int(11) NOT NULL,
  `route_id` bigint(20) UNSIGNED NOT NULL,
  `position` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `stoppages`
--

INSERT INTO `stoppages` (`id`, `place_name`, `comments`, `lat_long`, `rent`, `route_id`, `position`) VALUES
(1, 'Shamoly', '', '', 5, 6, 1),
(2, 'Asad Gate', '', '', 10, 6, 2),
(3, 'Science Lab', '', '', 15, 6, 3),
(4, 'ShahBag', '', '', 20, 6, 4),
(5, 'Kakrail', '', '', 25, 6, 5),
(6, 'Fakirapul', '', '', 30, 6, 6),
(7, 'Bangladesh Bank', '', '', 30, 6, 7),
(8, 'Doyaganj Road', '', '', 35, 6, 8),
(9, 'Jurain', '', '', 40, 6, 9),
(10, 'Sony Hall', '', '', 10, 11, 1),
(11, 'Mirpur-2', '', '', 10, 11, 2),
(12, 'Mirpur-10', '', '', 10, 11, 3),
(13, 'Kazipara', '', '', 15, 11, 4),
(14, 'Shewrapara', '', '', 15, 11, 5),
(15, 'Agargaon', '', '', 15, 11, 6),
(16, 'Jahangir Gate', '', '', 20, 11, 7),
(17, 'Mohakhali', '', '', 20, 11, 8),
(18, 'Gulshan-1', '', '', 25, 11, 9),
(19, 'Badda', '', '', 25, 11, 10),
(20, 'East - Rampura', '', '', 30, 11, 11),
(21, 'Chowdhury Para', '', '', 30, 11, 12),
(22, 'Malibag Rail Gate', '', '', 35, 11, 13),
(23, 'Tongi', '', '', 20, 12, 1),
(24, 'Uttara', '', '', 25, 12, 2),
(25, 'Mohakhali', '', '', 30, 12, 3),
(26, 'Farmgate', '', '', 35, 12, 4),
(27, 'Shahbag', '', '', 40, 12, 5),
(28, 'Kallyanpur', '', '', 5, 13, 1),
(29, 'Shamoly', '', '', 5, 13, 2),
(30, 'Agargaon', '', '', 8, 13, 3),
(31, 'Jahangir gate', '', '', 10, 13, 4),
(32, 'Rangpur', 'sometimes take passenger. boarding may not possible', '', 50, 15, 1),
(33, 'Bogra', 'sometimes take passenger. boarding may not possible', '', 150, 15, 2),
(34, 'Sirajganj', 'sometimes take passenger. boarding not possible', '', 550, 15, 3),
(35, 'Tangail', '', '', 550, 15, 4),
(36, 'Gazipur', '', '', 550, 15, 5),
(37, 'Savar', '', '', 550, 15, 6),
(38, 'Majar Road', '', '', 550, 15, 7),
(39, 'Shamoly', '', '', 5, 14, 1),
(40, 'Asad gate', '', '', 8, 14, 2),
(41, 'Kalabagan', '', '', 10, 14, 3),
(42, 'Shahbag', '', '', 15, 14, 4),
(43, 'Gulistan', '', '', 20, 14, 5),
(44, 'Adabor', '', '', 5, 5, 1),
(45, 'Shamoly', '', '', 5, 5, 2),
(46, 'Shishu Mela', '', '', 10, 5, 3),
(47, 'Agargaon', '', '', 15, 5, 4),
(48, 'Shewrapara', '', '', 15, 5, 5),
(49, 'Kazipara', '', '', 15, 5, 6),
(50, 'Mirpur-10', '', '', 15, 5, 7),
(51, 'Purobi', '', '', 20, 5, 8),
(52, 'Kalshi', '', '', 20, 5, 9),
(53, 'Airport', '', '', 25, 5, 10),
(54, 'Uttara', '', '', 35, 5, 11),
(55, 'Hemayatpur', 'Fare not sure', '', 10, 18, 1),
(56, 'Gabtoli', 'Fare not sure', '', 20, 18, 2),
(57, 'Shamoly', '', '', 25, 18, 3),
(58, 'Farmgate', '', '', 30, 18, 4),
(59, 'Basabo', '', '', 35, 18, 5),
(60, 'Jatrabari', '', '', 40, 18, 6),
(61, 'Mohammadpur Tin rastar mor', '', '', 10, 9, 1),
(62, 'Mohammadpur Bus Stand', '', '', 15, 9, 2),
(63, 'Asad Gate', '', '', 15, 9, 3),
(64, 'Shamoly', '', '', 15, 9, 4),
(65, 'Darus Salam', '', '', 15, 9, 5),
(66, 'Mirpur-1', '', '', 15, 9, 6),
(67, 'Mirpur-10', '', '', 15, 9, 7),
(68, 'Kalshi', '', '', 20, 9, 8),
(69, 'Jashimuddin', '', '', 30, 9, 9),
(70, 'Rajlokhkhi', '', '', 35, 9, 10),
(71, 'Doulatdia', '', '', 550, 8, 1),
(72, 'Magura', '', '', 550, 8, 2),
(73, 'Khajura', '', '', 550, 8, 3),
(74, 'New market', '', '', 500, 8, 4),
(75, 'Shewrapara', 'Fare not sure', '', 5, 20, 1),
(76, 'Kazipara', 'Fare not sure', '', 10, 20, 2),
(77, 'Mirpur-10', 'Fare not sure', '', 10, 20, 3),
(78, 'Mirpur-11.1/2', 'Fare not sure', '', 10, 20, 4),
(79, 'Zia Kolony', 'Fare not sure', '', 15, 20, 5),
(80, 'Airport', 'Fare not sure', '', 20, 20, 6),
(81, 'Uttara', 'Fare not sure', '', 25, 20, 7),
(82, 'Mirpur-11', 'fare not sure', '', 10, 21, 1),
(83, 'Mirpur-10', 'fare not sure', '', 10, 21, 2),
(84, 'Kazipara', 'fare not sure', '', 10, 21, 3),
(85, 'Mirpur-11.1/2', '', '', 5, 22, 1),
(86, 'Mirpur-11', 'fare not sure', '', 10, 22, 2),
(87, 'Mirpur-10', '', '', 10, 22, 3),
(88, 'Kazipara', 'fare not sure', '', 10, 22, 4),
(89, 'Shewrapara', 'fare not sure', '', 10, 22, 5),
(90, 'Farmgate', 'fare not sure', '', 15, 22, 6),
(91, 'Shahbag', 'fare not sure', '', 20, 22, 7),
(92, 'Pressclub', 'fare not sure', '', 20, 22, 8),
(93, 'Bongobazar', 'fare not sure', '', 20, 22, 9),
(94, 'Golapshah majar, gulistan', 'fare not sure', '', 20, 22, 10),
(95, 'Rai saheb bazar', '', '', 25, 22, 11),
(96, 'Sankar', '', '', 10, 23, 1),
(97, 'Dhanmondi-15', '', '', 10, 23, 2),
(98, 'Jhigatola', '', '', 10, 23, 3),
(99, 'Science Lab', 'fare not sure', '', 10, 23, 4),
(100, 'Katabon', 'fare not sure', '', 10, 23, 5),
(101, 'Shahbag', 'fare not sure', '', 15, 23, 6),
(102, 'Kakrail', 'fare not sure', '', 15, 23, 7),
(103, 'Mouchak', 'fare not sure', '', 20, 23, 8),
(104, 'Malibag Rail Gate', 'fare not sure', '', 25, 23, 9),
(105, 'Rampura bazar', 'fare not sure', '', 25, 23, 10),
(106, 'Rampura bridge', 'fare not sure', '', 30, 23, 11),
(107, 'South banasree', 'fare', '', 35, 23, 12),
(108, 'Asad Gate', '', '', 5, 24, 1),
(109, 'Farmgate', 'fare not sure', '', 5, 24, 2),
(110, 'Mohakhali', 'fare not sure', '', 10, 24, 3),
(111, 'Titumir college', 'fare not sure', '', 10, 24, 4),
(112, 'Gulshan-1', 'fare not sure', '', 15, 24, 5),
(113, 'Badda', 'fare not sure', '', 20, 24, 6),
(114, 'Gaibandha', 'This is a via, passenger drop or pick not happen here', '', 1400, 19, 1),
(115, 'Bogra', 'This is a via, passenger drop or pick not happen here', '', 1400, 19, 2),
(116, 'Sirajganj', 'This is a via, passenger drop or pick not happen here', '', 1400, 19, 3),
(117, 'Jamuna Setu', 'This is a via, passenger drop or pick not happen here', '', 1400, 19, 4),
(118, 'Tangail', 'Same rent, passenger drop available', '', 1400, 19, 5),
(119, 'Savar', 'Same rent, passenger drop available', '', 1400, 19, 6),
(120, 'Majar road, gabtoli', 'Same rent, passenger drop available', '', 1400, 19, 7),
(121, 'Shankar', '', '', 10, 25, 1),
(122, 'Dhanmondi-15', '', '', 10, 25, 2),
(123, 'Jhigatola', '', '', 10, 25, 3),
(124, 'Science Lab', '', '', 10, 25, 4),
(125, 'Shahbag UBL', '', '', 15, 25, 5),
(126, 'Gulistan', '', '', 20, 25, 6),
(127, 'Motijheel', '', '', 25, 25, 7),
(128, 'Gulistan', 'fare not sure', '', 5, 27, 1),
(129, 'Paltan', 'fare not sure', '', 5, 27, 2),
(130, 'Malibag', 'fare not sure', '', 8, 27, 3),
(131, 'Mogbazar', 'fare not sure', '', 10, 27, 4),
(132, 'Kawran bazar', 'fare not sure', '', 15, 27, 5),
(133, 'Farmgate', 'fare not sure', '', 15, 27, 6),
(134, 'Bijoy sarani', 'fare not sure', '', 20, 27, 7),
(135, 'Mohakhali', 'fare not sure', '', 20, 27, 8),
(136, 'Gulshan-1', 'fare not sure', '', 25, 27, 9),
(137, 'Gulshan-2', 'fare not sure', '', 25, 27, 10),
(138, 'Darus salam', 'fare not sure', '', 5, 26, 1),
(139, 'Shamoly', 'fare not sure', '', 10, 26, 2),
(140, 'Asad Gate', 'fare not sure', '', 10, 26, 3),
(141, 'Farmgate', 'fare not sure', '', 15, 26, 4),
(142, 'Pressclub', 'fare not sure', '', 20, 26, 5),
(143, 'Gulistan', 'fare not sure', '', 25, 26, 6),
(144, 'Anik plaza (Mirpur-11.1/2)', 'fare not sure', '', 5, 29, 1),
(145, 'Mirpur-11', 'fare not sure', '', 5, 29, 2),
(146, 'Mirpur-10', 'fare not sure', '', 10, 29, 3),
(147, 'Kazipara', 'fare not sure', '', 10, 29, 4),
(148, 'Farmgate', 'fare not sure', '', 15, 29, 5),
(149, 'Pressclub', 'fare not sure', '', 20, 29, 6),
(150, 'T&t', 'fare not sure', '', 20, 29, 7),
(151, 'Rai saheb bazar', 'fare not sure', '', 25, 29, 8),
(152, 'Victoria park', 'fare not sure', '', 25, 29, 9),
(153, 'Motijheel', 'fare not sure', '', 10, 31, 1),
(154, 'Kamlapur', 'fare not sure', '', 10, 31, 2),
(155, 'Malibag', 'fare not sure', '', 10, 31, 3),
(156, 'Mogbazar', 'fare not sure', '', 15, 31, 4),
(157, 'Nabisco', 'fare not sure', '', 20, 31, 5),
(158, 'Mohakhali', 'fare not sure', '', 20, 31, 6),
(159, 'Banani', 'fare not sure', '', 20, 31, 7),
(160, 'Khilkhet', 'fare not sure', '', 20, 31, 8),
(161, 'Airport', 'fare not sure', '', 25, 31, 9),
(162, 'Uttara', 'fare not sure', '', 30, 31, 10),
(163, 'Tongi board bazar', 'fare not sure', '', 35, 31, 11),
(164, 'Mirpur-1', 'fare not sure', '', 10, 32, 1),
(165, 'Mirpur-10', 'fare not sure', '', 10, 32, 2),
(166, 'Mirpur-11', 'fare not sure', '', 10, 32, 3),
(167, 'Kalshi', 'fare not sure', '', 15, 32, 4),
(168, 'Bishwa road', 'fare not sure', '', 15, 32, 5),
(169, 'Airport', 'fare not sure', '', 20, 32, 6),
(170, 'Uttara', 'fare not sure', '', 25, 32, 7),
(171, 'Abdullahpur', 'fare not sure', '', 30, 32, 8),
(172, 'Gulistan', 'fare not sure', '', 10, 33, 1),
(173, 'Paltan', 'fare not sure', '', 10, 33, 2),
(174, 'Malibag', 'fare not sure', '', 15, 33, 3),
(175, 'Mogbazar', 'fare not sure', '', 15, 33, 4),
(176, 'Satrasta', 'fare not sure', '', 15, 33, 5),
(177, 'Nabisco', 'fare not sure', '', 15, 33, 6),
(178, 'Mohakhali', 'fare not sure', '', 20, 33, 7),
(179, 'Banani', 'fare not sure', '', 20, 33, 8),
(180, 'Airport', 'fare not sure', '', 25, 33, 9),
(181, 'Uttara', 'fare not sure', '', 30, 33, 10),
(182, 'Abdullahpur', 'fare not sure', '', 30, 33, 11),
(183, 'Tongi', 'fare not sure', '', 35, 33, 12),
(184, 'Gazipur', 'fare not sure', '', 40, 33, 13),
(185, 'Mirpur-10', 'fare not sure', '', 10, 34, 1),
(186, 'Mirpur-1', 'fare not sure', '', 10, 34, 2),
(187, 'Technical', 'fare not sure', '', 15, 34, 3),
(188, 'Shamoly', 'fare not sure', '', 20, 34, 4),
(189, 'Asad Gate', 'fare not sure', '', 20, 34, 5),
(190, 'Science Lab', 'fare not sure', '', 25, 34, 6),
(191, 'Katabon', 'fare not sure', '', 25, 34, 7),
(192, 'Shahbag', 'fare not sure', '', 25, 34, 8),
(193, 'Paltan', 'fare not sure', '', 30, 34, 9),
(194, 'Dainik bangla', 'fare not sure', '', 30, 34, 10),
(195, 'Notre dame', 'fare not sure', '', 35, 34, 11),
(196, 'Darus Salam', 'fare not sure', '', 5, 35, 1),
(197, 'Kallyanpur', 'fare not sure', '', 5, 35, 2),
(198, 'Shamoly', 'fare not sure', '', 5, 35, 3),
(199, 'Asad Gate', 'fare not sure', '', 10, 35, 4),
(200, 'Kalabagan', 'fare not sure', '', 10, 35, 5),
(201, 'Shahbag', 'fare not sure', '', 15, 35, 6),
(202, 'Gulistan', 'fare not sure', '', 20, 35, 7),
(203, 'Saidabad', 'fare not sure', '', 10, 36, 1),
(204, 'Mugda', 'fare not sure', '', 10, 36, 2),
(205, 'Basabo', 'fare not sure', '', 15, 36, 3),
(206, 'Khilgaon', 'fare not sure', '', 15, 36, 4),
(207, 'Malibag', 'fare not sure', '', 20, 36, 5),
(208, 'Rampura', 'fare not sure', '', 25, 36, 6),
(209, 'Khilkhet', 'fare not sure', '', 25, 36, 7),
(210, 'Airport', 'fare not sure', '', 25, 36, 8),
(211, 'Rajlokhkhi', 'fare not sure', '', 30, 36, 9),
(212, 'House Building', 'fare not sure', '', 35, 36, 10),
(213, 'Abdullahpur', 'fare not sure', '', 35, 36, 11),
(214, 'Gulistan', 'fare not sure', '', 10, 38, 1),
(215, 'Rampura', 'fare not sure', '', 10, 38, 2),
(216, 'Badda', 'fare not sure', '', 15, 38, 3),
(217, 'Bishwa road', 'fare not sure', '', 20, 38, 4),
(218, 'Airport', 'fare not sure', '', 25, 38, 5),
(219, 'Tongi', 'fare not sure', '', 30, 38, 6),
(220, 'Boikali hotel', 'fare not sure', '', 5, 30, 1),
(221, 'Mirpur-11', 'fare not sure', '', 5, 30, 2),
(222, 'Mirpur-10', 'fare not sure', '', 5, 30, 3),
(223, 'Kazipara', 'fare not sure', '', 10, 30, 4),
(224, 'Shewrapara', 'fare not sure', '', 10, 30, 5),
(225, 'Taltola', 'fare not sure', '', 10, 30, 6),
(226, 'Farmgate', 'fare not sure', '', 15, 30, 7),
(227, 'Shahbag', 'fare not sure', '', 15, 30, 8),
(228, 'Paltan', 'fare not sure', '', 20, 30, 9),
(229, 'Shapla chattor', 'fare not sure', '', 25, 30, 10),
(230, 'Ittafaq', 'fare not sure', '', 30, 30, 11),
(231, 'Saidabad', 'fare not sure', '', 35, 30, 12),
(232, 'Gulistan', 'fare not sure', '', 10, 39, 1),
(233, 'Kakrail', 'fare not sure', '', 10, 39, 2),
(234, 'Malibag', 'fare not sure', '', 15, 39, 3),
(235, 'Mogbazar', 'fare not sure', '', 20, 39, 4),
(236, 'Mohakhali', 'fare not sure', '', 25, 39, 5),
(237, 'Airport', 'fare not sure', '', 30, 39, 6),
(238, 'Abdullahpur', 'fare not sure', '', 35, 39, 7),
(239, 'Sankar', 'fare not sure', '', 10, 40, 1),
(240, 'Dhanmondi-15', 'fare not sure', '', 10, 40, 2),
(241, 'Jhigatola', 'fare not sure', '', 10, 40, 3),
(242, 'Science Lab', 'fare not sure', '', 15, 40, 4),
(243, 'Katabon', 'fare not sure', '', 20, 40, 5),
(244, 'Arambag', 'fare not sure', '', 25, 40, 6),
(245, 'Asad Gate', '', '', 5, 41, 1),
(246, 'Farmgate', '', '', 5, 41, 2),
(247, 'Bijoy sarani', '', '', 8, 41, 3),
(248, 'Mohakhali', '', '', 10, 41, 4),
(249, 'Gulshan-1', 'fare not sure', '', 15, 41, 5),
(250, 'Badda', 'fare not sure', '', 20, 41, 6),
(251, 'Asad Gate', 'fare not sure', '', 5, 42, 1),
(252, 'Kalabagan', 'fare not sure', '', 10, 42, 2),
(253, 'Science Lab', 'fare not sure', '', 15, 42, 3),
(254, 'Katabon', 'fare not sure', '', 15, 42, 4),
(255, 'Shahbag', 'fare not sure', '', 20, 42, 5),
(256, 'Pressclub', 'fare not sure', '', 25, 42, 6),
(257, 'Motijheel', 'fare not sure', '', 25, 42, 7),
(258, 'Azimpur', 'fare not sure', '', 5, 43, 1),
(259, 'Nilkhet', 'fare not sure', '', 5, 43, 2),
(260, 'City College', 'fare not sure', '', 10, 43, 3),
(261, 'Kalabagan', 'fare not sure', '', 15, 43, 4),
(262, 'Sukrabad', 'fare not sure', '', 15, 43, 5),
(263, 'Asad Gate', 'fare not sure', '', 20, 43, 6),
(264, 'Farmgate', 'fare not sure', '', 20, 43, 7),
(265, 'Mohakhali', 'fare not sure', '', 25, 43, 8),
(266, 'Banani/Kakoli', 'fare not sure', '', 30, 43, 9),
(267, 'Technical', '', '', 10, 3, 1),
(268, 'Kallyanpur', '', '', 10, 3, 2),
(269, 'Shamoly', '', '', 10, 3, 3),
(270, 'Agargaon', '', '', 15, 3, 4),
(271, 'Mohakhali', '', '', 20, 3, 5),
(272, 'Chairmenbari (Banani)', '', '', 20, 3, 6),
(273, 'Sainik Club (Banani)', '', '', 25, 3, 7),
(274, 'Kakoli', '', '', 25, 3, 8),
(275, 'Jashim Uddin (Uttara)', '', '', 30, 3, 9),
(276, 'Rajlokhkhi (Uttara)', '', '', 30, 3, 10),
(277, 'Sankar', 'fare not sure', '', 5, 44, 1),
(278, 'Dhanmondi-15', 'fare not sure', '', 5, 44, 2),
(279, 'Jhigatola', 'fare not sure', '', 10, 44, 3),
(280, 'Science Lab', 'fare not sure', '', 10, 44, 4),
(281, 'Shahbag', 'fare not sure', '', 15, 44, 5),
(282, 'Pressclub', 'fare not sure', '', 20, 44, 6),
(283, 'Gulistan', 'fare not sure', '', 23, 44, 7),
(284, 'Mirpur-11', 'fare not sure', '', 5, 45, 1),
(285, 'Mirpur-10', 'fare not sure', '', 10, 45, 2),
(286, 'Taltola', 'fare not sure', '', 10, 45, 3),
(287, 'Agargaon', 'fare not sure', '', 10, 45, 4),
(288, 'Shewrapara', 'fare not sure', '', 10, 45, 5),
(289, 'Kazipara', 'fare not sure', '', 15, 45, 6),
(290, 'Sukrabad', 'fare not sure', '', 15, 45, 7),
(291, 'Kalabagan', 'fare not sure', '', 20, 45, 8),
(292, 'Labaid', 'fare not sure', '', 20, 45, 9),
(293, 'New market', 'fare not sure', '', 20, 45, 10),
(294, 'Eden Mohilla College', 'fare not sure', '', 20, 45, 11),
(295, 'Azimpur', 'fare not sure', '', 5, 46, 1),
(296, 'New market', 'fare not sure', '', 5, 46, 2),
(297, 'City College', 'fare not sure', '', 8, 46, 3),
(298, 'Kalabagan', 'fare not sure', '', 10, 46, 4),
(299, 'Rasel Square', 'fare not sure', '', 15, 46, 5),
(300, 'Panthopath', 'fare not sure', '', 15, 46, 6),
(301, 'Kawran bazar', 'fare not sure', '', 15, 46, 7),
(302, 'Satrasta', 'fare not sure', '', 20, 46, 8),
(303, 'Nabisco', 'fare not sure', '', 20, 46, 9),
(304, 'Gulshan-1', 'fare not sure', '', 25, 46, 10),
(305, 'Mirpur-10', 'fare not sure', '', 5, 47, 1),
(306, 'Shewrapara', 'fare not sure', '', 10, 47, 2),
(307, 'Agargaon', 'fare not sure', '', 10, 47, 3),
(308, 'Mohakhali', 'fare not sure', '', 15, 47, 4),
(309, 'Banani/Kakoli', 'fare not sure', '', 15, 47, 5),
(310, 'Nikunja', 'fare not sure', '', 20, 47, 6),
(311, 'Khilkhet', 'fare not sure', '', 20, 47, 7),
(312, 'Airport', 'fare not sure', '', 25, 47, 8),
(313, 'Uttara', 'fare not sure', '', 30, 47, 9),
(314, 'Science Lab', 'fare not sure', '', 15, 48, 1),
(315, 'Shahbag', 'fare not sure', '', 15, 48, 2),
(316, 'Kakrail', 'fare not sure', '', 15, 48, 3),
(317, 'Mouchak', 'fare not sure', '', 20, 48, 4),
(318, 'Rampura', 'fare not sure', '', 20, 48, 5),
(319, 'Badda', 'fare not sure', '', 20, 48, 6),
(320, 'Baridhara', 'fare not sure', '', 25, 48, 7),
(321, 'Basundhara', 'fare not sure', '', 25, 48, 8),
(322, 'Kuril Bishwa Road', 'fare not sure', '', 25, 48, 9),
(323, 'Airport', 'fare not sure', '', 30, 48, 10),
(324, 'Gabindaganj', 'passenger not taken here. fare not sure', '', 780, 49, 1),
(325, 'Bogra', 'passenger not taken here. fare not sure', '', 780, 49, 2),
(326, 'Sirajganj', 'passenger not taken here. fare not sure', '', 780, 49, 3),
(327, 'Tangail', 'passenger not taken here. fare not sure', '', 780, 49, 4),
(328, 'Savar', 'passenger not taken here. fare not sure', '', 780, 49, 5),
(329, 'Technical', 'passenger not taken here. fare not sure', '', 780, 49, 6),
(330, 'Mirpur-10', 'fare not sure', '', 5, 50, 1),
(331, 'Kazipara', 'fare not sure', '', 5, 50, 2),
(332, 'Shewrapara', 'fare not sure', '', 10, 50, 3),
(333, 'Taltola', 'fare not sure', '', 10, 50, 4),
(334, 'Agargaon', 'fare not sure', '', 10, 50, 5),
(335, 'Bijoy sarani', 'fare not sure', '', 15, 50, 6),
(336, 'Farmgate', 'fare not sure', '', 15, 50, 7),
(337, 'Kawran bazar', 'fare not sure', '', 20, 50, 8),
(338, 'Shahbag', 'fare not sure', '', 20, 50, 9),
(339, 'Motsa Bhaban', 'fare not sure', '', 20, 50, 10),
(340, 'Paltan', 'fare not sure', '', 20, 50, 11),
(341, 'Gulistan', 'fare not sure', '', 25, 50, 12),
(342, 'Adamji', 'fare not sure', '', 25, 50, 13),
(343, 'Mirpur-2', 'fare not sure', '', 5, 51, 1),
(344, 'Mirpur-10', 'fare not sure', '', 5, 51, 2),
(345, 'Kazipara', 'fare not sure', '', 8, 51, 3),
(346, 'Shewrapara', 'fare not sure', '', 10, 51, 4),
(347, 'Agargaon', 'fare not sure', '', 10, 51, 5),
(348, 'Bijoy sarani (Chandrima Uddyan)', 'fare not sure', '', 10, 51, 6),
(349, 'Farmgate', 'fare not sure', '', 15, 51, 7),
(350, 'Bangla motor', 'fare not sure', '', 15, 51, 8),
(351, 'Mogbazar', 'fare not sure', '', 20, 51, 9),
(352, 'Malibag', 'fare not sure', '', 25, 51, 10),
(353, 'Mirpur-11', 'Fare not sure', '', 5, 52, 1),
(354, 'Mirpur-10', 'Fare not sure', '', 8, 52, 2),
(355, 'Kazipara', 'Fare not sure', '', 10, 52, 3),
(356, 'Shewrapara', 'Fare not sure', '', 10, 52, 4),
(357, 'Agargaon', 'Fare not sure', '', 12, 52, 5),
(358, 'Farmgate', 'Fare not sure', '', 15, 52, 6),
(359, 'Pressclub', 'Fare not sure', '', 20, 52, 7),
(360, 'Gulistan', 'Fare not sure', '', 25, 52, 8),
(361, 'Bangla College (Mirpur-1)', 'Fare not sure', '', 5, 53, 1),
(362, 'Mirpur-1', 'Fare not sure', '', 10, 53, 2),
(363, 'Kazipara', 'Fare not sure', '', 15, 53, 3),
(364, 'Shewrapara', 'Fare not sure', '', 15, 53, 4),
(365, 'Agargaon', 'Fare not sure', '', 15, 53, 5),
(366, 'Mohakhali', 'Fare not sure', '', 20, 53, 6),
(367, 'Titumir college', 'Fare not sure', '', 20, 53, 7),
(368, 'Gulshan-2', 'Fare not sure', '', 25, 53, 8),
(369, 'Khilgaon', 'Fare not sure', '', 30, 53, 9),
(370, 'Physical College (Dhanmondi)', 'Fare not sure', '', 5, 54, 1),
(371, 'Dhanmondi-27', 'Fare not sure', '', 5, 54, 2),
(372, 'Sankar', 'Fare not sure', '', 8, 54, 3),
(373, 'Abahoni mat', 'Fare not sure', '', 5, 54, 4),
(374, 'Dhanmondi-15', 'Fare not sure', '', 10, 54, 5),
(375, 'Jhigatola', 'Fare not sure', '', 12, 54, 6),
(376, 'City College', 'Fare not sure', '', 12, 54, 7),
(377, 'Science Lab', 'Fare not sure', '', 15, 54, 8),
(378, 'Bata Signal', 'Fare not sure', '', 20, 54, 9),
(379, 'Elephant Road', 'Fare not sure', '', 20, 54, 10),
(380, 'Katabon', 'Fare not sure', '', 20, 54, 11),
(381, 'Shahbag', 'Fare not sure', '', 20, 54, 12),
(382, 'Motsa Bhaban', 'Fare not sure', '', 20, 54, 13),
(383, 'Pressclub', 'Fare not sure', '', 25, 54, 14),
(384, 'Paltan', 'Fare not sure', '', 25, 54, 15),
(385, 'GPO (Paltan)', 'Fare not sure', '', 25, 54, 16),
(386, 'Hockey Stadium', 'Fare not sure', '', 25, 54, 17),
(387, 'Gulistan', 'Fare not sure', '', 30, 54, 18),
(388, 'Motijheel', 'Fare not sure', '', 35, 54, 19),
(389, 'Kamlapur', 'Fare not sure', '', 35, 54, 20),
(390, 'Mugda', 'Fare not sure', '', 35, 54, 21),
(391, 'Basabo', 'Fare not sure', '', 40, 54, 22),
(392, 'Bodhdhya Mondir', 'Fare not sure', '', 40, 54, 23),
(393, 'Mirpur-13', 'Fare not sure', '', 5, 55, 1),
(394, 'Mirpur-10', 'Fare not sure', '', 5, 55, 2),
(395, 'Mirpur-2', 'Fare not sure', '', 5, 55, 3),
(396, 'Mirpur-1', 'Fare not sure', '', 8, 55, 4),
(397, 'Ansar camp', 'Fare not sure', '', 8, 55, 5),
(398, 'Technical', 'Fare not sure', '', 10, 55, 6),
(399, 'Kallyanpur', 'Fare not sure', '', 10, 55, 7),
(400, 'Shamoly', 'Fare not sure', '', 10, 55, 8),
(401, 'College gate', 'Fare not sure', '', 10, 55, 9),
(402, 'Asad Gate', 'Fare not sure', '', 15, 55, 10),
(403, 'Dhanmondi', 'Fare not sure', '', 15, 55, 11),
(404, 'Sukrabad', 'Fare not sure', '', 20, 55, 12),
(405, 'Kalabagan', 'Fare not sure', '', 20, 55, 13),
(406, 'Science Lab', 'Fare not sure', '', 25, 55, 14),
(407, 'Katabon', 'Fare not sure', '', 25, 55, 15),
(408, 'Shahbag', 'Fare not sure', '', 25, 55, 16),
(409, 'Pressclub', 'Fare not sure', '', 30, 55, 17),
(410, 'Dainik bangla', 'Fare not sure', '', 30, 55, 18),
(411, 'Shapla chattor', 'Fare not sure', '', 35, 55, 19),
(412, 'Kamlapur', 'Fare not sure', '', 35, 55, 20),
(413, 'Basabo', 'Fare not sure', '', 40, 55, 21),
(414, 'Khilgaon', 'Fare not sure', '', 40, 55, 22),
(415, 'Sankar', 'fare not sure', '', 10, 10, 1),
(416, 'Dhanmondi-15', 'fare not sure', '', 10, 10, 2),
(417, 'Jhigatola', 'fare not sure', '', 10, 10, 3),
(418, 'Science Lab', 'fare not sure', '', 15, 10, 4),
(419, 'Shahbag', 'fare not sure', '', 15, 10, 5),
(420, 'Pressclub', 'fare not sure', '', 20, 10, 6),
(421, 'Gulistan', 'fare not sure', '', 25, 10, 7),
(422, 'Mirpur-14', 'Fare not sure', '', 5, 56, 1),
(423, 'Mirpur-10', 'Fare not sure', '', 5, 56, 2),
(424, 'Mirpur-2', 'Fare not sure', '', 8, 56, 3),
(425, 'Mirpur-1', 'Fare not sure', '', 8, 56, 4),
(426, 'Technical', 'Fare not sure', '', 10, 56, 5),
(427, 'Darus Salam', 'Fare not sure', '', 10, 56, 6),
(428, 'Kallyanpur', 'Fare not sure', '', 10, 56, 7),
(429, 'Shamoly', 'Fare not sure', '', 12, 56, 8),
(430, 'College gate', 'Fare not sure', '', 15, 56, 9),
(431, 'Asad Gate', 'Fare not sure', '', 15, 56, 10),
(432, 'Sukrabad', 'Fare not sure', '', 20, 56, 11),
(433, 'Kalabagan', 'Fare not sure', '', 20, 56, 12),
(434, 'Science Lab', 'Fare not sure', '', 25, 56, 13),
(435, 'Shahbag', 'Fare not sure', '', 25, 56, 14),
(436, 'Pressclub', 'Fare not sure', '', 30, 56, 15),
(437, 'Gulistan', 'Fare not sure', '', 30, 56, 16),
(438, 'Motijheel', 'Fare not sure', '', 30, 56, 17),
(439, 'Kamlapur', 'Fare not sure', '', 35, 56, 18),
(440, 'Mugda', 'Fare not sure', '', 35, 56, 19),
(441, 'Basabo', 'Fare not sure', '', 40, 56, 20),
(442, 'Mirpur-12', 'fare not sure', '', 5, 28, 1),
(443, 'Mirpur-11', 'fare not sure', '', 10, 28, 2),
(444, 'Mirpur-10', 'fare not sure', '', 10, 28, 3),
(445, 'Kazipara', 'fare not sure', '', 10, 28, 4),
(446, 'Shewrapara', 'fare not sure', '', 15, 28, 5),
(447, 'Agargaon', 'fare not sure', '', 15, 28, 6),
(448, 'Bijoy sarani', 'fare not sure', '', 15, 28, 7),
(449, 'Farmgate', 'fare not sure', '', 15, 28, 8),
(450, 'Kawran bazar', 'fare not sure', '', 20, 28, 9),
(451, 'ShahBag', 'fare not sure', '', 20, 28, 10),
(452, 'Pressclub', 'fare not sure', '', 20, 28, 11),
(453, 'Gulistan', 'fare not sure', '', 25, 28, 12),
(454, 'Bangabhaban', 'fare not sure', '', 25, 28, 13),
(455, 'Saidabad', 'fare not sure', '', 30, 28, 14),
(456, 'Savar', 'Passenger not drop here.', '', 550, 57, 1),
(457, 'Tangail', 'Passenger not drop here.', '', 550, 57, 2),
(458, 'Gazipur', 'Passenger not drop here.', '', 550, 57, 3),
(459, 'Sirajganj', 'Passenger not drop here.', '', 550, 57, 4),
(460, 'Jamuna Setu', 'Passenger not drop here.', '', 550, 57, 5),
(461, 'Food Village, Bogra', 'Passenger not drop here.', '', 550, 57, 6),
(462, 'Gaibandha', 'Passenger not drop here.', '', 550, 57, 7),
(463, 'Modern Mor, Rangpur', '', '', 550, 57, 8),
(464, 'Mostafi,Rangpur', '', '', 550, 57, 9),
(465, 'Borobari,Lalmonirhat', '', '', 550, 57, 10),
(466, 'Titsta Bridge, Lalmonirhat', '', '', 550, 57, 11),
(467, 'Kathal bari, Kurigram', '', '', 550, 57, 12),
(468, 'Khalilganj Bazar, Kurigram', '', '', 550, 57, 13),
(469, 'Technical', 'passenger not drop here', '', 550, 16, 1),
(470, 'Savar', 'passenger not drop here', '', 550, 16, 2),
(471, 'Tangail', 'passenger not drop here', '', 550, 16, 3),
(472, 'Gazipur', 'passenger not drop here', '', 550, 16, 4),
(473, 'Sirajganj', 'passenger not drop here', '', 550, 16, 5),
(474, 'Bogra', 'passenger not drop here', '', 550, 16, 6),
(475, 'Gaibandha', 'passenger not drop here', '', 550, 16, 7),
(476, 'Modern Mor, Rangpur', '', '', 550, 16, 8),
(477, 'Borobari,Lalmonirhat', '', '', 550, 16, 9),
(478, 'Tista Bridge, Lalmonirhat', '', '', 550, 16, 10),
(479, 'Kathal bari, Kurigram', '', '', 550, 16, 11),
(480, 'Khalilganj Bazar, Kurigram', '', '', 550, 16, 12),
(481, 'Mirpur-10', 'fare not sure', '', 5, 58, 1),
(482, 'Mirpur-2', 'fare not sure', '', 10, 58, 2),
(483, 'Mirpur-1', 'fare not sure', '', 10, 58, 3),
(484, 'Majar Road', 'fare not sure', '', 10, 58, 4),
(485, 'Diabari', 'fare not sure', '', 10, 58, 5),
(486, 'Birulia', 'fare not sure', '', 10, 58, 6),
(487, 'Beribadh', 'fare not sure', '', 10, 58, 7),
(488, 'Dhaur', 'fare not sure', '', 15, 58, 8),
(489, 'Asulia', 'fare not sure', '', 20, 58, 9),
(490, 'Fantasy Kingdom', 'fare not sure', '', 25, 58, 10),
(491, 'Bypile', 'fare not sure', '', 30, 58, 11),
(492, 'Jirani', 'fare not sure', '', 35, 58, 12),
(493, 'Nandan Park', 'fare not sure', '', 40, 58, 13),
(494, 'Mirpur-11', 'fare not sure', '', 5, 59, 1),
(495, 'Mirpur-10', 'fare not sure', '', 5, 59, 2),
(496, 'Mirpur-2', 'fare not sure', '', 5, 59, 3),
(497, 'Mirpur-1', 'fare not sure', '', 10, 59, 4),
(498, 'Ansar camp', 'fare not sure', '', 10, 59, 5),
(499, 'Bangla College (Mirpur-1)', 'fare not sure', '', 10, 59, 6),
(500, 'Technical', 'fare not sure', '', 10, 59, 7),
(501, 'Darus Salam', 'fare not sure', '', 10, 59, 8),
(502, 'Kallyanpur', 'fare not sure', '', 10, 59, 9),
(503, 'Shamoly', 'fare not sure', '', 15, 59, 10),
(504, 'Asad Gate', 'fare not sure', '', 15, 59, 11),
(505, 'Sukrabad', 'fare not sure', '', 15, 59, 12),
(506, 'Kalabagan', 'fare not sure', '', 20, 59, 13),
(507, 'Science Lab', 'fare not sure', '', 20, 59, 14),
(508, 'New market', 'fare not sure', '', 25, 59, 15),
(509, 'Mirpur-1', 'fare not sure', '', 5, 60, 1),
(510, 'Mirpur-10', 'fare not sure', '', 5, 60, 2),
(511, 'Purobi', 'fare not sure', '', 5, 60, 3),
(512, 'Kalshi', 'fare not sure', '', 10, 60, 4),
(513, 'Matikata Flyover', 'fare not sure', '', 10, 60, 5),
(514, 'Mohakhali', 'fare not sure', '', 10, 60, 6),
(515, 'Banani/Kakoli', 'fare not sure', '', 15, 60, 7),
(516, 'Gulshan-2', 'fare not sure', '', 15, 60, 8),
(517, 'Gulshan-1', 'fare not sure', '', 20, 60, 9),
(518, 'Badda', 'fare not sure', '', 20, 60, 10),
(519, 'Rampura', 'fare not sure', '', 25, 60, 11),
(520, 'Ansar camp (Mirpur-1)', 'fare not sure', '', 5, 61, 1),
(521, 'Technical', 'fare not sure', '', 5, 61, 2),
(522, 'Darus Salam', 'fare not sure', '', 5, 61, 3),
(523, 'Kallyanpur', 'fare not sure', '', 5, 61, 4),
(524, 'Shamoly', 'fare not sure', '', 8, 61, 5),
(525, 'College gate', 'fare not sure', '', 10, 61, 6),
(526, 'Sukrabad', 'fare not sure', '', 10, 61, 7),
(527, 'Kalabagan', 'fare not sure', '', 15, 61, 8),
(528, 'Science Lab', 'fare not sure', '', 15, 61, 9),
(529, 'Katabon', 'fare not sure', '', 15, 61, 10),
(530, 'ShahBag', 'fare not sure', '', 20, 61, 11),
(531, 'Pressclub', 'fare not sure', '', 20, 61, 12),
(532, 'Gulistan Mor', 'fare not sure', '', 20, 61, 13),
(533, 'Bangladesh Bank (Motijheel)', 'fare not sure', '', 25, 61, 14),
(534, 'Jatrabari', 'fare not sure', '', 30, 61, 15),
(535, 'Ansar camp (Mirpur-1)', 'fare not sure', '', 5, 62, 1),
(536, 'Technical', 'fare not sure', '', 5, 62, 2),
(537, 'Darus Salam', 'fare not sure', '', 5, 62, 3),
(538, 'Kallyanpur', 'fare not sure', '', 5, 62, 4),
(539, 'Shamoly', 'fare not sure', '', 10, 62, 5),
(540, 'College gate', 'fare not sure', '', 10, 62, 6),
(541, 'Asad Gate', 'fare not sure', '', 10, 62, 7),
(542, 'Farmgate', 'fare not sure', '', 15, 62, 8),
(543, 'Kawran bazar', 'fare not sure', '', 15, 62, 9),
(544, 'ShahBag', 'fare not sure', '', 15, 62, 10),
(545, 'Pressclub', 'fare not sure', '', 20, 62, 11),
(546, 'Motijheel', 'fare not sure', '', 25, 62, 12),
(547, 'Technical', 'fare not sure', '', 5, 63, 1),
(548, 'Darus Salam', 'fare not sure', '', 5, 63, 2),
(549, 'Kallyanpur', 'fare not sure', '', 10, 63, 3),
(550, 'Shamoly', 'fare not sure', '', 15, 63, 4),
(551, 'Agargaon', 'fare not sure', '', 15, 63, 5),
(552, 'Jahangir Gate', 'fare not sure', '', 20, 63, 6),
(553, 'Mohakhali', 'fare not sure', '', 20, 63, 7),
(554, 'Banani/Kakoli', 'fare not sure', '', 25, 63, 8),
(555, 'Uttara', 'fare not sure', '', 30, 63, 9),
(556, 'Anik plaza (Mirpur-11.1/2)', 'fare not sure', '', 5, 64, 1),
(557, 'Mirpur-11', 'fare not sure', '', 5, 64, 2),
(558, 'Mirpur-10', 'fare not sure', '', 5, 64, 3),
(559, 'Kazipara', 'fare not sure', '', 10, 64, 4),
(560, 'Shewrapara', 'fare not sure', '', 10, 64, 5),
(561, 'Farmgate', 'fare not sure', '', 10, 64, 6),
(562, 'Pressclub', 'fare not sure', '', 10, 64, 7),
(563, 'Gulistan', 'fare not sure', '', 20, 64, 8),
(564, 'Ahadbox', 'fare not sure', '', 20, 64, 9),
(565, 'Saidabad', 'fare not sure', '', 25, 64, 10),
(566, 'Jatrabari', 'fare not sure', '', 30, 64, 11),
(567, 'Mirpur-10', 'fare not sure', '', 5, 65, 1),
(568, 'Khejur bagan (Farmgate)', 'fare not sure', '', 5, 65, 2),
(569, 'ShahBag', 'fare not sure', '', 15, 65, 3),
(570, 'Pressclub', 'fare not sure', '', 15, 65, 4),
(571, 'Dainik bangla', 'fare not sure', '', 15, 65, 5),
(572, 'Fakirapul', 'fare not sure', '', 20, 65, 6),
(573, 'Bangladesh Bank (Motijheel)', 'fare not sure', '', 20, 65, 7),
(574, 'Ittafaq', 'fare not sure', '', 20, 65, 8),
(575, 'Jatrabari', 'fare not sure', '', 25, 65, 9),
(576, 'Saidabad', 'fare not sure', '', 25, 65, 10),
(577, 'Chittagong Road', 'fare not sure', '', 30, 65, 11),
(578, 'Katiadi', 'fare not sure', '', 300, 66, 1),
(579, 'Kuliarchor', 'fare not sure', '', 300, 66, 2),
(580, 'Bhairab', 'fare not sure', '', 300, 66, 3),
(581, 'Narshingdi', 'fare not sure', '', 300, 66, 4),
(582, 'Narayanganj', 'fare not sure', '', 300, 66, 5),
(583, 'Chittagong Road', 'fare not sure', '', 300, 66, 6),
(584, 'Katiadi', 'fare not sure', '', 300, 67, 1),
(585, 'Kuliarchor', 'fare not sure', '', 300, 67, 2),
(586, 'Bhairab', 'fare not sure', '', 300, 67, 3),
(587, 'Narshingdi', 'fare not sure', '', 300, 67, 4),
(588, 'Narayanganj', 'fare not sure', '', 300, 67, 5),
(589, 'Gazipur Chowrasta', 'fare not sure', '', 300, 67, 6),
(590, 'Abdullahpur', 'fare not sure', '', 300, 67, 7),
(591, 'Mohakhali', 'fare not sure', '', 300, 67, 8),
(592, 'Belabo', 'fare not sure', '', 200, 68, 1),
(593, 'Narshingdi', 'fare not sure', '', 200, 68, 2),
(594, 'Narayanganj', 'fare not sure', '', 200, 68, 3),
(595, 'Gazipur Chowrasta', 'fare not sure', '', 200, 68, 4),
(596, 'Abdullahpur', 'fare not sure', '', 200, 68, 5),
(597, 'Mohakhali', 'fare not sure', '', 200, 68, 6),
(598, 'Belabo', 'fare not sure', '', 200, 69, 1),
(599, 'Narshingdi', 'fare not sure', '', 200, 69, 2),
(600, 'Narayanganj', 'fare not sure', '', 200, 69, 3),
(601, 'Gazipur Chowrasta', 'fare not sure', '', 200, 69, 4),
(602, 'Abdullahpur', 'fare not sure', '', 200, 69, 5),
(603, 'Mohakhali', 'fare not sure', '', 200, 69, 6),
(604, 'Khalilganj Bazar, Kurigram', 'same rent, passenger not drop here', '', 550, 4, 1),
(605, 'Kathal bari, Kurigram', 'same rent, passenger not drop here', '', 550, 4, 2),
(606, 'Tista Bridge, Lalmonirhat', 'same rent, passenger not drop here', '', 550, 4, 3),
(607, 'Modern Mor, Rangpur', '', '', 550, 4, 4),
(608, 'Gaibandha', '', '', 550, 4, 5),
(609, 'Food Village, Bogra', '', '', 550, 4, 6),
(610, 'Sirajganj', '', '', 550, 4, 7),
(611, 'Tangail', '', '', 550, 4, 8),
(612, 'Gazipur', '', '', 550, 4, 9),
(613, 'Savar', '', '', 550, 4, 10),
(614, 'Technical', '', '', 550, 4, 11),
(615, 'Nabinagar', 'fare not sure', '', 15, 70, 1),
(616, 'Jahangirnagar University', 'fare not sure', '', 15, 70, 2),
(617, 'Savar', 'fare not sure', '', 20, 70, 3),
(618, 'Hemayatpur (Savar)', 'fare not sure', '', 25, 70, 4),
(619, 'Technical', 'fare not sure', '', 30, 70, 5),
(620, 'Darus Salam', 'fare not sure', '', 30, 70, 6),
(621, 'Kallyanpur', 'fare not sure', '', 30, 70, 7),
(622, 'Shamoly', 'fare not sure', '', 30, 70, 8),
(623, 'Asad Gate', 'fare not sure', '', 35, 70, 9),
(624, 'Kalabagan', 'fare not sure', '', 40, 70, 10),
(625, 'Science Lab', 'fare not sure', '', 40, 70, 11),
(626, 'New market', 'fare not sure', '', 45, 70, 12),
(627, 'Gulistan', 'fare not sure', '', 50, 70, 13),
(628, 'EPZ', 'fare not sure', '', 5, 37, 1),
(629, 'Nabinagar', 'fare not sure', '', 10, 37, 2),
(630, 'Savar', 'fare not sure', '', 10, 37, 3),
(631, 'Technical', 'fare not sure', '', 15, 37, 4),
(632, 'Gabtoli', 'fare not sure', '', 15, 37, 5),
(633, 'Darus Salam', 'fare not sure', '', 20, 37, 6),
(634, 'Kalabagan', 'fare not sure', '', 20, 37, 7),
(635, 'New market', 'fare not sure', '', 25, 37, 8),
(636, 'Chankharpul', 'fare not sure', '', 30, 37, 9),
(637, 'Gulistan', 'fare not sure', '', 35, 37, 10),
(638, 'Saidabad', 'fare not sure', '', 40, 37, 11),
(639, 'Town Hall', '', '', 5, 71, 1),
(640, 'Asad Gate', '', '', 5, 71, 2),
(641, 'Farmgate', '', '', 8, 71, 3),
(642, 'Mohakhali', '', '', 10, 71, 4),
(643, 'Titumir college', '', '', 12, 71, 5),
(644, 'Gulshan-1', '', '', 15, 71, 6),
(645, 'Hemayatpur (Savar)', 'fare not sure', '', 10, 72, 1),
(646, 'Amin Bazar', 'fare not sure', '', 10, 72, 2),
(647, 'Gabtoli', 'fare not sure', '', 15, 72, 3),
(648, 'Technical', 'fare not sure', '', 15, 72, 4),
(649, 'Darus Salam', 'fare not sure', '', 15, 72, 5),
(650, 'Kallyanpur', 'fare not sure', '', 15, 72, 6),
(651, 'Shamoly', 'fare not sure', '', 20, 72, 7),
(652, 'Shishu Mela', 'fare not sure', '', 20, 72, 8),
(653, 'Agargaon', 'fare not sure', '', 20, 72, 9),
(654, 'Mohakhali', 'fare not sure', '', 25, 72, 10),
(655, 'Gulshan-1', 'fare not sure', '', 30, 72, 11),
(656, 'Ansar camp (Mirpur-1)', 'fare not sure', '', 5, 73, 1),
(657, 'Farmgate', 'fare not sure', '', 10, 73, 2),
(658, 'Golapshah majar, gulistan', 'fare not sure', '', 20, 73, 3),
(659, 'Fulbaria', 'fare not sure', '', 20, 73, 4),
(660, 'Nayabazar', 'fare not sure', '', 25, 73, 5),
(661, 'Keraniganj', 'fare not sure', '', 30, 73, 6),
(662, 'Gulistan', 'fare not sure', '', 10, 74, 1),
(663, 'Paltan', 'fare not sure', '', 10, 74, 2),
(664, 'Kakrail', 'fare not sure', '', 15, 74, 3),
(665, 'Malibag', 'fare not sure', '', 15, 74, 4),
(666, 'Mogbazar', 'fare not sure', '', 15, 74, 5),
(667, 'Mohakhali', 'fare not sure', '', 20, 74, 6),
(668, 'Airport', 'fare not sure', '', 25, 74, 7),
(669, 'Abdullahpur', 'fare not sure', '', 30, 74, 8),
(670, 'Tongi', 'fare not sure', '', 35, 74, 9),
(671, 'Gazipur Bypass', 'fare not sure', '', 40, 74, 10),
(672, 'Mirpur-1', 'fare not sure', '', 5, 75, 1),
(673, 'Mirpur-2', 'fare not sure', '', 5, 75, 2),
(674, 'Mirpur-10', 'fare not sure', '', 10, 75, 3),
(675, 'Mirpur-12', 'fare not sure', '', 10, 75, 4),
(676, 'Kalshi', 'fare not sure', '', 10, 75, 5),
(677, 'Kuril', 'fare not sure', '', 15, 75, 6),
(678, 'Norda', 'fare not sure', '', 20, 75, 7),
(679, 'Natun bazar', 'fare not sure', '', 25, 75, 8),
(680, 'Badda', 'fare not sure', '', 30, 75, 9),
(681, 'Hatirjhil', 'fare not sure', '', 35, 75, 10),
(682, 'Mirpur-1', 'fare not sure', '', 5, 76, 1),
(683, 'Mirpur-2', 'fare not sure', '', 5, 76, 2),
(684, 'Mirpur-10', 'fare not sure', '', 10, 76, 3),
(685, 'Mirpur-12', 'fare not sure', '', 10, 76, 4),
(686, 'Kalshi', 'fare not sure', '', 10, 76, 5),
(687, 'Kuril', 'fare not sure', '', 15, 76, 6),
(688, 'Norda', 'fare not sure', '', 20, 76, 7),
(689, 'Natun bazar', 'fare not sure', '', 25, 76, 8),
(690, 'Badda', 'fare not sure', '', 30, 76, 9),
(691, 'Hatirjhil', 'fare not sure', '', 35, 76, 10),
(692, 'Adabor', 'Normally passenger not taken from here', '', 5, 2, 1),
(693, 'Shamoly', 'Normally passenger not taken from here', '', 5, 2, 2),
(694, 'Agargaon', 'Normally passenger not taken from here', '', 15, 2, 3),
(695, 'Mohakhali', '', '', 20, 2, 4),
(696, 'Amtoli', '', '', 25, 2, 5),
(697, 'Chairmenbari (Banani)', '', '', 25, 2, 6),
(698, 'Sainik Club (Banani)', '', '', 25, 2, 7),
(699, 'Kakoli', '', '', 25, 2, 8),
(700, 'JashimUddin (Uttara)', '', '', 30, 2, 9),
(701, 'Rajlokhkhi (Uttara)', '', '', 30, 2, 10),
(702, 'Technical', '', '', 5, 1, 1),
(703, 'Darus salam', '', '', 5, 1, 2),
(704, 'Kallyanpur', '', '', 7, 1, 3),
(705, 'Shamoly', '', '', 8, 1, 4),
(706, 'Adabor', '', '', 10, 1, 5),
(707, 'Krishi market', '', '', 0, 1, 6),
(708, 'Shia Mashjid', '', '', 0, 1, 7),
(709, 'Allah Karim Mashjid', '', '', 0, 1, 8),
(710, 'Dhanmondi', '', '', 0, 1, 9),
(711, 'Gaibandha', '', '', 550, 17, 1),
(712, 'Bogra', '', '', 550, 17, 2),
(713, 'Sirajganj', '', '', 0, 17, 3),
(714, 'Tangail', '', '', 0, 17, 4),
(715, 'Gazipur', '', '', 0, 17, 5),
(716, 'Savar', '', '', 0, 17, 6),
(717, 'Kachukhet', 'fare not sure', '', 10, 77, 1),
(718, 'Sainik Club (Banani)', 'fare not sure', '', 12, 77, 2),
(719, 'Kakoli', 'fare not sure', '', 12, 77, 3),
(720, 'Mohakhali', 'fare not sure', '', 15, 77, 4),
(721, 'Savar Bazar', 'fare not sure', '', 5, 78, 1),
(722, 'Hemayatpur (Savar)', 'fare not sure', '', 10, 78, 2),
(723, 'Amin Bazar', 'fare not sure', '', 15, 78, 3),
(724, 'Gabtoli', 'fare not sure', '', 15, 78, 4),
(725, 'Technical', 'fare not sure', '', 15, 78, 5),
(726, 'Darus Salam', 'fare not sure', '', 15, 78, 6),
(727, 'Kallyanpur', 'fare not sure', '', 15, 78, 7),
(728, 'Shamoly', 'fare not sure', '', 20, 78, 8),
(729, 'Asad Gate', 'fare not sure', '', 25, 78, 9),
(730, 'Farmgate', 'fare not sure', '', 30, 78, 10),
(731, 'Bangla motor', 'fare not sure', '', 35, 78, 11),
(732, 'Gulistan', 'fare not sure', '', 40, 78, 12),
(733, 'Adabor', '', '', 5, 79, 1),
(734, 'Shamoly', '', '', 5, 79, 2),
(735, 'Dhanmondi-27', '', '', 5, 79, 3),
(736, 'Rasel Square', '', '', 10, 79, 4),
(737, 'Kalabagan', '', '', 15, 79, 5),
(738, 'Science Lab', '', '', 15, 79, 6),
(739, 'ShahBag', '', '', 20, 79, 7),
(740, 'Pressclub', '', '', 25, 79, 8),
(741, 'Dilkusha', '', '', 30, 79, 9),
(742, 'Ittafaq', '', '', 35, 79, 10),
(743, 'Dairy Gate (Jahangirnagar University)', 'fare not sure', '', 5, 80, 1),
(744, 'Savar', 'fare not sure', '', 5, 80, 2),
(745, 'Hemayatpur (Savar)', 'fare not sure', '', 10, 80, 3),
(746, 'Amin Bazar', 'fare not sure', '', 15, 80, 4),
(747, 'Gabtoli', 'fare not sure', '', 15, 80, 5),
(748, 'Technical', 'fare not sure', '', 15, 80, 6),
(749, 'Ansar camp (Mirpur-1)', 'fare not sure', '', 20, 80, 7),
(750, 'Mirpur-1', 'fare not sure', '', 25, 80, 8),
(751, 'Mirpur-2', 'fare not sure', '', 25, 80, 9),
(752, 'Mirpur-10', 'fare not sure', '', 30, 80, 10),
(753, 'Mirpur-14', 'fare not sure', '', 30, 80, 11);

-- --------------------------------------------------------

--
-- Table structure for table `stoppage_bn`
--

CREATE TABLE `stoppage_bn` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `route_id` bigint(20) UNSIGNED NOT NULL,
  `place_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `comments` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `rent` int(11) NOT NULL,
  `position` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `stoppage_bn`
--

INSERT INTO `stoppage_bn` (`id`, `route_id`, `place_name`, `comments`, `rent`, `position`) VALUES
(1, 1, 'টেকনিকাল', '', 5, 1),
(2, 1, 'দারুস সালাম', '', 5, 2),
(3, 1, 'কল্যানপুর', '', 7, 3),
(4, 1, 'শ্যামলী', '', 8, 4),
(5, 8, 'নিউ মার্কেট বাসস্টান্ড', '', 550, 1),
(6, 9, 'মোহাম্মদপুর তিন রাস্তার মোড়', '', 10, 1),
(7, 9, 'মোহাম্মদপুর বাস স্ট্রান্ড', '', 15, 2),
(8, 9, 'আসাদগেট', '', 15, 3),
(9, 9, 'শ্যামলী', '', 15, 4),
(10, 9, 'দারুস সালাম', '', 15, 5),
(11, 9, 'মিরপুর-১', '', 15, 6),
(12, 9, 'মিরপুর-১০', '', 15, 7),
(13, 9, 'কালশী', '', 20, 8),
(14, 9, 'জসীমউদ্দিন', '', 30, 9),
(15, 9, 'রাজলক্ষী', '', 35, 10),
(16, 6, 'শ্যামলী', '', 10, 1),
(17, 6, 'আসাদগেট', '', 10, 2),
(18, 6, 'সাইন্সল্যাব', '', 15, 3),
(19, 6, 'শাহবাগ', '', 20, 4),
(20, 6, 'কাকরাইল', '', 25, 8),
(21, 6, 'ফকিরাপুল', '', 30, 9),
(22, 6, 'বাংলাদেশ ব্যাংক', '', 30, 10),
(23, 6, 'দয়াগঞ্জ রোড', '', 35, 11),
(24, 6, 'জুড়াইন', '', 40, 12),
(25, 11, 'সনি সিনেমা হল', '', 10, 1),
(26, 11, 'মিরপুর-২', '', 10, 2),
(27, 11, 'মিরপুর-১০', '', 10, 3),
(28, 11, 'কাজীপাড়া', '', 15, 4),
(29, 11, 'শেওড়াপাড়া', '', 15, 5),
(30, 11, 'আগারগাও ', '', 15, 6),
(31, 11, 'জাহাঙ্গীরগেট', '', 20, 7),
(32, 11, 'মহাখালী', '', 20, 8),
(33, 11, 'গুলশান-১', '', 25, 9),
(34, 11, 'বাড্ডা', '', 25, 10),
(35, 11, 'পূর্ব-রামপুরা', '', 30, 11),
(36, 11, 'চৌধুরীপাড়া', '', 30, 12),
(37, 11, 'মালিবাগ রেলগেট', '', 35, 13),
(38, 12, 'টঙ্গী', '', 20, 1),
(39, 12, 'উত্তরা', '', 25, 2),
(40, 12, 'মহাখালী', '', 30, 3),
(41, 12, 'ফার্মগেট', '', 35, 4),
(42, 12, 'শাহবাগ', '', 40, 5),
(43, 2, 'মহাখালী', '', 20, 3),
(44, 2, 'চেয়ারমেনবাড়ি', '', 25, 4),
(45, 2, 'সৈনিক ক্লাব', '', 25, 5),
(46, 2, 'কাকলী', '', 25, 6),
(47, 2, 'জসীমউদ্দিন', '', 30, 7),
(48, 2, 'রাজলক্ষী', '', 35, 8),
(49, 2, 'শ্যামলী', 'এখান থেকে সাধারনত যাত্রী উঠায়না', 5, 1),
(50, 2, 'আগারগাও', 'এখান থেকে সাধারনত যাত্রী উঠায়না', 15, 2),
(51, 3, 'টেকনিকাল', '', 10, 1),
(52, 3, 'কল্যানপুর', '', 10, 2),
(53, 3, 'শ্যামলী', '', 10, 3),
(54, 3, 'আগারগাও', '', 15, 4),
(55, 3, 'জসীমউদ্দিন', '', 30, 9),
(56, 3, 'রাজলক্ষী', '', 30, 10),
(57, 3, 'মহাখালী', '', 20, 5),
(58, 3, 'চেয়ারম্যান বাড়ী', '', 20, 6),
(59, 3, 'সৈনিক ক্লাব', '', 25, 7),
(60, 3, 'কাকলী', '', 25, 8),
(61, 13, 'কল্যানপুর', '', 5, 1),
(62, 13, 'শ্যামলী', '', 5, 2),
(63, 13, 'আগারগাও', '', 8, 3),
(64, 13, 'জাহাঙ্গীরগেট', '', 10, 4),
(65, 14, 'শ্যামলী', '', 5, 1),
(66, 14, 'আসাদগেট', '', 8, 2),
(67, 14, 'ফার্মগেট', '', 10, 3),
(68, 14, 'কাওরান বাজার', '', 12, 4),
(69, 14, 'শাহবাগ', '', 15, 5),
(70, 14, 'গুলিস্তান', '', 20, 6),
(71, 15, 'Rangpur', 'sometimes take passenger. boarding may not possible', 50, 1),
(72, 15, 'Bogra', 'sometimes take passenger. boarding may not possible', 150, 2),
(73, 15, 'Sirajgonj', 'sometimes take passenger. boarding not possible', 550, 3),
(74, 15, 'Tangail', '', 550, 4),
(75, 15, 'Gazipur', '', 550, 5),
(76, 15, 'Savar', '', 550, 6),
(77, 15, 'Majar Road', '', 550, 7),
(78, 5, 'আদাবর', '', 5, 1),
(79, 5, 'শ্যামলী', '', 5, 2),
(80, 5, 'শিশুমেলা', '', 10, 3),
(81, 5, 'আগারগাও', '', 15, 4),
(82, 5, 'শেওড়াপাড়া', '', 15, 5),
(83, 5, 'কাজীপাড়া', '', 15, 6),
(84, 5, 'মিরপুর-১০', '', 15, 7),
(85, 5, 'পুরবী', '', 20, 8),
(86, 5, 'কালশী', '', 25, 9),
(87, 5, 'এয়ারপোর্ট', '', 30, 10),
(88, 5, 'উত্তরা', '', 35, 11),
(89, 18, 'হেমায়াতপুর', 'Fare not sure', 10, 1),
(90, 18, 'গাবতলী', 'Fare not sure', 20, 2),
(91, 18, 'শ্যামলী', '', 25, 3),
(92, 18, 'ফার্মগেট', '', 30, 4),
(93, 18, 'বাসাবো', '', 35, 5),
(94, 18, 'যাত্রাবাড়ী', '', 40, 6),
(95, 20, 'শেওড়াপাড়া', 'ভাড়া নিশ্চিত না', 5, 1),
(96, 20, 'কাজীপাড়া', 'ভাড়া নিশ্চিত না', 10, 2),
(97, 20, 'মিরপুর-১০', 'ভাড়া নিশ্চিত না', 10, 3),
(98, 20, 'মিরপুর-১১.১/২', 'ভাড়া নিশ্চিত না', 10, 4),
(99, 20, 'জিয়া কলোনী', 'ভাড়া নিশ্চিত না', 15, 5),
(100, 20, 'এয়ারপোর্ট', 'ভাড়া নিশ্চিত না', 20, 6),
(101, 20, 'উত্তরা', 'ভাড়া নিশ্চিত না', 25, 7),
(102, 19, 'গাইবান্ধা', 'সাধারনত এখানে যাত্রী ওঠানামা করাবেনা তবে এই স্থান হয়ে গাড়িটি যায়', 1400, 1),
(103, 19, 'বগুরা', 'সাধারনত এখানে যাত্রী ওঠানামা করাবেনা তবে এই স্থান হয়ে গাড়িটি যায়', 1400, 2),
(104, 19, 'সিরাজগন্জ', 'সাধারনত এখানে যাত্রী ওঠানামা করাবেনা তবে এই স্থান হয়ে গাড়িটি যায়', 1400, 3),
(105, 19, 'যমুনা সেতু', 'সাধারনত এখানে যাত্রী ওঠানামা করাবেনা তবে এই স্থান হয়ে গাড়িটি যায়', 1400, 4),
(106, 19, 'টাংগাইল', 'যাত্রী নামাবে, ভাড়া একই', 1400, 5),
(107, 19, 'সাভার', 'যাত্রী নামাবে, ভাড়া একই', 1400, 6),
(108, 19, 'মাজার রোড, গাবতলী', 'যাত্রী নামাবে, ভাড়া একই', 1400, 7),
(109, 21, 'মিরপুর-১১', 'ভাড়াটা নিশ্চিত না', 10, 1),
(110, 21, 'মিরপুর-১০', 'ভাড়াটা নিশ্চিত না', 10, 2),
(111, 21, 'কাজীপাড়া', 'ভাড়াটা নিশ্চিত না', 10, 3),
(112, 22, 'মিরপুর-১১.১/২', '', 5, 1),
(113, 22, 'মিরপুর-১১', 'ভাড়াটা নিশ্চিত না', 10, 2),
(114, 22, 'মিরপুর-১০', 'ভাড়াটা নিশ্চিত না', 10, 3),
(115, 22, 'কাজীপাড়া', 'ভাড়াটা নিশ্চিত না', 10, 4),
(116, 22, 'শেওড়াপাড়া', 'ভাড়াটা নিশ্চিত না', 10, 5),
(117, 22, 'ফার্মগেট', 'ভাড়াটা নিশ্চিত না', 15, 6),
(118, 22, 'শাহবাগ', 'ভাড়াটা নিশ্চিত না', 20, 7),
(119, 22, 'প্রেসক্লাব', 'ভাড়াটা নিশ্চিত না', 20, 8),
(120, 22, 'বঙ্গবাজার', 'ভাড়াটা নিশ্চিত না', 20, 9),
(121, 22, 'গোলাপশাহ মাজার, গুলিস্তান', 'ভাড়াটা নিশ্চিত না', 20, 10),
(122, 22, ' রায়সাহেব বাজার', '', 25, 11),
(123, 23, 'শংকর', '', 10, 1),
(124, 23, 'ধানমন্ডি-১৫', '', 10, 2),
(125, 23, 'ঝিগাতলা', '', 10, 3),
(126, 23, 'সাইন্সল্যাব', 'ভাড়াটা নিশ্চিত না', 10, 4),
(127, 23, 'কাটাবন', 'ভাড়াটা নিশ্চিত না', 10, 5),
(128, 23, 'শাহবাগ ', 'ভাড়াটা নিশ্চিত না', 15, 6),
(129, 23, 'কাকরাইল', 'ভাড়াটা নিশ্চিত না', 15, 7),
(130, 23, 'মৌচাক ', 'ভাড়াটা নিশ্চিত না', 20, 8),
(131, 23, 'মালিবাগ রেলগেট', 'fare not sure', 25, 9),
(132, 23, 'রামপুরা বাজার', 'ভাড়াটা নিশ্চিত না', 25, 10),
(133, 23, 'রামপুরা ব্রীজ', 'ভাড়াটা নিশ্চিত না', 30, 11),
(134, 23, 'দক্ষিন বনশ্রী', 'ভাড়াটা নিশ্চিত না', 35, 12),
(135, 24, 'আসাদগেট', '', 5, 1),
(136, 24, 'ফার্মগেট', 'ভাড়াটা নিশ্চিত না', 5, 2),
(137, 24, 'মহাখালী', 'ভাড়াটা নিশ্চিত না', 10, 3),
(138, 24, 'গুলশান-১', 'ভাড়াটা নিশ্চিত না', 10, 4),
(139, 24, 'বাড্ডা', 'ভাড়াটা নিশ্চিত না', 15, 5),
(140, 24, 'নতুন বাজার', 'ভাড়াটা নিশ্চিত না', 20, 6),
(141, 25, 'শংকর', '', 10, 1),
(142, 25, 'ধানমন্ডি-১৫', '', 10, 2),
(143, 25, 'ঝিগাতলা', '', 10, 3),
(144, 25, 'সায়েন্সল্যাব', '', 10, 4),
(145, 25, 'শাহবাগ ইউবিএল', '', 15, 5),
(146, 25, 'গুলিস্তান', '', 20, 6),
(147, 25, 'মতিঝিল', '', 25, 7),
(148, 26, 'দারুস সালাম', 'fare not sure', 5, 1),
(149, 26, 'শ্যামলী', 'fare not sure', 10, 2),
(150, 26, 'আসাদগেট', 'fare not sure', 10, 3),
(151, 26, 'ফার্মগেট', 'fare not sure', 15, 4),
(152, 26, 'প্রেসক্লাব', 'fare not sure', 20, 5),
(153, 26, 'গুলিস্তান', 'fare not sure', 25, 6),
(154, 17, 'বগুরা', '', 550, 1),
(155, 17, 'পীরগন্জ', '', 550, 2),
(156, 27, 'গুলিস্তান', 'fare not sure', 5, 1),
(157, 27, 'পল্টন', 'fare not sure', 5, 2),
(158, 27, 'মালিবাগ', 'fare not sure', 8, 3),
(159, 27, 'মগবাজার', 'fare not sure', 10, 4),
(160, 27, 'কাওরান বাজার', 'fare not sure', 15, 5),
(161, 27, 'ফার্মগেট', 'fare not sure', 15, 6),
(162, 27, 'বিজয় সরনী', 'fare not sure', 20, 7),
(163, 27, 'মহাখালী', 'fare not sure', 20, 8),
(164, 27, 'গুলশান-১', 'fare not sure', 25, 9),
(165, 27, 'গুলশান-২', 'fare not sure', 25, 10),
(166, 29, 'Anik plaza (Mirpur-11.1/2)', 'fare not sure', 5, 1),
(167, 29, 'Mirpur-11', 'fare not sure', 5, 2),
(168, 29, 'Mirpur - 10', 'fare not sure', 10, 3),
(169, 29, 'Kajipara', 'fare not sure', 10, 4),
(170, 29, 'Farmgate', 'fare not sure', 15, 5),
(171, 29, 'pressclub', 'fare not sure', 20, 6),
(172, 29, 't&t', 'fare not sure', 20, 7),
(173, 29, 'rai saheb bazar', 'fare not sure', 25, 8),
(174, 29, 'victoria park', 'fare not sure', 25, 9),
(175, 30, 'Boikali hotel', 'fare not sure', 5, 1),
(176, 30, 'Mirpur-11', 'fare not sure', 5, 2),
(177, 30, 'Mirpur - 10', 'fare not sure', 5, 3),
(178, 30, 'Kajipara', 'fare not sure', 10, 4),
(179, 30, 'Shewrapara', 'fare not sure', 10, 5),
(180, 30, 'taltola', 'fare not sure', 10, 6),
(181, 30, 'Farmgate', 'fare not sure', 15, 7),
(182, 30, 'Shahbag', 'fare not sure', 15, 8),
(183, 30, 'paltan', 'fare not sure', 20, 9),
(184, 30, 'shapla chattor', 'fare not sure', 25, 10),
(185, 30, 'ittafaq', 'fare not sure', 30, 11),
(186, 30, 'saidabad', 'fare not sure', 35, 12),
(187, 31, 'মতিঝিল', 'ভাড়া নিশ্চিত না', 10, 1),
(188, 31, 'কমলাপুর', 'ভাড়া নিশ্চিত না', 10, 2),
(189, 31, 'মালিবাগ', 'ভাড়া নিশ্চিত না', 10, 3),
(190, 31, 'মগবাজার', 'ভাড়া নিশ্চিত না', 15, 4),
(191, 31, 'নাবিস্কো', 'ভাড়া নিশ্চিত না', 20, 5),
(192, 31, 'মহাখালী', 'ভাড়া নিশ্চিত না', 20, 6),
(193, 31, 'বনানী', 'ভাড়া নিশ্চিত না', 20, 7),
(194, 31, 'খিলক্ষেত', 'ভাড়া নিশ্চিত না', 20, 8),
(195, 31, 'এয়ারপোর্ট', 'ভাড়া নিশ্চিত না', 25, 9),
(196, 31, 'উত্তরা', 'ভাড়া নিশ্চিত না', 30, 10),
(197, 31, 'টঙ্গী বোর্ড বাজার', 'ভাড়া নিশ্চিত না', 35, 11),
(198, 32, 'মিরপুর-১', 'ভাড়া নিশ্চিত না', 10, 1),
(199, 32, 'মিরপুর-১০', 'ভাড়া নিশ্চিত না', 10, 2),
(200, 32, 'মিরপুর-১১', 'ভাড়া নিশ্চিত না', 10, 3),
(201, 32, 'কালশী', 'ভাড়া নিশ্চিত না', 15, 4),
(202, 32, 'বিশ্বরোড', 'ভাড়া নিশ্চিত না', 15, 5),
(203, 32, 'এয়ারপোর্ট', 'ভাড়া নিশ্চিত না', 20, 6),
(204, 32, 'উত্তরা', 'ভাড়া নিশ্চিত না', 25, 7),
(205, 32, 'আব্দুল্লাহপুর', 'ভাড়া নিশ্চিত না', 30, 8),
(206, 33, 'গুলিস্তান', 'fare not sure', 10, 1),
(207, 33, 'পল্টন', 'fare not sure', 10, 2),
(208, 33, 'মালিবাগ', 'fare not sure', 15, 3),
(209, 33, 'মগবাজার', 'fare not sure', 15, 4),
(210, 33, 'সাতরাস্তা', 'fare not sure', 15, 5),
(211, 33, 'নাবিস্কো', 'fare not sure', 15, 6),
(212, 33, 'মহাখালী', 'fare not sure', 20, 7),
(213, 33, 'বনানী', 'fare not sure', 20, 8),
(214, 33, 'এয়ারপোর্ট', 'fare not sure', 25, 9),
(215, 33, 'উত্তরা', 'fare not sure', 30, 10),
(216, 33, 'আব্দুল্লাহপুর', 'fare not sure', 30, 11),
(217, 33, 'টঙ্গী', 'fare not sure', 35, 12),
(218, 33, 'গাজীপুর', 'fare not sure', 40, 13),
(219, 34, 'Mirpur-10', 'fare not sure', 10, 1),
(220, 34, 'Mirpur-1', 'fare not sure', 10, 2),
(221, 34, 'Technical', 'fare not sure', 15, 3),
(222, 34, 'Shamoly', 'fare not sure', 20, 4),
(223, 34, 'Asad Gate', 'fare not sure', 20, 5),
(224, 34, 'Science Lab', 'fare not sure', 25, 6),
(225, 34, 'katabon', 'fare not sure', 25, 7),
(226, 34, 'Shahbag', 'fare not sure', 25, 8),
(227, 34, 'paltan', 'fare not sure', 30, 9),
(228, 34, 'dainik bangla', 'fare not sure', 30, 10),
(229, 34, 'notre dame', 'fare not sure', 35, 11),
(230, 35, 'দারুস সালাম', 'ভাড়া নিশ্চিত না', 5, 1),
(231, 35, 'কল্যানপুর', 'ভাড়া নিশ্চিত না', 5, 2),
(232, 35, 'শ্যামলী', 'ভাড়া নিশ্চিত না', 5, 3),
(233, 35, 'আসাদগেট', 'ভাড়া নিশ্চিত না', 10, 4),
(234, 35, 'কলাবাগান', 'ভাড়া নিশ্চিত না', 10, 5),
(235, 35, 'শাহবাগ', 'ভাড়া নিশ্চিত না', 15, 6),
(236, 35, 'গুলিস্তান', 'ভাড়া নিশ্চিত না', 20, 7),
(237, 36, 'সায়দাবাদ', 'ভাড়া নিশ্চিত না', 10, 1),
(238, 36, 'মুগদা', 'ভাড়া নিশ্চিত না', 10, 2),
(239, 36, 'বাসাবো', 'ভাড়া নিশ্চিত না', 15, 3),
(240, 36, 'খিলগাও', 'ভাড়া নিশ্চিত না', 15, 4),
(241, 36, 'মালিবাগ', 'ভাড়া নিশ্চিত না', 20, 5),
(242, 36, 'রামপুরা', 'ভাড়া নিশ্চিত না', 25, 6),
(243, 36, 'খিলক্ষেত', 'ভাড়া নিশ্চিত না', 25, 7),
(244, 36, 'এয়ারপোর্ট', 'ভাড়া নিশ্চিত না', 25, 8),
(245, 36, 'রাজলক্ষী', 'ভাড়া নিশ্চিত না', 30, 9),
(246, 36, 'হাউজ বিল্ডিং', 'ভাড়া নিশ্চিত না', 35, 10),
(247, 36, 'আব্দুল্লাহপুর', 'ভাড়া নিশ্চিত না', 35, 11),
(248, 37, 'ইপিজেড', 'ভাড়া নিশ্চিত না', 5, 1),
(249, 37, 'নবীনগর', 'ভাড়া নিশ্চিত না', 10, 2),
(250, 37, 'সাভার', 'ভাড়া নিশ্চিত না', 10, 3),
(251, 37, 'গাবতলী', 'ভাড়া নিশ্চিত না', 15, 4),
(252, 37, 'কলাবাগান', 'ভাড়া নিশ্চিত না', 20, 5),
(253, 37, 'নিউ মার্কেট', 'ভাড়া নিশ্চিত না', 25, 6),
(254, 37, 'চানখারপুল', 'ভাড়া নিশ্চিত না', 30, 7),
(255, 37, 'গুলিস্তান', 'ভাড়া নিশ্চিত না', 35, 8),
(256, 37, 'সায়দাবাদ', 'ভাড়া নিশ্চিত না', 40, 9),
(257, 38, 'গুলিস্তান', 'ভাড়া নিশ্চিত না', 10, 1),
(258, 38, 'রামপুরা', 'ভাড়া নিশ্চিত না', 10, 2),
(259, 38, 'বাড্ডা', 'ভাড়া নিশ্চিত না', 15, 3),
(260, 38, 'বিশ্বরোড', 'ভাড়া নিশ্চিত না', 20, 4),
(261, 38, 'এয়ারপোর্ট', 'ভাড়া নিশ্চিত না', 25, 5),
(262, 38, 'টঙ্গী', 'ভাড়া নিশ্চিত না', 30, 6),
(263, 41, 'আসাদগেট', '', 5, 1),
(264, 41, 'ফার্মগেট', '', 5, 2),
(265, 41, 'বিজয় সরনী', '', 8, 3),
(266, 41, 'মহাখালী', '', 10, 4),
(267, 41, 'গুলশান-১', 'ভাড়া নিশ্চিত না', 15, 5),
(268, 41, 'বাড্ডা', 'ভাড়া নিশ্চিত না', 20, 6),
(269, 42, 'আসাদগেট', 'ভাড়া নিশ্চিত না', 5, 1),
(270, 42, 'কলাবাগান', 'ভাড়া নিশ্চিত না', 10, 2),
(271, 42, 'সাইন্সল্যাব', 'ভাড়া নিশ্চিত না', 15, 3),
(272, 42, 'কাটাবন', 'ভাড়া নিশ্চিত না', 15, 4),
(273, 42, 'শাহবাগ', 'ভাড়া নিশ্চিত না', 20, 5),
(274, 42, 'প্রেসক্লাব', 'ভাড়া নিশ্চিত না', 25, 6),
(275, 42, 'মতিঝিল', 'ভাড়া নিশ্চিত না', 25, 7),
(276, 43, 'আজিমপুর', 'ভাড়া নিশ্চিত না', 5, 1),
(277, 43, 'নীলক্ষেত', 'ভাড়া নিশ্চিত না', 5, 2),
(278, 43, 'সিটি কলেজ', 'ভাড়া নিশ্চিত না', 10, 3),
(279, 43, 'কলাবাগান', 'ভাড়া নিশ্চিত না', 15, 4),
(280, 43, 'শুক্রাবাদ', 'ভাড়া নিশ্চিত না', 15, 5),
(281, 43, 'আসাদগেট', 'ভাড়া নিশ্চিত না', 20, 6),
(282, 43, 'ফার্মগেট', 'ভাড়া নিশ্চিত না', 20, 7),
(283, 43, 'মহাখালী', 'ভাড়া নিশ্চিত না', 25, 8),
(284, 43, 'বনানী/কাকলী', 'ভাড়া নিশ্চিত না', 30, 9),
(285, 44, 'শংকর', 'ভাড়া নিশ্চিত না', 5, 1),
(286, 44, 'ধানমন্ডি-১৫', 'ভাড়া নিশ্চিত না', 5, 2),
(287, 44, 'ঝিগাতলা', 'ভাড়া নিশ্চিত না', 10, 3),
(288, 44, 'সাইন্সল্যাব', 'ভাড়া নিশ্চিত না', 10, 4),
(289, 44, 'শাহবাগ', 'ভাড়া নিশ্চিত না', 15, 5),
(290, 44, 'প্রেসক্লাব', 'ভাড়া নিশ্চিত না', 20, 6),
(291, 44, 'গুলিস্তান', 'ভাড়া নিশ্চিত না', 23, 7),
(292, 40, 'শংকর', 'ভাড়া নিশ্চিত না', 10, 1),
(293, 40, 'ধানমন্ডি-১৫', 'ভাড়া নিশ্চিত না', 10, 2),
(294, 40, 'ঝিগাতলা', 'ভাড়া নিশ্চিত না', 10, 3),
(295, 40, 'সাইন্সল্যাব', 'ভাড়া নিশ্চিত না', 15, 4),
(296, 40, 'কাটাবন', 'ভাড়া নিশ্চিত না', 20, 5),
(297, 40, 'আরামবাগ', 'ভাড়া নিশ্চিত না', 25, 6),
(298, 39, 'গুলিস্তান', 'ভাড়া নিশ্চিত না', 10, 1),
(299, 39, 'কাকরাইল', 'ভাড়া নিশ্চিত না', 10, 2),
(300, 39, 'মালিবাগ', 'ভাড়া নিশ্চিত না', 15, 3),
(301, 39, 'মগবাজার', 'ভাড়া নিশ্চিত না', 20, 4),
(302, 39, 'মহাখালী', 'ভাড়া নিশ্চিত না', 25, 5),
(303, 39, 'এয়ারপোর্ট', 'ভাড়া নিশ্চিত না', 30, 6),
(304, 39, 'আব্দুল্লাহপুর', 'ভাড়া নিশ্চিত না', 35, 7),
(305, 45, 'মিরপুর-১১', 'ভাড়া নিশ্চিত না', 5, 1),
(306, 45, 'মিরপুর-১০', 'ভাড়া নিশ্চিত না', 10, 2),
(307, 45, 'তালতলা', 'ভাড়া নিশ্চিত না', 10, 3),
(308, 45, 'আগারগাও ', 'ভাড়া নিশ্চিত না', 10, 4),
(309, 45, 'শেওড়াপাড়া', 'ভাড়া নিশ্চিত না', 10, 5),
(310, 45, 'কাজীপাড়া', 'ভাড়া নিশ্চিত না', 15, 6),
(311, 45, 'শুক্রাবাদ', 'ভাড়া নিশ্চিত না', 15, 7),
(312, 45, 'কলাবাগান', 'ভাড়া নিশ্চিত না', 20, 8),
(313, 45, 'ল্যাবএইড', 'ভাড়া নিশ্চিত না', 20, 9),
(314, 45, 'নিউ মার্কেট', 'ভাড়া নিশ্চিত না', 20, 10),
(315, 45, 'ইডেন মহিলা কলেজ', 'ভাড়া নিশ্চিত না', 20, 11),
(316, 46, 'আজিমপুর', 'ভাড়া নিশ্চিত না', 5, 1),
(317, 46, 'নিউ মার্কেট', 'ভাড়া নিশ্চিত না', 5, 2),
(318, 46, 'সিটি কলেজ', 'ভাড়া নিশ্চিত না', 10, 3),
(319, 46, 'কলাবাগান', 'ভাড়া নিশ্চিত না', 10, 4),
(320, 46, 'রাসেল স্কয়ার', 'ভাড়া নিশ্চিত না', 15, 5),
(321, 46, 'পান্থপথ', 'ভাড়া নিশ্চিত না', 15, 6),
(322, 46, 'কাওরান বাজার', 'ভাড়া নিশ্চিত না', 15, 7),
(323, 46, 'সাতরাস্তা', 'ভাড়া নিশ্চিত না', 20, 8),
(324, 46, 'নাবিস্কো', 'ভাড়া নিশ্চিত না', 20, 9),
(325, 46, 'গুলশান-১', 'ভাড়া নিশ্চিত না', 25, 10),
(326, 47, 'মিরপুর-১০', 'ভাড়া নিশ্চিত না', 5, 1),
(327, 47, 'শেওড়াপাড়া', 'ভাড়া নিশ্চিত না', 10, 2),
(328, 47, 'আগারগাও ', 'ভাড়া নিশ্চিত না', 10, 3),
(329, 47, 'মহাখালী', 'ভাড়া নিশ্চিত না', 15, 4),
(330, 47, 'বনানী/কাকলী', 'ভাড়া নিশ্চিত না', 15, 5),
(331, 47, 'নিকুন্জ', 'ভাড়া নিশ্চিত না', 20, 6),
(332, 47, 'খিলক্ষেত', 'ভাড়া নিশ্চিত না', 20, 7),
(333, 47, 'এয়ারপোর্ট', 'ভাড়া নিশ্চিত না', 25, 8),
(334, 47, 'উত্তরা', 'ভাড়া নিশ্চিত না', 30, 9),
(335, 48, 'সাইন্সল্যাব', 'ভাড়া নিশ্চিত না', 15, 1),
(336, 48, 'শাহবাগ', 'ভাড়া নিশ্চিত না', 15, 2),
(337, 48, 'কাকরাইল', 'ভাড়া নিশ্চিত না', 15, 3),
(338, 48, 'মৌচাক', 'ভাড়া নিশ্চিত না', 20, 4),
(339, 48, 'রামপুরা', 'ভাড়া নিশ্চিত না', 20, 5),
(340, 48, 'বাড্ডা', 'ভাড়া নিশ্চিত না', 20, 6),
(341, 48, 'বাড়িধারা', 'ভাড়া নিশ্চিত না', 25, 7),
(342, 48, 'বসুন্ধরা', 'ভাড়া নিশ্চিত না', 25, 8),
(343, 48, 'কুড়িল বিশ্বরোড', 'ভাড়া নিশ্চিত না', 25, 9),
(344, 48, 'এয়ারপোর্ট', 'ভাড়া নিশ্চিত না', 30, 10),
(345, 49, 'গোবিন্দগন্জ', 'এখানে যাত্রী নেয়না। ভাড়া নিশ্চিত না', 780, 1),
(346, 49, 'বগুড়া', 'এখানে যাত্রী নেয়না। ভাড়া নিশ্চিত না', 780, 2),
(347, 49, 'সিরাজগন্জ', 'এখানে যাত্রী নেয়না। ভাড়া নিশ্চিত না', 780, 3),
(348, 49, 'টাংগাইল', 'এখানে যাত্রী নেয়না। ভাড়া নিশ্চিত না', 780, 4),
(349, 49, 'সাভার', 'এখানে যাত্রী নেয়না। ভাড়া নিশ্চিত না', 780, 5),
(350, 49, 'টেকনিকাল', 'এখানে যাত্রী নেয়না। ভাড়া নিশ্চিত না', 780, 6),
(351, 50, 'মিরপুর-১০', 'ভাড়া নিশ্চিত না', 5, 1),
(352, 50, 'কাজীপাড়া', 'ভাড়া নিশ্চিত না', 5, 2),
(353, 50, 'শেওড়াপাড়া', 'ভাড়া নিশ্চিত না', 10, 3),
(354, 50, 'তালতলা', 'ভাড়া নিশ্চিত না', 10, 4),
(355, 50, 'আগারগাও ', 'ভাড়া নিশ্চিত না', 10, 5),
(356, 50, 'বিজয় সরনী', 'ভাড়া নিশ্চিত না', 15, 6),
(357, 50, 'ফার্মগেট', 'ভাড়া নিশ্চিত না', 15, 7),
(358, 50, 'কাওরান বাজার', 'ভাড়া নিশ্চিত না', 20, 8),
(359, 50, 'শাহবাগ', 'ভাড়া নিশ্চিত না', 20, 9),
(360, 50, 'মৎস ভবন', 'ভাড়া নিশ্চিত না', 20, 10),
(361, 50, 'পল্টন', 'ভাড়া নিশ্চিত না', 20, 11),
(362, 50, 'গুলিস্তান', 'ভাড়া নিশ্চিত না', 25, 12),
(363, 50, 'আদমজী', 'ভাড়া নিশ্চিত না', 25, 13),
(364, 51, 'মিরপুর-২', 'ভাড়া নিশ্চিত না', 5, 1),
(365, 51, 'মিরপুর-১০', 'ভাড়া নিশ্চিত না', 5, 2),
(366, 51, 'কাজীপাড়া', 'ভাড়া নিশ্চিত না', 8, 3),
(367, 51, 'শেওড়াপাড়া', 'ভাড়া নিশ্চিত না', 10, 4),
(368, 51, 'আগারগাও ', 'ভাড়া নিশ্চিত না', 10, 5),
(369, 51, 'বিজয় সরনী (চন্দ্রিমা উদ্দান)', 'ভাড়া নিশ্চিত না', 10, 6),
(370, 51, 'ফার্মগেট', 'ভাড়া নিশ্চিত না', 15, 7),
(371, 51, 'বাংলামটর', 'ভাড়া নিশ্চিত না', 15, 8),
(372, 51, 'মগবাজার', 'ভাড়া নিশ্চিত না', 20, 9),
(373, 51, 'মালিবাগ', 'ভাড়া নিশ্চিত না', 25, 10),
(374, 52, 'মিরপুর-১১', 'ভাড়া নিশ্চিত না', 5, 1),
(375, 52, 'মিরপুর-১০', 'ভাড়া নিশ্চিত না', 8, 2),
(376, 52, 'কাজীপাড়া', 'ভাড়া নিশ্চিত না', 10, 3),
(377, 52, 'শেওড়াপাড়া', 'ভাড়া নিশ্চিত না', 10, 4),
(378, 52, 'আগারগাও', 'ভাড়া নিশ্চিত না', 12, 5),
(379, 52, 'ফার্মগেট', 'ভাড়া নিশ্চিত না', 15, 6),
(380, 52, 'প্রেসক্লাব', 'ভাড়া নিশ্চিত না', 20, 7),
(381, 52, 'গুলিস্তান', 'ভাড়া নিশ্চিত না', 25, 8),
(382, 53, 'বাংলা কলেজ (মিরপুর-১)', 'ভাড়া নিশ্চিত না', 5, 1),
(383, 53, 'মিরপুর-১', 'ভাড়া নিশ্চিত না', 10, 2),
(384, 53, 'কাজীপাড়া', 'ভাড়া নিশ্চিত না', 15, 3),
(385, 53, 'শেওড়াপাড়া', 'ভাড়া নিশ্চিত না', 15, 4),
(386, 53, 'আগারগাও ', 'ভাড়া নিশ্চিত না', 15, 5),
(387, 53, 'মহাখালী', 'ভাড়া নিশ্চিত না', 20, 6),
(388, 53, 'তিতুমীর কলেজ', 'ভাড়া নিশ্চিত না', 20, 7),
(389, 53, 'গুলশান-২', 'ভাড়া নিশ্চিত না', 25, 8),
(390, 53, 'খিলগাও', 'ভাড়া নিশ্চিত না', 30, 9),
(391, 54, 'ফিজিকাল কলেজ (ধানমন্ডি)', 'ভাড়া নিশ্চিত না', 5, 1),
(392, 54, 'ধানমন্ডি-২৭', 'ভাড়া নিশ্চিত না', 5, 2),
(393, 54, 'শংকর', 'ভাড়া নিশ্চিত না', 8, 3),
(394, 54, 'আবাহনী মাঠ', 'ভাড়া নিশ্চিত না', 5, 4),
(395, 54, 'ধানমন্ডি-১৫', 'ভাড়া নিশ্চিত না', 10, 5),
(396, 54, 'ঝিগাতলা', 'ভাড়া নিশ্চিত না', 12, 6),
(397, 54, 'সিটি কলেজ', 'ভাড়া নিশ্চিত না', 12, 7),
(398, 54, 'সাইন্সল্যাব', 'ভাড়া নিশ্চিত না', 15, 8),
(399, 54, 'বাটা সিগনাল', 'ভাড়া নিশ্চিত না', 20, 9),
(400, 54, 'এলিফেন্ট রোড', 'ভাড়া নিশ্চিত না', 20, 10),
(401, 54, 'কাটাবন', 'ভাড়া নিশ্চিত না', 20, 11),
(402, 54, 'শাহবাগ', 'ভাড়া নিশ্চিত না', 20, 12),
(403, 54, 'মৎস ভবন', 'ভাড়া নিশ্চিত না', 20, 13),
(404, 54, 'প্রেসক্লাব', 'ভাড়া নিশ্চিত না', 25, 14),
(405, 54, 'পল্টন', 'ভাড়া নিশ্চিত না', 25, 15),
(406, 54, 'জিপিও (পল্টন)', 'ভাড়া নিশ্চিত না', 25, 16),
(407, 54, 'হকি স্টেডিয়াম', 'ভাড়া নিশ্চিত না', 25, 17),
(408, 54, 'গুলিস্তান', 'ভাড়া নিশ্চিত না', 30, 18),
(409, 54, 'মতিঝিল', 'ভাড়া নিশ্চিত না', 35, 19),
(410, 54, 'কমলাপুর', 'ভাড়া নিশ্চিত না', 35, 20),
(411, 54, 'মুগদা', 'ভাড়া নিশ্চিত না', 35, 21),
(412, 54, 'বাসাবো', 'ভাড়া নিশ্চিত না', 40, 22),
(413, 54, 'বৌদ্ধ মন্দির', 'ভাড়া নিশ্চিত না', 40, 23),
(414, 55, 'মিরপুর-১৩', 'ভাড়া নিশ্চিত না', 5, 1),
(415, 55, 'মিরপুর-১০', 'Fare not sure', 5, 2),
(416, 55, 'মিরপুর-২', 'ভাড়া নিশ্চিত না', 5, 3),
(417, 55, 'মিরপুর-১', 'ভাড়া নিশ্চিত না', 8, 4),
(418, 55, 'আনসার ক্যাম্প', 'ভাড়া নিশ্চিত না', 8, 5),
(419, 55, 'টেকনিকাল', 'ভাড়া নিশ্চিত না', 10, 6),
(420, 55, 'কল্যানপুর', 'ভাড়া নিশ্চিত না', 10, 7),
(421, 55, 'শ্যামলী', 'ভাড়া নিশ্চিত না', 10, 8),
(422, 55, 'কলেজ গেট', 'ভাড়া নিশ্চিত না', 10, 9),
(423, 55, 'আসাদগেট', 'ভাড়া নিশ্চিত না', 15, 10),
(424, 55, 'ধানমন্ডি', 'ভাড়া নিশ্চিত না', 15, 11),
(425, 55, 'শুক্রাবাদ', 'ভাড়া নিশ্চিত না', 20, 12),
(426, 55, 'কলাবাগান', 'ভাড়া নিশ্চিত না', 20, 13),
(427, 55, 'সাইন্সল্যাব', 'ভাড়া নিশ্চিত না', 25, 14),
(428, 55, 'কাটাবন', 'ভাড়া নিশ্চিত না', 25, 15),
(429, 55, 'শাহবাগ', 'ভাড়া নিশ্চিত না', 25, 16),
(430, 55, 'প্রেসক্লাব', 'ভাড়া নিশ্চিত না', 30, 17),
(431, 55, 'দৈনিক বাংলা', 'ভাড়া নিশ্চিত না', 30, 18),
(432, 55, 'শাপলা চত্তর', 'ভাড়া নিশ্চিত না', 35, 19),
(433, 55, 'কমলাপুর', 'ভাড়া নিশ্চিত না', 35, 20),
(434, 55, 'বাসাবো', 'ভাড়া নিশ্চিত না', 40, 21),
(435, 55, 'খিলগাও', 'ভাড়া নিশ্চিত না', 40, 22),
(436, 10, 'শংকর', 'ভাড়া নিশ্চিত না', 10, 1),
(437, 10, 'ধানমন্ডি-১৫', 'ভাড়া নিশ্চিত না', 10, 2),
(438, 10, 'ঝিগাতলা', 'ভাড়া নিশ্চিত না', 10, 3),
(439, 10, 'সাইন্সল্যাব', 'ভাড়া নিশ্চিত না', 15, 4),
(440, 10, 'শাহবাগ', 'ভাড়া নিশ্চিত না', 15, 5),
(441, 10, 'প্রেসক্লাব', 'ভাড়া নিশ্চিত না', 20, 6),
(442, 10, 'গুলিস্তান', 'ভাড়া নিশ্চিত না', 25, 7),
(443, 56, 'মিরপুর-১৪', 'ভাড়া নিশ্চিত না', 5, 1),
(444, 56, 'মিরপুর-১০', 'ভাড়া নিশ্চিত না', 5, 2),
(445, 56, 'মিরপুর-১০', 'ভাড়া নিশ্চিত না', 8, 3),
(446, 56, 'মিরপুর-১', 'ভাড়া নিশ্চিত না', 8, 4),
(447, 56, 'টেকনিকাল', 'ভাড়া নিশ্চিত না', 10, 5),
(448, 56, 'দারুস সালাম', 'ভাড়া নিশ্চিত না', 10, 6),
(449, 56, 'কল্যানপুর', 'ভাড়া নিশ্চিত না', 10, 7),
(450, 56, 'শ্যামলী', 'ভাড়া নিশ্চিত না', 12, 8),
(451, 56, 'কলেজ গেট', 'ভাড়া নিশ্চিত না', 15, 9),
(452, 56, 'আসাদগেট', 'ভাড়া নিশ্চিত না', 15, 10),
(453, 56, 'শুক্রাবাদ', 'ভাড়া নিশ্চিত না', 20, 11),
(454, 56, 'কলাবাগান', 'ভাড়া নিশ্চিত না', 20, 12),
(455, 56, 'সাইন্সল্যাব', 'ভাড়া নিশ্চিত না', 25, 13),
(456, 56, 'শাহবাগ', 'ভাড়া নিশ্চিত না', 25, 14),
(457, 56, 'প্রেসক্লাব', 'ভাড়া নিশ্চিত না', 30, 15),
(458, 56, 'গুলিস্তান', 'ভাড়া নিশ্চিত না', 30, 16),
(459, 56, 'মতিঝিল', 'ভাড়া নিশ্চিত না', 30, 17),
(460, 56, 'কমলাপুর', 'ভাড়া নিশ্চিত না', 35, 18),
(461, 56, 'মুগদা', 'ভাড়া নিশ্চিত না', 35, 19),
(462, 56, 'বাসাবো', 'ভাড়া নিশ্চিত না', 40, 20),
(463, 28, 'মিরপুর-১২', 'ভাড়া নিশ্চিত না', 5, 1),
(464, 28, 'মিরপুর-১১', 'ভাড়া নিশ্চিত না', 10, 2),
(465, 28, 'মিরপুর-১০', 'ভাড়া নিশ্চিত না', 10, 3),
(466, 28, 'কাজীপাড়া', 'ভাড়া নিশ্চিত না', 10, 4),
(467, 28, 'শেওড়াপাড়া', 'ভাড়া নিশ্চিত না', 10, 5),
(468, 28, 'আগারগাও', 'ভাড়া নিশ্চিত না', 15, 6),
(469, 28, 'বিজয় সরনী', 'ভাড়া নিশ্চিত না', 15, 7),
(470, 28, 'ফার্মগেট', 'ভাড়া নিশ্চিত না', 15, 8),
(471, 28, 'কাওরান বাজার', 'ভাড়া নিশ্চিত না', 20, 9),
(472, 28, 'শাহবাগ', 'ভাড়া নিশ্চিত না', 20, 10),
(473, 28, 'প্রেসক্লাব', 'ভাড়া নিশ্চিত না', 20, 11),
(474, 28, 'গুলিস্তান', 'ভাড়া নিশ্চিত না', 20, 12),
(475, 28, 'বঙ্গভবন', 'ভাড়া নিশ্চিত না', 25, 13),
(476, 28, 'সায়দাবাদ', 'ভাড়া নিশ্চিত না', 30, 14),
(477, 57, 'সাভার', 'এখানে যাত্রী নিতে পারে কিন্তু নামাবে না', 550, 1),
(478, 57, 'টাংগাইল', 'এখানে যাত্রী নিতে পারে কিন্তু নামাবে না', 550, 2),
(479, 57, 'গাজীপুর', 'এখানে যাত্রী নিতে পারে কিন্তু নামাবে না', 550, 3),
(480, 57, 'সিরাজগন্জ', 'এখানে যাত্রী নিতে পারে কিন্তু নামাবে না', 550, 4),
(481, 57, 'যমুনা সেতু', 'এখানে যাত্রী নিতে পারে কিন্তু নামাবে না', 550, 5),
(482, 57, 'ফুড ভিলেজ', 'এখানে যাত্রী নিতে পারে কিন্তু নামাবে না', 550, 6),
(483, 57, 'গাইবান্ধা', 'এখানে যাত্রী নিতে পারে কিন্তু নামাবে না', 550, 7),
(484, 57, 'মডার্ন মোড়, রংপুর', '', 550, 8),
(485, 57, 'মোস্তফী, রংপুর', '', 550, 9),
(486, 57, 'বড়বাড়ি, লালমনিরহাট', '', 550, 10),
(487, 57, 'তিস্তা ব্রিজ, লালমনিরহাট', '', 550, 11),
(488, 57, 'কাঠাল বাড়ি, কুড়িগ্রাম', '', 550, 12),
(489, 57, 'খলিলগন্জ বাজার, কুড়িগ্রাম', '', 550, 13),
(490, 16, 'টেকনিকাল', 'এখানে যাত্রী নামাবেনা', 550, 1),
(491, 16, 'সাভার', 'এখানে যাত্রী নামাবেনা', 550, 2),
(492, 16, 'গাজীপুর', 'এখানে যাত্রী নামাবেনা', 550, 3),
(493, 16, 'টাংগাইল', 'এখানে যাত্রী নামাবেনা', 550, 4),
(494, 16, 'সিরাজগন্জ', 'এখানে যাত্রী নামাবেনা', 550, 5),
(495, 16, 'বগুড়া', 'এখানে যাত্রী নামাবেনা', 550, 6),
(496, 16, 'গাইবান্ধা', 'এখানে যাত্রী নামাবেনা', 550, 7),
(497, 16, 'মডার্ন মোড়, রংপুর', '', 550, 8),
(498, 16, 'বড়বাড়ী, লালমনিরহাট', '', 550, 9),
(499, 16, 'তিস্তা ব্রিজ, লালমনিরহাট', '', 550, 10),
(500, 16, 'কাঠাল বাড়ি, কুড়িগ্রাম', '', 550, 11),
(501, 16, 'খলিলগন্জ বাজার, কুড়িগ্রাম', '', 550, 12),
(502, 58, 'মিরপুর-১০', 'ভাড়া নিশ্চিত না', 5, 1),
(503, 58, 'মিরপুর-২', 'ভাড়া নিশ্চিত না', 10, 2),
(504, 58, 'মিরপুর-১', 'ভাড়া নিশ্চিত না', 10, 3),
(505, 58, 'মাজার রোড, গাবতলী', 'ভাড়া নিশ্চিত না', 10, 4),
(506, 58, 'দিয়াবাড়ী', 'ভাড়া নিশ্চিত না', 10, 5),
(507, 58, 'বিরুলিয়া', 'ভাড়া নিশ্চিত না', 10, 6),
(508, 58, 'বেরিবাধ', 'ভাড়া নিশ্চিত না', 10, 7),
(509, 58, 'ধউর', 'ভাড়া নিশ্চিত না', 15, 8),
(510, 58, 'আশুলিয়া', 'ভাড়া নিশ্চিত না', 20, 9),
(511, 58, 'ফ্যান্টাসি কিংডম', 'ভাড়া নিশ্চিত না', 25, 10),
(512, 58, 'বাইপাইল', 'ভাড়া নিশ্চিত না', 30, 11),
(513, 58, 'জিরানী', 'ভাড়া নিশ্চিত না', 35, 12),
(514, 58, 'নন্দন পার্ক', 'ভাড়া নিশ্চিত না', 40, 13),
(515, 59, 'মিরপুর-১১', 'ভাড়া নিশ্চিত না', 5, 1),
(516, 59, 'মিরপুর-১০', 'ভাড়া নিশ্চিত না', 5, 2),
(517, 59, 'মিরপুর-২', 'ভাড়া নিশ্চিত না', 5, 3),
(518, 59, 'মিরপুর-১', 'ভাড়া নিশ্চিত না', 10, 4),
(519, 59, 'আনসার ক্যাম্প', 'ভাড়া নিশ্চিত না', 10, 5),
(520, 59, 'বাংলা কলেজ (মিরপুর-১)', 'ভাড়া নিশ্চিত না', 10, 6),
(521, 59, 'টেকনিকাল', 'ভাড়া নিশ্চিত না', 10, 7),
(522, 59, 'দারুস সালাম', 'ভাড়া নিশ্চিত না', 10, 8),
(523, 59, 'কল্যানপুর', 'ভাড়া নিশ্চিত না', 10, 9),
(524, 59, 'শ্যামলী', 'ভাড়া নিশ্চিত না', 15, 10),
(525, 59, 'আসাদগেট', 'ভাড়া নিশ্চিত না', 15, 11),
(526, 59, 'শুক্রাবাদ', 'ভাড়া নিশ্চিত না', 15, 12),
(527, 59, 'কলাবাগান', 'ভাড়া নিশ্চিত না', 20, 13),
(528, 59, 'সাইন্সল্যাব', 'ভাড়া নিশ্চিত না', 20, 14),
(529, 59, 'নিউ মার্কেট', 'ভাড়া নিশ্চিত না', 25, 15),
(530, 60, 'মিরপুর-১', 'ভাড়া নিশ্চিত না', 5, 1),
(531, 60, 'মিরপুর-১০', 'ভাড়া নিশ্চিত না', 5, 2),
(532, 60, 'পুরবী', 'ভাড়া নিশ্চিত না', 5, 3),
(533, 60, 'কালশী', 'ভাড়া নিশ্চিত না', 10, 4),
(534, 60, 'মাটিকাটা ফ্লাইওভার', 'ভাড়া নিশ্চিত না', 10, 5),
(535, 60, 'মহাখালী', 'ভাড়া নিশ্চিত না', 15, 6),
(536, 60, 'বনানী/কাকলী', 'ভাড়া নিশ্চিত না', 15, 7),
(537, 60, 'গুলশান-২', 'ভাড়া নিশ্চিত না', 20, 8),
(538, 60, 'গুলশান-১', 'ভাড়া নিশ্চিত না', 20, 9),
(539, 60, 'বাড্ডা', 'ভাড়া নিশ্চিত না', 25, 10),
(540, 60, 'রামপুরা', 'ভাড়া নিশ্চিত না', 25, 11),
(541, 61, 'আনসার ক্যাম্প (মিরপুর-১)', 'ভাড়া নিশ্চিত না', 5, 1),
(542, 61, 'টেকনিকাল', 'ভাড়া নিশ্চিত না', 5, 2),
(543, 61, 'দারুস সালাম', 'ভাড়া নিশ্চিত না', 5, 3),
(544, 61, 'কল্যানপুর', 'ভাড়া নিশ্চিত না', 5, 4),
(545, 61, 'শ্যামলী', 'ভাড়া নিশ্চিত না', 8, 5),
(546, 61, 'কলেজ গেট', 'ভাড়া নিশ্চিত না', 10, 6),
(547, 61, 'শুক্রাবাদ', 'ভাড়া নিশ্চিত না', 10, 7),
(548, 61, 'কলাবাগান', 'ভাড়া নিশ্চিত না', 15, 8),
(549, 61, 'সাইন্সল্যাব', 'ভাড়া নিশ্চিত না', 15, 9),
(550, 61, 'কাটাবন', 'ভাড়া নিশ্চিত না', 15, 10),
(551, 61, 'শাহবাগ', 'ভাড়া নিশ্চিত না', 20, 11),
(552, 61, 'প্রেসক্লাব', 'ভাড়া নিশ্চিত না', 20, 12),
(553, 61, 'গুলিস্তান মোড়', 'ভাড়া নিশ্চিত না', 20, 13),
(554, 61, 'বাংলাদেশ ব্যাংক (মতিঝিল)', 'ভাড়া নিশ্চিত না', 25, 14),
(555, 61, 'যাত্রাবাড়ী', 'ভাড়া নিশ্চিত না', 30, 15),
(556, 62, 'আনসার ক্যাম্প (মিরপুর-১)', 'ভাড়া নিশ্চিত না', 5, 1),
(557, 62, 'টেকনিকাল', 'ভাড়া নিশ্চিত না', 5, 2),
(558, 62, 'দারুস সালাম', 'ভাড়া নিশ্চিত না', 5, 3),
(559, 62, 'কল্যানপুর', 'ভাড়া নিশ্চিত না', 5, 4),
(560, 62, 'শ্যামলী', 'ভাড়া নিশ্চিত না', 10, 5),
(561, 62, 'কলেজ গেট', 'ভাড়া নিশ্চিত না', 10, 6),
(562, 62, 'আসাদগেট', 'ভাড়া নিশ্চিত না', 10, 7),
(563, 62, 'ফার্মগেট', 'ভাড়া নিশ্চিত না', 15, 8),
(564, 62, 'কাওরান বাজার', 'ভাড়া নিশ্চিত না', 15, 9),
(565, 62, 'শাহবাগ', 'ভাড়া নিশ্চিত না', 15, 10),
(566, 62, 'প্রেসক্লাব', 'ভাড়া নিশ্চিত না', 20, 11),
(567, 62, 'মতিঝিল', 'ভাড়া নিশ্চিত না', 25, 12),
(568, 63, 'টেকনিকাল', 'ভাড়া নিশ্চিত না', 5, 1),
(569, 63, 'দারুস সালাম', 'ভাড়া নিশ্চিত না', 5, 2),
(570, 63, 'কল্যানপুর', 'ভাড়া নিশ্চিত না', 10, 3),
(571, 63, 'শ্যামলী', 'ভাড়া নিশ্চিত না', 15, 4),
(572, 63, 'আগারগাও ', 'ভাড়া নিশ্চিত না', 15, 5),
(573, 63, 'জাহাঙ্গীরগেট', 'ভাড়া নিশ্চিত না', 20, 6),
(574, 63, 'মহাখালী', 'ভাড়া নিশ্চিত না', 20, 7),
(575, 63, 'বনানী/কাকলী', 'ভাড়া নিশ্চিত না', 25, 8),
(576, 63, 'উত্তরা', 'ভাড়া নিশ্চিত না', 30, 9),
(577, 64, 'অনিক প্লাজা (মিরপুর ১১.১/২)', 'ভাড়া নিশ্চিত না', 5, 1),
(578, 64, 'মিরপুর-১১', 'ভাড়া নিশ্চিত না', 5, 2),
(579, 64, 'মিরপুর-১০', 'ভাড়া নিশ্চিত না', 5, 3),
(580, 64, 'কাজীপাড়া', 'ভাড়া নিশ্চিত না', 10, 4),
(581, 64, 'শেওড়াপাড়া', 'ভাড়া নিশ্চিত না', 10, 5),
(582, 64, 'ফার্মগেট', 'ভাড়া নিশ্চিত না', 10, 6),
(583, 64, 'প্রেসক্লাব', 'ভাড়া নিশ্চিত না', 10, 7),
(584, 64, 'গুলিস্তান', 'ভাড়া নিশ্চিত না', 20, 8),
(585, 64, 'আহাদবক্স', 'ভাড়া নিশ্চিত না', 20, 9),
(586, 64, 'সায়দাবাদ', 'ভাড়া নিশ্চিত না', 25, 10),
(587, 64, 'যাত্রাবাড়ী', 'ভাড়া নিশ্চিত না', 30, 11),
(588, 65, 'মিরপুর-১০', 'ভাড়া নিশ্চিত না', 5, 1),
(589, 65, 'খেজুর বাগান (ফার্মগেট)', 'ভাড়া নিশ্চিত না', 5, 2),
(590, 65, 'শাহবাগ', 'ভাড়া নিশ্চিত না', 15, 3),
(591, 65, 'প্রেসক্লাব', 'ভাড়া নিশ্চিত না', 15, 4),
(592, 65, 'দৈনিক বাংলা', 'fare not sure', 15, 5),
(593, 65, 'ফকিরাপুল', 'fare not sure', 20, 6),
(594, 65, 'বাংলাদেশ ব্যাংক (মতিঝিল)', 'fare not sure', 20, 7),
(595, 65, 'ইত্তেফাক', 'fare not sure', 20, 8),
(596, 65, 'যাত্রাবাড়ী', 'fare not sure', 25, 9),
(597, 65, 'সায়দাবাদ', 'fare not sure', 25, 10),
(598, 65, 'চিটাগং রোড', 'fare not sure', 30, 11),
(599, 66, 'কটিয়াদী', 'ভাড়া নিশ্চিত না', 300, 1),
(600, 66, 'কুলিয়ারচর', 'ভাড়া নিশ্চিত না', 300, 2),
(601, 66, 'ভৈরব', 'ভাড়া নিশ্চিত না', 300, 3),
(602, 66, 'নরসিংদী', 'ভাড়া নিশ্চিত না', 300, 4),
(603, 66, 'নারায়নগন্জ', 'ভাড়া নিশ্চিত না', 300, 5),
(604, 66, 'চিটাগং রোড', 'ভাড়া নিশ্চিত না', 300, 6),
(605, 67, 'কটিয়াদী', 'ভাড়া নিশ্চিত না', 300, 1),
(606, 67, 'কুলিয়ারচর', 'ভাড়া নিশ্চিত না', 300, 2),
(607, 67, 'ভৈরব', 'ভাড়া নিশ্চিত না', 300, 3),
(608, 67, 'নরসিংদী', 'ভাড়া নিশ্চিত না', 300, 4),
(609, 67, 'নারায়নগন্জ', 'ভাড়া নিশ্চিত না', 300, 5),
(610, 67, 'গাজীপুর', 'ভাড়া নিশ্চিত না', 300, 6),
(611, 67, 'আব্দুল্লাহপুর', 'ভাড়া নিশ্চিত না', 300, 7),
(612, 67, 'মহাখালী', 'ভাড়া নিশ্চিত না', 300, 8),
(613, 68, 'বেলাবো', 'ভাড়া নিশিচত না', 200, 1),
(614, 68, 'নরসিংদী', 'ভাড়া নিশিচত না', 200, 2),
(615, 68, 'নারায়নগন্জ', 'ভাড়া নিশিচত না', 200, 3),
(616, 68, 'গাজীপুর চৌরাস্তা', 'ভাড়া নিশিচত না', 200, 4),
(617, 68, 'আব্দুল্লাহপুর', 'ভাড়া নিশিচত না', 200, 5),
(618, 68, 'মহাখালী', 'ভাড়া নিশিচত না', 200, 6),
(619, 69, 'বেলাবো', 'ভাড়া নিশিচত না', 200, 1),
(620, 69, 'নরসিংদী', 'ভাড়া নিশিচত না', 200, 2),
(621, 69, 'নারায়নগন্জ', 'ভাড়া নিশিচত না', 200, 3),
(622, 69, 'গাজীপুর চৌরাস্তা', 'ভাড়া নিশিচত না', 200, 4),
(623, 69, 'আব্দুল্লাহপুর', 'ভাড়া নিশিচত না', 200, 5),
(624, 69, 'মহাখালী', 'ভাড়া নিশিচত না', 200, 6),
(625, 4, 'খলিলগন্জ বাজার, কুড়িগ্রাম', 'এখানে যাত্রী নামাবেনা, উঠাতে পারে', 550, 1),
(626, 4, 'কাঠাল বাড়ি, কুড়িগ্রাম', 'এখানে যাত্রী নামাবেনা, উঠাতে পারে', 550, 2),
(627, 4, 'তিস্তা ব্রিজ, লালমনিরহাট', 'এখানে যাত্রী নামাবেনা, উঠাতে পারে', 550, 3),
(628, 4, 'মডার্ন মোড়, রংপুর', 'এখানে যাত্রী নামাবেনা, উঠাতে পারে', 550, 4),
(629, 4, 'গাইবান্ধা', 'এখানে যাত্রী নামাবেনা, উঠাতে পারে', 550, 5),
(630, 4, 'ফুড ভিলেজ (বগুড়া)', 'এখানে যাত্রী নামাবেনা', 550, 6),
(631, 4, 'সিরাজগন্জ', '', 550, 7),
(632, 4, 'টাংগাইল', '', 550, 8),
(633, 4, 'গাজীপুর', '', 550, 9),
(634, 4, 'সাভার', '', 550, 10),
(635, 4, 'টেকনিকাল', '', 550, 11),
(636, 70, 'নবীনগর', 'ভাড়া নিশ্চিত না', 15, 1),
(637, 70, 'জাহাঙ্গীরনগর বিশ্ববিদ্যালয়', 'ভাড়া নিশ্চিত না', 15, 2),
(638, 70, 'সাভার', 'ভাড়া নিশ্চিত না', 20, 3),
(639, 70, 'হেমায়াতপুর (সাভার)', 'ভাড়া নিশ্চিত না', 25, 4),
(640, 70, 'টেকনিকাল', 'ভাড়া নিশ্চিত না', 30, 5),
(641, 70, 'দারুস সালাম', 'ভাড়া নিশ্চিত না', 30, 6),
(642, 70, 'কল্যানপুর', 'ভাড়া নিশ্চিত না', 30, 7),
(643, 70, 'শ্যামলী', 'ভাড়া নিশ্চিত না', 30, 8),
(644, 70, 'আসাদগেট', 'ভাড়া নিশ্চিত না', 35, 9),
(645, 70, 'কলাবাগান', 'ভাড়া নিশ্চিত না', 40, 10),
(646, 70, 'সাইন্সল্যাব', 'ভাড়া নিশ্চিত না', 40, 11),
(647, 70, 'নিউ মার্কেট', 'ভাড়া নিশ্চিত না', 45, 12),
(648, 70, 'গুলিস্তান', 'ভাড়া নিশ্চিত না', 50, 13),
(649, 71, 'টাউন হল', '', 5, 1),
(650, 71, 'আসাদগেট', '', 5, 2),
(651, 71, 'ফার্মগেট', '', 8, 3),
(652, 71, 'মহাখালী', '', 10, 4),
(653, 71, 'তিতুমীর কলেজ', '', 12, 5),
(654, 71, 'গুলশান-১', '', 15, 6),
(655, 72, 'হেমায়াতপুর (সাভার)', 'ভাড়া নিশ্চিত না', 10, 1),
(656, 72, 'আমিন বাজার', 'ভাড়া নিশ্চিত না', 10, 2),
(657, 72, 'গাবতলী', 'ভাড়া নিশ্চিত না', 15, 3),
(658, 72, 'টেকনিকাল', 'ভাড়া নিশ্চিত না', 15, 4),
(659, 72, 'দারুস সালাম', 'ভাড়া নিশ্চিত না', 15, 5),
(660, 72, 'কল্যানপুর', 'ভাড়া নিশ্চিত না', 15, 6),
(661, 72, 'শ্যামলী', 'ভাড়া নিশ্চিত না', 20, 7),
(662, 72, 'শিশুমেলা', 'ভাড়া নিশ্চিত না', 20, 8),
(663, 72, 'আগারগাও ', 'ভাড়া নিশ্চিত না', 20, 9),
(664, 72, 'মহাখালী', 'ভাড়া নিশ্চিত না', 25, 10),
(665, 72, 'গুলশান-১', 'ভাড়া নিশ্চিত না', 30, 11),
(666, 73, 'আনসার ক্যাম্প (মিরপুর-১)', 'ভাড়া নিশ্চিত না', 5, 1),
(667, 73, 'ফার্মগেট', 'ভাড়া নিশ্চিত না', 10, 2),
(668, 73, 'গোলাপশাহ মাজার, গুলিস্তান', 'ভাড়া নিশ্চিত না', 20, 3),
(669, 73, 'ফূলবাড়িয়া', 'ভাড়া নিশ্চিত না', 20, 4),
(670, 73, 'নয়াবাজার', 'ভাড়া নিশ্চিত না', 25, 5),
(671, 73, 'কেরানীগন্জ', 'ভাড়া নিশ্চিত না', 30, 6),
(672, 74, 'গুলিস্তান', 'ভাড়া নিশ্চিত না', 10, 1),
(673, 74, 'পল্টন', 'ভাড়া নিশ্চিত না', 10, 2),
(674, 74, 'কাকরাইল', 'ভাড়া নিশ্চিত না', 15, 3),
(675, 74, 'মালিবাগ', 'ভাড়া নিশ্চিত না', 15, 4),
(676, 74, 'মগবাজার', 'ভাড়া নিশ্চিত না', 15, 5),
(677, 74, 'মহাখালী', 'ভাড়া নিশ্চিত না', 20, 6),
(678, 74, 'এয়ারপোর্ট', 'ভাড়া নিশ্চিত না', 25, 7),
(679, 74, 'আব্দুল্লাহপুর', 'ভাড়া নিশ্চিত না', 30, 8),
(680, 74, 'টঙ্গী', 'ভাড়া নিশ্চিত না', 35, 9),
(681, 74, 'গাজীপুর বাইপাস', 'ভাড়া নিশ্চিত না', 40, 10),
(682, 75, 'মিরপুর-১', 'ভাড়া নিশ্চিত না', 5, 1),
(683, 75, 'মিরপুর-২', 'ভাড়া নিশ্চিত না', 5, 2),
(684, 75, 'মিরপুর-১০', 'ভাড়া নিশ্চিত না', 10, 3),
(685, 75, 'মিরপুর-১২', 'ভাড়া নিশ্চিত না', 10, 4),
(686, 75, 'কালশী', 'ভাড়া নিশ্চিত না', 10, 5),
(687, 75, 'কুড়িল', 'ভাড়া নিশ্চিত না', 15, 6),
(688, 75, 'নর্দা', 'ভাড়া নিশ্চিত না', 20, 7),
(689, 75, 'নতুন বাজার', 'ভাড়া নিশ্চিত না', 25, 8),
(690, 75, 'বাড্ডা', 'fare not sure', 30, 9),
(691, 75, 'হাতিরঝিল', 'fare not sure', 35, 10),
(692, 76, 'মিরপুর-১', 'ভাড়া নিশ্চিত না', 5, 1),
(693, 76, 'মিরপুর-২', 'ভাড়া নিশ্চিত না', 5, 2),
(694, 76, 'মিরপুর-১০', 'ভাড়া নিশ্চিত না', 10, 3),
(695, 76, 'মিরপুর-১২', 'ভাড়া নিশ্চিত না', 10, 4),
(696, 76, 'কালশী', 'ভাড়া নিশ্চিত না', 10, 5),
(697, 76, 'কুড়িল', 'ভাড়া নিশ্চিত না', 15, 6),
(698, 76, 'নর্দা', 'ভাড়া নিশ্চিত না', 20, 7),
(699, 76, 'নতুন বাজার', 'ভাড়া নিশ্চিত না', 25, 8),
(700, 76, 'বাড্ডা', 'fare not sure', 30, 9),
(701, 76, 'হাতিরঝিল', 'fare not sure', 35, 10),
(702, 77, 'কচুক্ষেত', 'ভাড়া নিশ্চিত না', 10, 1),
(703, 77, 'সৈনিক ক্লাব', 'ভাড়া নিশ্চিত না', 12, 2),
(704, 77, 'কাকলী', 'ভাড়া নিশ্চিত না', 12, 3),
(705, 77, 'মহাখালী', 'ভাড়া নিশ্চিত না', 15, 4),
(706, 78, 'সাভার বাজার', 'ভাড়া নিশ্চিত না', 5, 1),
(707, 78, 'হেমায়াতপুর (সাভার)', 'ভাড়া নিশ্চিত না', 10, 2),
(708, 78, 'আমিন বাজার', 'ভাড়া নিশ্চিত না', 15, 3),
(709, 78, 'গাবতলী', 'ভাড়া নিশ্চিত না', 15, 4),
(710, 78, 'টেকনিকাল', 'ভাড়া নিশ্চিত না', 15, 5),
(711, 78, 'দারুস সালাম', 'ভাড়া নিশ্চিত না', 15, 6),
(712, 78, 'কল্যানপুর', 'ভাড়া নিশ্চিত না', 15, 7),
(713, 78, 'শ্যামলী', 'ভাড়া নিশ্চিত না', 20, 8),
(714, 78, 'আসাদগেট', 'ভাড়া নিশ্চিত না', 25, 9),
(715, 78, 'ফার্মগেট', 'ভাড়া নিশ্চিত না', 30, 10),
(716, 78, 'বাংলামটর', 'ভাড়া নিশ্চিত না', 35, 11),
(717, 78, 'গুলিস্তান', 'ভাড়া নিশ্চিত না', 40, 12),
(718, 79, 'আদাবর', 'ভাড়া নিশ্চিত না', 5, 1),
(719, 79, 'শ্যামলী', 'ভাড়া নিশ্চিত না', 5, 2),
(720, 79, 'ধানমন্ডি-২৭', 'ভাড়া নিশ্চিত না', 5, 3),
(721, 79, 'রাসেল স্কয়ার', 'ভাড়া নিশ্চিত না', 10, 4),
(722, 79, 'কলাবাগান', 'ভাড়া নিশ্চিত না', 15, 5),
(723, 79, 'সাইন্সল্যাব', 'ভাড়া নিশ্চিত না', 15, 6),
(724, 79, 'শাহবাগ', 'ভাড়া নিশ্চিত না', 20, 7),
(725, 79, 'প্রেসক্লাব', 'ভাড়া নিশ্চিত না', 20, 8),
(726, 79, 'দিলকুশা', 'ভাড়া নিশ্চিত না', 25, 9),
(727, 79, 'ইত্তেফাক', 'ভাড়া নিশ্চিত না', 30, 10),
(728, 80, 'ডেইরি গেট (জাবি)', 'ভাড়া নিশ্চিত না', 5, 1),
(729, 80, 'সাভার বাজার', 'ভাড়া নিশ্চিত না', 5, 2),
(730, 80, 'হেমায়াতপুর (সাভার)', 'ভাড়া নিশ্চিত না', 10, 3),
(731, 80, 'আমিন বাজার', 'ভাড়া নিশ্চিত না', 15, 4),
(732, 80, 'গাবতলী', 'ভাড়া নিশ্চিত না', 15, 5),
(733, 80, 'টেকনিকাল', 'ভাড়া নিশ্চিত না', 15, 6),
(734, 80, 'আনসার ক্যাম্প (মিরপুর-১)', 'ভাড়া নিশ্চিত না', 20, 7),
(735, 80, 'মিরপুর-১', 'ভাড়া নিশ্চিত না', 25, 8),
(736, 80, 'মিরপুর-২', 'ভাড়া নিশ্চিত না', 25, 9),
(737, 80, 'মিরপুর-১০', 'ভাড়া নিশ্চিত না', 30, 10),
(738, 80, 'মিরপুর-১৪', 'ভাড়া নিশ্চিত না', 35, 11);

-- --------------------------------------------------------

--
-- Table structure for table `thanas`
--

CREATE TABLE `thanas` (
  `id` int(2) UNSIGNED NOT NULL,
  `district_id` int(2) UNSIGNED NOT NULL,
  `name` varchar(30) NOT NULL,
  `bn_name` varchar(50) NOT NULL,
  `guesture` varchar(250) NOT NULL,
  `bn_guesture` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `thanas`
--

INSERT INTO `thanas` (`id`, `district_id`, `name`, `bn_name`, `guesture`, `bn_guesture`) VALUES
(1, 34, 'Amtali', 'আমতলী', '', ''),
(2, 34, 'Bamna', 'বামনা', '', ''),
(3, 34, 'Barguna Sadar', 'বরগুনা সদর', '', ''),
(4, 34, 'Betagi', 'বেতাগি', '', ''),
(5, 34, 'Patharghata', 'পাথরঘাটা', '', ''),
(6, 34, 'Taltali', 'তালতলী', '', ''),
(7, 35, 'Muladi', 'মুলাদি', '', ''),
(8, 35, 'Babuganj', 'বাবুগঞ্জ', '', ''),
(9, 35, 'Agailjhara', 'আগাইলঝরা', '', ''),
(10, 35, 'Barisal Sadar', 'বরিশাল সদর', '', ''),
(11, 35, 'Bakerganj', 'বাকেরগঞ্জ', '', ''),
(12, 35, 'Banaripara', 'বানাড়িপারা', '', ''),
(13, 35, 'Gaurnadi', 'গৌরনদী', '', ''),
(14, 35, 'Hizla', 'হিজলা', '', ''),
(15, 35, 'Mehendiganj', 'মেহেদিগঞ্জ ', '', ''),
(16, 35, 'Wazirpur', 'ওয়াজিরপুর', '', ''),
(17, 36, 'Bhola Sadar', 'ভোলা সদর', '', ''),
(18, 36, 'Burhanuddin', 'বুরহানউদ্দিন', '', ''),
(19, 36, 'Char Fasson', 'চর ফ্যাশন', '', ''),
(20, 36, 'Daulatkhan', 'দৌলতখান', '', ''),
(21, 36, 'Lalmohan', 'লালমোহন', '', ''),
(22, 36, 'Manpura', 'মনপুরা', '', ''),
(23, 36, 'Tazumuddin', 'তাজুমুদ্দিন', '', ''),
(24, 37, 'Jhalokati Sadar', 'ঝালকাঠি সদর', '', ''),
(25, 37, 'Kathalia', 'কাঁঠালিয়া', '', ''),
(26, 37, 'Nalchity', 'নালচিতি', '', ''),
(27, 37, 'Rajapur', 'রাজাপুর', '', ''),
(28, 38, 'Bauphal', 'বাউফল', '', ''),
(29, 38, 'Dashmina', 'দশমিনা', '', ''),
(30, 38, 'Galachipa', 'গলাচিপা', '', ''),
(31, 38, 'Kalapara', 'কালাপারা', '', ''),
(32, 38, 'Mirzaganj', 'মির্জাগঞ্জ ', '', ''),
(33, 38, 'Patuakhali Sadar', 'পটুয়াখালী সদর', '', ''),
(34, 38, 'Dumki', 'ডুমকি', '', ''),
(35, 38, 'Rangabali', 'রাঙ্গাবালি', '', ''),
(36, 39, 'Bhandaria', 'ভ্যান্ডারিয়া', '', ''),
(37, 39, 'Kaukhali', 'কাউখালি', '', ''),
(38, 39, 'Mathbaria', 'মাঠবাড়িয়া', '', ''),
(39, 39, 'Nazirpur', 'নাজিরপুর', '', ''),
(40, 39, 'Nesarabad', 'নেসারাবাদ', '', ''),
(41, 39, 'Pirojpur Sadar', 'পিরোজপুর সদর', '', ''),
(42, 39, 'Zianagar', 'জিয়ানগর', '', ''),
(43, 40, 'Bandarban Sadar', 'বান্দরবন সদর', '', ''),
(44, 40, 'Thanchi', 'থানচি', '', ''),
(45, 40, 'Lama', 'লামা', '', ''),
(46, 40, 'Naikhongchhari', 'নাইখংছড়ি ', '', ''),
(47, 40, 'Ali kadam', 'আলী কদম', '', ''),
(48, 40, 'Rowangchhari', 'রউয়াংছড়ি ', '', ''),
(49, 40, 'Ruma', 'রুমা', '', ''),
(50, 41, 'Brahmanbaria Sadar', 'ব্রাহ্মণবাড়িয়া সদর', '', ''),
(51, 41, 'Ashuganj', 'আশুগঞ্জ', '', ''),
(52, 41, 'Nasirnagar', 'নাসির নগর', '', ''),
(53, 41, 'Nabinagar', 'নবীনগর', '', ''),
(54, 41, 'Sarail', 'সরাইল', '', ''),
(55, 41, 'Shahbazpur Town', 'শাহবাজপুর টাউন', '', ''),
(56, 41, 'Kasba', 'কসবা', '', ''),
(57, 41, 'Akhaura', 'আখাউরা', '', ''),
(58, 41, 'Bancharampur', 'বাঞ্ছারামপুর', '', ''),
(59, 41, 'Bijoynagar', 'বিজয় নগর', '', ''),
(60, 42, 'Chandpur Sadar', 'চাঁদপুর সদর', '', ''),
(61, 42, 'Faridganj', 'ফরিদগঞ্জ', '', ''),
(62, 42, 'Haimchar', 'হাইমচর', '', ''),
(63, 42, 'Haziganj', 'হাজীগঞ্জ', '', ''),
(64, 42, 'Kachua', 'কচুয়া', '', ''),
(65, 42, 'Matlab Uttar', 'মতলব উত্তর', '', ''),
(66, 42, 'Matlab Dakkhin', 'মতলব দক্ষিণ', '', ''),
(67, 42, 'Shahrasti', 'শাহরাস্তি', '', ''),
(68, 43, 'Anwara', 'আনোয়ারা', '', ''),
(69, 43, 'Banshkhali', 'বাশখালি', '', ''),
(70, 43, 'Boalkhali', 'বোয়ালখালি', '', ''),
(71, 43, 'Chandanaish', 'চন্দনাইশ', '', ''),
(72, 43, 'Fatikchhari', 'ফটিকছড়ি', '', ''),
(73, 43, 'Hathazari', 'হাঠহাজারী', '', ''),
(74, 43, 'Lohagara', 'লোহাগারা', '', ''),
(75, 43, 'Mirsharai', 'মিরসরাই', '', ''),
(76, 43, 'Patiya', 'পটিয়া', '', ''),
(77, 43, 'Rangunia', 'রাঙ্গুনিয়া', '', ''),
(78, 43, 'Raozan', 'রাউজান', '', ''),
(79, 43, 'Sandwip', 'সন্দ্বীপ', '', ''),
(80, 43, 'Satkania', 'সাতকানিয়া', '', ''),
(81, 43, 'Sitakunda', 'সীতাকুণ্ড', '', ''),
(82, 44, 'Barura', 'বড়ুরা', '', ''),
(83, 44, 'Brahmanpara', 'ব্রাহ্মণপাড়া', '', ''),
(84, 44, 'Burichong', 'বুড়িচং', '', ''),
(85, 44, 'Chandina', 'চান্দিনা', '', ''),
(86, 44, 'Chauddagram', 'চৌদ্দগ্রাম', '', ''),
(87, 44, 'Daudkandi', 'দাউদকান্দি', '', ''),
(88, 44, 'Debidwar', 'দেবীদ্বার', '', ''),
(89, 44, 'Homna', 'হোমনা', '', ''),
(90, 44, 'Comilla Sadar', 'কুমিল্লা সদর', '', ''),
(91, 44, 'Laksam', 'লাকসাম', '', ''),
(92, 44, 'Monohorgonj', 'মনোহরগঞ্জ', '', ''),
(93, 44, 'Meghna', 'মেঘনা', '', ''),
(94, 44, 'Muradnagar', 'মুরাদনগর', '', ''),
(95, 44, 'Nangalkot', 'নাঙ্গালকোট', '', ''),
(96, 44, 'Comilla Sadar South', 'কুমিল্লা সদর দক্ষিণ', '', ''),
(97, 44, 'Titas', 'তিতাস', '', ''),
(98, 45, 'Chakaria', 'চকরিয়া', '', ''),
(99, 45, 'Chakaria', 'চকরিয়া', '', ''),
(100, 45, 'Cox''s Bazar Sadar', 'কক্স বাজার সদর', '', ''),
(101, 45, 'Kutubdia', 'কুতুবদিয়া', '', ''),
(102, 45, 'Maheshkhali', 'মহেশখালী', '', ''),
(103, 45, 'Ramu', 'রামু', '', ''),
(104, 45, 'Teknaf', 'টেকনাফ', '', ''),
(105, 45, 'Ukhia', 'উখিয়া', '', ''),
(106, 45, 'Pekua', 'পেকুয়া', '', ''),
(107, 46, 'Feni Sadar', 'ফেনী সদর', '', ''),
(108, 46, 'Chagalnaiya', 'ছাগল নাইয়া', '', ''),
(109, 46, 'Daganbhyan', 'দাগানভিয়া', '', ''),
(110, 46, 'Parshuram', 'পরশুরাম', '', ''),
(111, 46, 'Fhulgazi', 'ফুলগাজি', '', ''),
(112, 46, 'Sonagazi', 'সোনাগাজি', '', ''),
(113, 47, 'Dighinala', 'দিঘিনালা ', '', ''),
(114, 47, 'Khagrachhari', 'খাগড়াছড়ি', '', ''),
(115, 47, 'Lakshmichhari', 'লক্ষ্মীছড়ি', '', ''),
(116, 47, 'Mahalchhari', 'মহলছড়ি', '', ''),
(117, 47, 'Manikchhari', 'মানিকছড়ি', '', ''),
(118, 47, 'Matiranga', 'মাটিরাঙ্গা', '', ''),
(119, 47, 'Panchhari', 'পানছড়ি', '', ''),
(120, 47, 'Ramgarh', 'রামগড়', '', ''),
(121, 48, 'Lakshmipur Sadar', 'লক্ষ্মীপুর সদর', '', ''),
(122, 48, 'Raipur', 'রায়পুর', '', ''),
(123, 48, 'Ramganj', 'রামগঞ্জ', '', ''),
(124, 48, 'Ramgati', 'রামগতি', '', ''),
(125, 48, 'Komol Nagar', 'কমল নগর', '', ''),
(126, 49, 'Noakhali Sadar', 'নোয়াখালী সদর', '', ''),
(127, 49, 'Begumganj', 'বেগমগঞ্জ', '', ''),
(128, 49, 'Chatkhil', 'চাটখিল', '', ''),
(129, 49, 'Companyganj', 'কোম্পানীগঞ্জ', '', ''),
(130, 49, 'Shenbag', 'শেনবাগ', '', ''),
(131, 49, 'Hatia', 'হাতিয়া', '', ''),
(132, 49, 'Kobirhat', 'কবিরহাট ', '', ''),
(133, 49, 'Sonaimuri', 'সোনাইমুরি', '', ''),
(134, 49, 'Suborno Char', 'সুবর্ণ চর ', '', ''),
(135, 50, 'Rangamati Sadar', 'রাঙ্গামাটি সদর', '', ''),
(136, 50, 'Belaichhari', 'বেলাইছড়ি', '', ''),
(137, 50, 'Bagaichhari', 'বাঘাইছড়ি', '', ''),
(138, 50, 'Barkal', 'বরকল', '', ''),
(139, 50, 'Juraichhari', 'জুরাইছড়ি', '', ''),
(140, 50, 'Rajasthali', 'রাজাস্থলি', '', ''),
(141, 50, 'Kaptai', 'কাপ্তাই', '', ''),
(142, 50, 'Langadu', 'লাঙ্গাডু', '', ''),
(143, 50, 'Nannerchar', 'নান্নেরচর ', '', ''),
(144, 50, 'Kaukhali', 'কাউখালি', '', ''),
(145, 1, 'Dhamrai', 'ধামরাই', '', ''),
(146, 1, 'Dohar', 'দোহার', '', ''),
(147, 1, 'Keraniganj', 'কেরানীগঞ্জ', '', ''),
(149, 1, 'Savar', 'সাভার', '', ''),
(150, 2, 'Faridpur Sadar', 'ফরিদপুর সদর', '', ''),
(151, 2, 'Boalmari', 'বোয়ালমারী', '', ''),
(152, 2, 'Alfadanga', 'আলফাডাঙ্গা', '', ''),
(153, 2, 'Madhukhali', 'মধুখালি', '', ''),
(154, 2, 'Bhanga', 'ভাঙ্গা', '', ''),
(155, 2, 'Nagarkanda', 'নগরকান্ড', '', ''),
(156, 2, 'Charbhadrasan', 'চরভদ্রাসন ', '', ''),
(157, 2, 'Sadarpur', 'সদরপুর', '', ''),
(158, 2, 'Shaltha', 'শালথা', '', ''),
(159, 3, 'Gazipur Sadar-Joydebpur', 'গাজীপুর সদর', '', ''),
(160, 3, 'Kaliakior', 'কালিয়াকৈর', '', ''),
(161, 3, 'Kapasia', 'কাপাসিয়া', '', ''),
(162, 3, 'Sripur', 'শ্রীপুর', '', ''),
(163, 3, 'Kaliganj', 'কালীগঞ্জ', '', ''),
(164, 3, 'Tongi', 'টঙ্গি', '', ''),
(165, 4, 'Gopalganj Sadar', 'গোপালগঞ্জ সদর', '', ''),
(166, 4, 'Kashiani', 'কাশিয়ানি', '', ''),
(167, 4, 'Kotalipara', 'কোটালিপাড়া', '', ''),
(168, 4, 'Muksudpur', 'মুকসুদপুর', '', ''),
(169, 4, 'Tungipara', 'টুঙ্গিপাড়া', '', ''),
(170, 5, 'Dewanganj', 'দেওয়ানগঞ্জ', '', ''),
(171, 5, 'Baksiganj', 'বকসিগঞ্জ', '', ''),
(172, 5, 'Islampur', 'ইসলামপুর', '', ''),
(173, 5, 'Jamalpur Sadar', 'জামালপুর সদর', '', ''),
(174, 5, 'Madarganj', 'মাদারগঞ্জ', '', ''),
(175, 5, 'Melandaha', 'মেলানদাহা', '', ''),
(176, 5, 'Sarishabari', 'সরিষাবাড়ি ', '', ''),
(177, 5, 'Narundi Police I.C', 'নারুন্দি', '', ''),
(178, 6, 'Astagram', 'অষ্টগ্রাম', '', ''),
(179, 6, 'Bajitpur', 'বাজিতপুর', '', ''),
(180, 6, 'Bhairab', 'ভৈরব', '', ''),
(181, 6, 'Hossainpur', 'হোসেনপুর ', '', ''),
(182, 6, 'Itna', 'ইটনা', '', ''),
(183, 6, 'Karimganj', 'করিমগঞ্জ', '', ''),
(184, 6, 'Katiadi', 'কতিয়াদি', '', ''),
(185, 6, 'Kishoreganj Sadar', 'কিশোরগঞ্জ সদর', '', ''),
(186, 6, 'Kuliarchar', 'কুলিয়ারচর', '', ''),
(187, 6, 'Mithamain', 'মিঠামাইন', '', ''),
(188, 6, 'Nikli', 'নিকলি', '', ''),
(189, 6, 'Pakundia', 'পাকুন্ডা', '', ''),
(190, 6, 'Tarail', 'তাড়াইল', '', ''),
(191, 7, 'Madaripur Sadar', 'মাদারীপুর সদর', '', ''),
(192, 7, 'Kalkini', 'কালকিনি', '', ''),
(193, 7, 'Rajoir', 'রাজইর', '', ''),
(194, 7, 'Shibchar', 'শিবচর', '', ''),
(195, 8, 'Manikganj Sadar', 'মানিকগঞ্জ সদর', '', ''),
(196, 8, 'Singair', 'সিঙ্গাইর', '', ''),
(197, 8, 'Shibalaya', 'শিবালয়', '', ''),
(198, 8, 'Saturia', 'সাঠুরিয়া', '', ''),
(199, 8, 'Harirampur', 'হরিরামপুর', '', ''),
(200, 8, 'Ghior', 'ঘিওর', '', ''),
(201, 8, 'Daulatpur', 'দৌলতপুর', '', ''),
(202, 9, 'Lohajang', 'লোহাজং', '', ''),
(203, 9, 'Sreenagar', 'শ্রীনগর', '', ''),
(204, 9, 'Munshiganj Sadar', 'মুন্সিগঞ্জ সদর', '', ''),
(205, 9, 'Sirajdikhan', 'সিরাজদিখান', '', ''),
(206, 9, 'Tongibari', 'টঙ্গিবাড়ি', '', ''),
(207, 9, 'Gazaria', 'গজারিয়া', '', ''),
(208, 10, 'Bhaluka', 'ভালুকা', '', ''),
(209, 10, 'Trishal', 'ত্রিশাল', '', ''),
(210, 10, 'Haluaghat', 'হালুয়াঘাট', '', ''),
(211, 10, 'Muktagachha', 'মুক্তাগাছা', '', ''),
(212, 10, 'Dhobaura', 'ধবারুয়া', '', ''),
(213, 10, 'Fulbaria', 'ফুলবাড়িয়া', '', ''),
(214, 10, 'Gaffargaon', 'গফরগাঁও', '', ''),
(215, 10, 'Gauripur', 'গৌরিপুর', '', ''),
(216, 10, 'Ishwarganj', 'ঈশ্বরগঞ্জ', '', ''),
(217, 10, 'Mymensingh Sadar', 'ময়মনসিং সদর', '', ''),
(218, 10, 'Nandail', 'নন্দাইল', '', ''),
(219, 10, 'Phulpur', 'ফুলপুর', '', ''),
(220, 11, 'Araihazar', 'আড়াইহাজার', '', ''),
(221, 11, 'Sonargaon', 'সোনারগাঁও', '', ''),
(222, 11, 'Bandar', 'বান্দার', '', ''),
(223, 11, 'Naryanganj Sadar', 'নারায়ানগঞ্জ সদর', '', ''),
(224, 11, 'Rupganj', 'রূপগঞ্জ', '', ''),
(225, 11, 'Siddirgonj', 'সিদ্ধিরগঞ্জ', '', ''),
(226, 12, 'Belabo', 'বেলাবো', '', ''),
(227, 12, 'Monohardi', 'মনোহরদি', '', ''),
(228, 12, 'Narsingdi Sadar', 'নরসিংদী সদর', '', ''),
(229, 12, 'Palash', 'পলাশ', '', ''),
(230, 12, 'Raipura, Narsingdi', 'রায়পুর', '', ''),
(231, 12, 'Shibpur', 'শিবপুর', '', ''),
(232, 13, 'Kendua Upazilla', 'কেন্দুয়া', '', ''),
(233, 13, 'Atpara Upazilla', 'আটপাড়া', '', ''),
(234, 13, 'Barhatta Upazilla', 'বরহাট্টা', '', ''),
(235, 13, 'Durgapur Upazilla', 'দুর্গাপুর', '', ''),
(236, 13, 'Kalmakanda Upazilla', 'কলমাকান্দা', '', ''),
(237, 13, 'Madan Upazilla', 'মদন', '', ''),
(238, 13, 'Mohanganj Upazilla', 'মোহনগঞ্জ', '', ''),
(239, 13, 'Netrakona-S Upazilla', 'নেত্রকোনা সদর', '', ''),
(240, 13, 'Purbadhala Upazilla', 'পূর্বধলা', '', ''),
(241, 13, 'Khaliajuri Upazilla', 'খালিয়াজুরি', '', ''),
(242, 14, 'Baliakandi', 'বালিয়াকান্দি', '', ''),
(243, 14, 'Goalandaghat', 'গোয়ালন্দ ঘাট', '', ''),
(244, 14, 'Pangsha', 'পাংশা', '', ''),
(245, 14, 'Kalukhali', 'কালুখালি', '', ''),
(246, 14, 'Rajbari Sadar', 'রাজবাড়ি সদর', '', ''),
(247, 15, 'Shariatpur Sadar -Palong', 'শরীয়তপুর সদর ', '', ''),
(248, 15, 'Damudya', 'দামুদিয়া', '', ''),
(249, 15, 'Naria', 'নড়িয়া', '', ''),
(250, 15, 'Jajira', 'জাজিরা', '', ''),
(251, 15, 'Bhedarganj', 'ভেদারগঞ্জ', '', ''),
(252, 15, 'Gosairhat', 'গোসাইর হাট ', '', ''),
(253, 16, 'Jhenaigati', 'ঝিনাইগাতি', '', ''),
(254, 16, 'Nakla', 'নাকলা', '', ''),
(255, 16, 'Nalitabari', 'নালিতাবাড়ি', '', ''),
(256, 16, 'Sherpur Sadar', 'শেরপুর সদর', '', ''),
(257, 16, 'Sreebardi', 'শ্রীবরদি', '', ''),
(258, 17, 'Tangail Sadar', 'টাঙ্গাইল সদর', '', ''),
(259, 17, 'Sakhipur', 'সখিপুর', '', ''),
(260, 17, 'Basail', 'বসাইল', '', ''),
(261, 17, 'Madhupur', 'মধুপুর', '', ''),
(262, 17, 'Ghatail', 'ঘাটাইল', '', ''),
(263, 17, 'Kalihati', 'কালিহাতি', '', ''),
(264, 17, 'Nagarpur', 'নগরপুর', '', ''),
(265, 17, 'Mirzapur', 'মির্জাপুর', '', ''),
(266, 17, 'Gopalpur', 'গোপালপুর', '', ''),
(267, 17, 'Delduar', 'দেলদুয়ার', '', ''),
(268, 17, 'Bhuapur', 'ভুয়াপুর', '', ''),
(269, 17, 'Dhanbari', 'ধানবাড়ি', '', ''),
(270, 55, 'Bagerhat Sadar', 'বাগেরহাট সদর', '', ''),
(271, 55, 'Chitalmari', 'চিতলমাড়ি', '', ''),
(272, 55, 'Fakirhat', 'ফকিরহাট', '', ''),
(273, 55, 'Kachua', 'কচুয়া', '', ''),
(274, 55, 'Mollahat', 'মোল্লাহাট ', '', ''),
(275, 55, 'Mongla', 'মংলা', '', ''),
(276, 55, 'Morrelganj', 'মরেলগঞ্জ', '', ''),
(277, 55, 'Rampal', 'রামপাল', '', ''),
(278, 55, 'Sarankhola', 'স্মরণখোলা', '', ''),
(279, 56, 'Damurhuda', 'দামুরহুদা', '', ''),
(280, 56, 'Chuadanga-S', 'চুয়াডাঙ্গা সদর', '', ''),
(281, 56, 'Jibannagar', 'জীবন নগর ', '', ''),
(282, 56, 'Alamdanga', 'আলমডাঙ্গা', '', ''),
(283, 57, 'Abhaynagar', 'অভয়নগর', '', ''),
(284, 57, 'Keshabpur', 'কেশবপুর', '', ''),
(285, 57, 'Bagherpara', 'বাঘের পাড়া ', '', ''),
(286, 57, 'Jessore Sadar', 'যশোর সদর', '', ''),
(287, 57, 'Chaugachha', 'চৌগাছা', '', ''),
(288, 57, 'Manirampur', 'মনিরামপুর ', '', ''),
(289, 57, 'Jhikargachha', 'ঝিকরগাছা', '', ''),
(290, 57, 'Sharsha', 'সারশা', '', ''),
(291, 58, 'Jhenaidah Sadar', 'ঝিনাইদহ সদর', '', ''),
(292, 58, 'Maheshpur', 'মহেশপুর', '', ''),
(293, 58, 'Kaliganj', 'কালীগঞ্জ', '', ''),
(294, 58, 'Kotchandpur', 'কোট চাঁদপুর ', '', ''),
(295, 58, 'Shailkupa', 'শৈলকুপা', '', ''),
(296, 58, 'Harinakunda', 'হাড়িনাকুন্দা', '', ''),
(297, 59, 'Terokhada', 'তেরোখাদা', '', ''),
(298, 59, 'Batiaghata', 'বাটিয়াঘাটা ', '', ''),
(299, 59, 'Dacope', 'ডাকপে', '', ''),
(300, 59, 'Dumuria', 'ডুমুরিয়া', '', ''),
(301, 59, 'Dighalia', 'দিঘলিয়া', '', ''),
(302, 59, 'Koyra', 'কয়ড়া', '', ''),
(303, 59, 'Paikgachha', 'পাইকগাছা', '', ''),
(304, 59, 'Phultala', 'ফুলতলা', '', ''),
(305, 59, 'Rupsa', 'রূপসা', '', ''),
(306, 60, 'Kushtia Sadar', 'কুষ্টিয়া সদর', '', ''),
(307, 60, 'Kumarkhali', 'কুমারখালি', '', ''),
(308, 60, 'Daulatpur', 'দৌলতপুর', 'Dowlatpur,Doulatpur', ''),
(309, 60, 'Mirpur', 'মিরপুর', '', ''),
(310, 60, 'Bheramara', 'ভেরামারা', 'Veramara', ''),
(311, 60, 'Khoksa', 'খোকসা', '', ''),
(312, 61, 'Magura Sadar', 'মাগুরা সদর', '', ''),
(313, 61, 'Mohammadpur', 'মোহাম্মাদপুর', 'Muhammadpur', ''),
(314, 61, 'Shalikha', 'শালিখা', 'Salikha', ''),
(315, 61, 'Sreepur', 'শ্রীপুর', 'Sripur', ''),
(316, 62, 'angni', 'আংনি', '', ''),
(317, 62, 'Mujib Nagar', 'মুজিব নগর', '', ''),
(318, 62, 'Meherpur-S', 'মেহেরপুর সদর', '', ''),
(319, 63, 'Narail-S Upazilla', 'নড়াইল সদর', 'Norail Sadar', ''),
(320, 63, 'Lohagara Upazilla', 'লোহাগাড়া', '', ''),
(321, 63, 'Kalia Upazilla', 'কালিয়া', '', ''),
(322, 64, 'Satkhira Sadar', 'সাতক্ষীরা সদর', '', ''),
(323, 64, 'Assasuni', 'আসসাশুনি ', '', ''),
(324, 64, 'Debhata', 'দেভাটা', '', ''),
(325, 64, 'Tala', 'তালা', '', ''),
(326, 64, 'Kalaroa', 'কলরোয়া', 'Koloroa', ''),
(327, 64, 'Kaliganj', 'কালীগঞ্জ', '', ''),
(328, 64, 'Shyamnagar', 'শ্যামনগর', 'Shamnogor, Shamnagar,Shamnogar', ''),
(329, 18, 'Adamdighi', 'আদমদিঘী', '', ''),
(330, 18, 'Bogra Sadar', 'বগুড়া সদর', '', ''),
(331, 18, 'Sherpur', 'শেরপুর', '', ''),
(332, 18, 'Dhunat', 'ধুনট', '', ''),
(333, 18, 'Dhupchanchia', 'দুপচাচিয়া', '', ''),
(334, 18, 'Gabtali', 'গাবতলি', '', ''),
(335, 18, 'Kahaloo', 'কাহালু', '', ''),
(336, 18, 'Nandigram', 'নন্দিগ্রাম', '', ''),
(337, 18, 'Sahajanpur', 'শাহজাহানপুর', '', ''),
(338, 18, 'Sariakandi', 'সারিয়াকান্দি', '', ''),
(339, 18, 'Shibganj', 'শিবগঞ্জ', '', ''),
(340, 18, 'Sonatala', 'সোনাতলা', '', ''),
(341, 19, 'Joypurhat S', 'জয়পুরহাট সদর', '', ''),
(342, 19, 'Akkelpur', 'আক্কেলপুর', '', ''),
(343, 19, 'Kalai', 'কালাই', '', ''),
(344, 19, 'Khetlal', 'খেতলাল', '', ''),
(345, 19, 'Panchbibi', 'পাঁচবিবি', '', ''),
(346, 20, 'Naogaon Sadar', 'নওগাঁ সদর', '', ''),
(347, 20, 'Mohadevpur', 'মহাদেবপুর', '', ''),
(348, 20, 'Manda', 'মান্দা', '', ''),
(349, 20, 'Niamatpur', 'নিয়ামতপুর', '', ''),
(350, 20, 'Atrai', 'আত্রাই', '', ''),
(351, 20, 'Raninagar', 'রাণীনগর', '', ''),
(352, 20, 'Patnitala', 'পত্নীতলা', '', ''),
(353, 20, 'Dhamoirhat', 'ধামইরহাট ', '', ''),
(354, 20, 'Sapahar', 'সাপাহার', '', ''),
(355, 20, 'Porsha', 'পোরশা', '', ''),
(356, 20, 'Badalgachhi', 'বদলগাছি', '', ''),
(357, 21, 'Natore Sadar', 'নাটোর সদর', '', ''),
(358, 21, 'Baraigram', 'বড়াইগ্রাম', '', ''),
(359, 21, 'Bagatipara', 'বাগাতিপাড়া', '', ''),
(360, 21, 'Lalpur', 'লালপুর', '', ''),
(361, 21, 'Natore Sadar', 'নাটোর সদর', '', ''),
(362, 21, 'Baraigram', 'বড়াই গ্রাম', '', ''),
(363, 22, 'Bholahat', 'ভোলাহাট', '', ''),
(364, 22, 'Gomastapur', 'গোমস্তাপুর', '', ''),
(365, 22, 'Nachole', 'নাচোল', '', ''),
(366, 22, 'Nawabganj Sadar', 'নবাবগঞ্জ সদর', '', ''),
(367, 22, 'Shibganj', 'শিবগঞ্জ', '', ''),
(368, 23, 'Atgharia', 'আটঘরিয়া', '', ''),
(369, 23, 'Bera', 'বেড়া', '', ''),
(370, 23, 'Bhangura', 'ভাঙ্গুরা', '', ''),
(371, 23, 'Chatmohar', 'চাটমোহর', '', ''),
(372, 23, 'Faridpur', 'ফরিদপুর', '', ''),
(373, 23, 'Ishwardi', 'ঈশ্বরদী', '', ''),
(374, 23, 'Pabna Sadar', 'পাবনা সদর', '', ''),
(375, 23, 'Santhia', 'সাথিয়া', '', ''),
(376, 23, 'Sujanagar', 'সুজানগর', '', ''),
(377, 24, 'Bagha', 'বাঘা', '', ''),
(378, 24, 'Bagmara', 'বাগমারা', '', ''),
(379, 24, 'Charghat', 'চারঘাট', '', ''),
(380, 24, 'Durgapur', 'দুর্গাপুর', '', ''),
(381, 24, 'Godagari', 'গোদাগারি', '', ''),
(382, 24, 'Mohanpur', 'মোহনপুর', '', ''),
(383, 24, 'Paba', 'পবা', '', ''),
(384, 24, 'Puthia', 'পুঠিয়া', '', ''),
(385, 24, 'Tanore', 'তানোর', '', ''),
(386, 25, 'Sirajganj Sadar', 'সিরাজগঞ্জ সদর', '', ''),
(387, 25, 'Belkuchi', 'বেলকুচি', '', ''),
(388, 25, 'Chauhali', 'চৌহালি', '', ''),
(389, 25, 'Kamarkhanda', 'কামারখান্দা', '', ''),
(390, 25, 'Kazipur', 'কাজীপুর', '', ''),
(391, 25, 'Raiganj', 'রায়গঞ্জ', '', ''),
(392, 25, 'Shahjadpur', 'শাহজাদপুর', '', ''),
(393, 25, 'Tarash', 'তারাশ', '', ''),
(394, 25, 'Ullahpara', 'উল্লাপাড়া', '', ''),
(395, 26, 'Birampur', 'বিরামপুর', '', ''),
(396, 26, 'Birganj', 'বীরগঞ্জ', '', ''),
(397, 26, 'Biral', 'বিড়াল', '', ''),
(398, 26, 'Bochaganj', 'বোচাগঞ্জ', '', ''),
(399, 26, 'Chirirbandar', 'চিরিরবন্দর', '', ''),
(400, 26, 'Phulbari', 'ফুলবাড়ি', '', ''),
(401, 26, 'Ghoraghat', 'ঘোড়াঘাট', '', ''),
(402, 26, 'Hakimpur', 'হাকিমপুর', '', ''),
(403, 26, 'Kaharole', 'কাহারোল', '', ''),
(404, 26, 'Khansama', 'খানসামা', '', ''),
(405, 26, 'Dinajpur Sadar', 'দিনাজপুর সদর', '', ''),
(406, 26, 'Nawabganj', 'নবাবগঞ্জ', '', ''),
(407, 26, 'Parbatipur', 'পার্বতীপুর', '', ''),
(408, 27, 'Fulchhari', 'ফুলছড়ি', '', ''),
(409, 27, 'Gaibandha sadar', 'গাইবান্ধা সদর', '', ''),
(410, 27, 'Gobindaganj', 'গোবিন্দগঞ্জ', '', ''),
(411, 27, 'Palashbari', 'পলাশবাড়ী', '', ''),
(412, 27, 'Sadullapur', 'সাদুল্যাপুর', '', ''),
(413, 27, 'Saghata', 'সাঘাটা', '', ''),
(414, 27, 'Sundarganj', 'সুন্দরগঞ্জ', '', ''),
(415, 28, 'Kurigram Sadar', 'কুড়িগ্রাম সদর', '', ''),
(416, 28, 'Nageshwari', 'নাগেশ্বরী', '', ''),
(417, 28, 'Bhurungamari', 'ভুরুঙ্গামারি', '', ''),
(418, 28, 'Phulbari', 'ফুলবাড়ি', '', ''),
(419, 28, 'Rajarhat', 'রাজারহাট', '', ''),
(420, 28, 'Ulipur', 'উলিপুর', '', ''),
(421, 28, 'Chilmari', 'চিলমারি', '', ''),
(422, 28, 'Rowmari', 'রউমারি', '', ''),
(423, 28, 'Char Rajibpur', 'চর রাজিবপুর', '', ''),
(424, 29, 'Lalmanirhat Sadar', 'লালমনিরহাট সদর', '', ''),
(425, 29, 'Aditmari', 'আদিতমারি', '', ''),
(426, 29, 'Kaliganj', 'কালীগঞ্জ', '', ''),
(427, 29, 'Hatibandha', 'হাতিবান্ধা', '', ''),
(428, 29, 'Patgram', 'পাটগ্রাম', '', ''),
(429, 30, 'Nilphamari Sadar', 'নীলফামারী সদর', '', ''),
(430, 30, 'Saidpur', 'সৈয়দপুর', '', ''),
(431, 30, 'Jaldhaka', 'জলঢাকা', '', ''),
(432, 30, 'Kishoreganj', 'কিশোরগঞ্জ', '', ''),
(433, 30, 'Domar', 'ডোমার', '', ''),
(434, 30, 'Dimla', 'ডিমলা', '', ''),
(435, 31, 'Panchagarh Sadar', 'পঞ্চগড় সদর', '', ''),
(436, 31, 'Debiganj', 'দেবীগঞ্জ', '', ''),
(437, 31, 'Boda', 'বোদা', '', ''),
(438, 31, 'Atwari', 'আটোয়ারি', '', ''),
(439, 31, 'Tetulia', 'তেতুলিয়া', '', ''),
(440, 32, 'Badarganj', 'বদরগঞ্জ', '', ''),
(441, 32, 'Mithapukur', 'মিঠাপুকুর', '', ''),
(442, 32, 'Gangachara', 'গঙ্গাচরা', '', ''),
(443, 32, 'Kaunia', 'কাউনিয়া', '', ''),
(444, 32, 'Rangpur Sadar', 'রংপুর সদর', '', ''),
(445, 32, 'Pirgachha', 'পীরগাছা', '', ''),
(446, 32, 'Pirganj', 'পীরগঞ্জ', '', ''),
(447, 32, 'Taraganj', 'তারাগঞ্জ', '', ''),
(448, 33, 'Thakurgaon Sadar', 'ঠাকুরগাঁও সদর', '', ''),
(449, 33, 'Pirganj', 'পীরগঞ্জ', '', ''),
(450, 33, 'Baliadangi', 'বালিয়াডাঙ্গি', '', ''),
(451, 33, 'Haripur', 'হরিপুর', '', ''),
(452, 33, 'Ranisankail', 'রাণীসংকইল', '', ''),
(453, 51, 'Ajmiriganj', 'আজমিরিগঞ্জ', '', ''),
(454, 51, 'Baniachang', 'বানিয়াচং', '', ''),
(455, 51, 'Bahubal', 'বাহুবল', '', ''),
(456, 51, 'Chunarughat', 'চুনারুঘাট', '', ''),
(457, 51, 'Habiganj Sadar', 'হবিগঞ্জ সদর', '', ''),
(458, 51, 'Lakhai', 'লাক্ষাই', '', ''),
(459, 51, 'Madhabpur', 'মাধবপুর', '', ''),
(460, 51, 'Nabiganj', 'নবীগঞ্জ', '', ''),
(461, 51, 'Shaistagonj', 'শায়েস্তাগঞ্জ', '', ''),
(462, 52, 'Moulvibazar Sadar', 'মৌলভীবাজার', '', ''),
(463, 52, 'Barlekha', 'বড়লেখা', '', ''),
(464, 52, 'Juri', 'জুড়ি', '', ''),
(465, 52, 'Kamalganj', 'কামালগঞ্জ', '', ''),
(466, 52, 'Kulaura', 'কুলাউরা', '', ''),
(467, 52, 'Rajnagar', 'রাজনগর', '', ''),
(468, 52, 'Sreemangal', 'শ্রীমঙ্গল', 'Srimangal,Srimongol,Srimangol', ''),
(469, 53, 'Bishwamvarpur', 'বিসশম্ভারপুর', '', ''),
(470, 53, 'Chhatak', 'ছাতক', 'Satak,Satok', ''),
(471, 53, 'Derai', 'দেড়াই', '', ''),
(472, 53, 'Dharampasha', 'ধরমপাশা', '', ''),
(473, 53, 'Dowarabazar', 'দোয়ারাবাজার', '', ''),
(474, 53, 'Jagannathpur', 'জগন্নাথপুর', '', ''),
(475, 53, 'Jamalganj', 'জামালগঞ্জ', '', ''),
(476, 53, 'Sulla', 'সুল্লা', '', ''),
(477, 53, 'Sunamganj Sadar', 'সুনামগঞ্জ সদর', '', ''),
(478, 53, 'Shanthiganj', 'শান্তিগঞ্জ', '', ''),
(479, 53, 'Tahirpur', 'তাহিরপুর', '', ''),
(480, 54, 'Sylhet Sadar', 'সিলেট সদর', '', ''),
(481, 54, 'Beanibazar', 'বেয়ানিবাজার', '', ''),
(482, 54, 'Bishwanath', 'বিশ্বনাথ', '', ''),
(483, 54, 'Dakshin Surma', 'দক্ষিণ সুরমা', '', ''),
(484, 54, 'Balaganj', 'বালাগঞ্জ', '', ''),
(485, 54, 'Companiganj', 'কোম্পানিগঞ্জ', '', ''),
(486, 54, 'Fenchuganj', 'ফেঞ্চুগঞ্জ', '', ''),
(487, 54, 'Golapganj', 'গোলাপগঞ্জ', '', ''),
(488, 54, 'Gowainghat', 'গোয়াইনঘাট', '', ''),
(489, 54, 'Jaintiapur', 'জয়ন্তপুর', '', ''),
(490, 54, 'Kanaighat', 'কানাইঘাট', '', ''),
(491, 54, 'Zakiganj', 'জাকিগঞ্জ', '', ''),
(492, 54, 'Nobigonj', 'নবীগঞ্জ', '', ''),
(493, 1, 'Mohammadpur', 'মোহাম্মাদপুর', '', ''),
(496, 1, 'Adabor', 'আদাবর', '', ''),
(497, 1, 'Badda', 'বাড্ডা', '', ''),
(499, 1, 'Bongsal', 'বংশাল', '', ''),
(500, 1, 'Bimanbandar', 'বিমানবন্দর', '', ''),
(501, 1, 'Cantonment', 'ক্যান্টনমেন্ট', '', ''),
(502, 1, 'Chak Bazar', 'চকবাজার', '', ''),
(503, 1, 'Dakshinkhan', 'দক্ষিনখান', '', ''),
(504, 1, 'Darus Salam', 'দারস সালাম', '', ''),
(506, 1, 'Demra ', 'ডেমরা', '', ''),
(507, 1, 'Dhanmondi', 'ধানমন্ডি', '', ''),
(508, 1, 'Gendaria', 'গেন্ডারিয়া', '', ''),
(509, 1, 'Gulshan', 'গুলশান', '', ''),
(510, 1, 'Hazaribagh', 'হাজারীবাগ', '', ''),
(511, 1, 'Jatrabari', 'যাত্রাবাড়ি', '', ''),
(512, 1, 'Kadamtali', 'কদমতলী', 'Kodomtoli,Kadomtoli,Kodamtoli', ''),
(513, 1, 'Kafrul', 'কাফরুল', 'Kafrool', ''),
(514, 1, 'Kalabagan', 'কলাবাগান', 'Kolabagan', ''),
(515, 1, 'Kamrangirchar', 'কামরাঙ্গীরচর', 'Kamrangirchor', ''),
(516, 1, 'Khilgaon', 'খিলগাও', '', ''),
(517, 1, 'khilkhet', 'খিলক্ষেত', '', ''),
(518, 1, 'Kotwali', 'কোতয়ালী', 'Kotoali,Kotowali', ''),
(519, 1, 'Lalbagh', 'লালবাগ', 'Lalbag', ''),
(520, 1, 'Mirpur', 'মিরপুর', '', ''),
(521, 1, 'Motijheel', 'মতিঝিল', 'Matijhil', ''),
(522, 1, 'Nawabganj', 'নবাবগন্জ', 'Nababganj,Nobabganj,Nababgonj', ''),
(523, 1, 'Newmarket', 'নিউমার্কেট', '', ''),
(524, 1, 'Pallabi', 'পল্লবী', 'Pollobi', ''),
(525, 1, 'Paltan', 'পল্টন', 'Polton', ''),
(526, 1, 'Ramna', 'রমনা', 'Romna', ''),
(527, 1, 'Rampura', 'রামপুরা', '', ''),
(528, 1, 'Sabujbagh', 'সবুজবাগ', '', ''),
(529, 1, 'Shah Ali', 'শাহআলী', '', ''),
(530, 1, 'Shahbag', 'শাহবাগ', '', ''),
(531, 1, 'Sher-e-Bangla Nagar', 'শের-ই-বাংলা', '', ''),
(532, 1, 'Shyampur', 'শ্যামপুর', '', ''),
(533, 1, 'Tejgaon', 'তেজগাও', '', ''),
(534, 1, 'Mohakhali', 'মহাখালি', '', ''),
(535, 1, 'Tejgaon Industrial Area', 'তেজগাও শিল্প এলাকা', '', ''),
(536, 1, 'Turag', 'তুরাগ', '', ''),
(537, 1, 'Uttara', 'উত্তরা', '', ''),
(538, 1, 'Uttar Khan', 'উত্তরখান', '', ''),
(539, 1, 'Banasree', 'বনশ্রী', '', ''),
(540, 1, 'Arambag', 'আরামবাগ', '', ''),
(541, 1, 'Wari', 'ওয়ারী', '', ''),
(542, 1, 'Banani', 'বনানী', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `transport_points`
--

CREATE TABLE `transport_points` (
  `id` int(10) UNSIGNED NOT NULL,
  `transport_id` int(10) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `point` tinyint(4) NOT NULL,
  `note` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `notification_msg` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `happened_at` datetime NOT NULL,
  `read` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `reputation` int(11) NOT NULL,
  `email` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `mobile` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` datetime NOT NULL,
  `last_logged` datetime NOT NULL,
  `user_type` enum('admin','manager','supervisor','user') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'user',
  `avatar` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `reputation`, `email`, `mobile`, `reg_date`, `last_logged`, `user_type`, `avatar`, `status`) VALUES
(2, 'rejoan', '0630c35dd69111d677fc36f0dfdb400c', 3, 'rejoan.er@gmail.com', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'admin', 'zce-php-engineer-logo-l.jpg', 1),
(4, 'anonymus', '81dc9bdb52d04dc20036dbd8313ed055', 0, 'anonymus@gmail.com', '01961349181', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'user', '', 1),
(6, 'rezwan', '0630c35dd69111d677fc36f0dfdb400c', 54, 'refatju@yahoo.com', '', '2016-12-31 12:51:48', '0000-00-00 00:00:00', 'user', 'PNG_transparency_demonstration_1.png', 1),
(8, 'symun', '0933dc8427a3a4e92bbeeaeb96393e36', 0, 'symun92@gmail.com', '01670765112', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'user', '', 1),
(9, 'zcpefaisal', 'd41d8cd98f00b204e9800998ecf8427e', 0, 'inboxlions@gmail.com', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'user', 'faisal.jpg', 1),
(10, 'awolad', '125d0ff9bcc6ce6786cdad33fa297f07', 0, 'awolad1122@gmail.com', '01723874408', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'user', '', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_route_meta_routes` (`route_id`),
  ADD KEY `FK_route_meta_users` (`user_id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `counter_address`
--
ALTER TABLE `counter_address`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_counter_address_poribohons` (`poribohon_id`),
  ADD KEY `FK_counter_address_districts` (`district`),
  ADD KEY `FK_counter_address_thanas` (`thana`);

--
-- Indexes for table `districts`
--
ALTER TABLE `districts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `drivers`
--
ALTER TABLE `drivers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `edited_counters`
--
ALTER TABLE `edited_counters`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_edited_counters_districts` (`district`),
  ADD KEY `FK_edited_counters_thanas` (`thana`),
  ADD KEY `FK_edited_counters_poribohons` (`poribohon_id`);

--
-- Indexes for table `edited_poribohons`
--
ALTER TABLE `edited_poribohons`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_edited_poribohons_poribohons` (`poribohon_id`),
  ADD KEY `FK_edited_poribohons_users` (`added_by`);

--
-- Indexes for table `edited_routes`
--
ALTER TABLE `edited_routes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_edited_routes_routes` (`route_id`),
  ADD KEY `FK_edited_routes_users` (`added_by`),
  ADD KEY `FK_edited_routes_poribohons` (`poribohon_id`),
  ADD KEY `FK_edited_routes_districts` (`from_district`),
  ADD KEY `FK_edited_routes_thanas` (`from_thana`),
  ADD KEY `FK_edited_routes_districts_2` (`to_district`),
  ADD KEY `FK_edited_routes_thanas_2` (`to_thana`);

--
-- Indexes for table `edited_stoppages`
--
ALTER TABLE `edited_stoppages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK__routes` (`route_id`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `point_paid`
--
ALTER TABLE `point_paid`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_verifications_routes` (`user_id`);

--
-- Indexes for table `poribohons`
--
ALTER TABLE `poribohons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `bn_name` (`bn_name`),
  ADD KEY `FK_poribohons_users` (`added_by`);

--
-- Indexes for table `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_profiles_users` (`user_id`),
  ADD KEY `FK_profiles_districts` (`district`),
  ADD KEY `FK_profiles_thanas` (`thana`);

--
-- Indexes for table `routes`
--
ALTER TABLE `routes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_routes_users` (`added_by`),
  ADD KEY `from_place` (`from_place`),
  ADD KEY `to_place` (`to_place`),
  ADD KEY `FK_routes_districts` (`from_district`),
  ADD KEY `FK_routes_thanas` (`from_thana`),
  ADD KEY `FK_routes_districts_2` (`to_district`),
  ADD KEY `FK_routes_thanas_2` (`to_thana`),
  ADD KEY `FK_routes_poribohons` (`poribohon_id`);

--
-- Indexes for table `route_bn`
--
ALTER TABLE `route_bn`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_route_translation_routes` (`route_id`);

--
-- Indexes for table `route_complains`
--
ALTER TABLE `route_complains`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK__users` (`user_id`),
  ADD KEY `FK__routes` (`route_id`);

--
-- Indexes for table `route_points`
--
ALTER TABLE `route_points`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_route_points_users` (`user_id`),
  ADD KEY `FK_route_points_routes` (`route_id`);

--
-- Indexes for table `stoppages`
--
ALTER TABLE `stoppages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_stopages_routes` (`route_id`);

--
-- Indexes for table `stoppage_bn`
--
ALTER TABLE `stoppage_bn`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK__stoppages` (`route_id`);

--
-- Indexes for table `thanas`
--
ALTER TABLE `thanas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `district_id` (`district_id`);

--
-- Indexes for table `transport_points`
--
ALTER TABLE `transport_points`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_transport_points_poribohons` (`transport_id`),
  ADD KEY `FK_transport_points_users` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `type` (`user_type`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `counter_address`
--
ALTER TABLE `counter_address`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `districts`
--
ALTER TABLE `districts`
  MODIFY `id` int(2) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;
--
-- AUTO_INCREMENT for table `drivers`
--
ALTER TABLE `drivers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `edited_counters`
--
ALTER TABLE `edited_counters`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `edited_poribohons`
--
ALTER TABLE `edited_poribohons`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `edited_routes`
--
ALTER TABLE `edited_routes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `edited_stoppages`
--
ALTER TABLE `edited_stoppages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `point_paid`
--
ALTER TABLE `point_paid`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `poribohons`
--
ALTER TABLE `poribohons`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;
--
-- AUTO_INCREMENT for table `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `routes`
--
ALTER TABLE `routes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;
--
-- AUTO_INCREMENT for table `route_bn`
--
ALTER TABLE `route_bn`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;
--
-- AUTO_INCREMENT for table `route_complains`
--
ALTER TABLE `route_complains`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `route_points`
--
ALTER TABLE `route_points`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `stoppages`
--
ALTER TABLE `stoppages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=754;
--
-- AUTO_INCREMENT for table `stoppage_bn`
--
ALTER TABLE `stoppage_bn`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=739;
--
-- AUTO_INCREMENT for table `thanas`
--
ALTER TABLE `thanas`
  MODIFY `id` int(2) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=543;
--
-- AUTO_INCREMENT for table `transport_points`
--
ALTER TABLE `transport_points`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `FK_route_meta_routes` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_route_meta_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `counter_address`
--
ALTER TABLE `counter_address`
  ADD CONSTRAINT `FK_counter_address_districts` FOREIGN KEY (`district`) REFERENCES `districts` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_counter_address_poribohons` FOREIGN KEY (`poribohon_id`) REFERENCES `poribohons` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_counter_address_thanas` FOREIGN KEY (`thana`) REFERENCES `thanas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `edited_counters`
--
ALTER TABLE `edited_counters`
  ADD CONSTRAINT `FK_edited_counters_districts` FOREIGN KEY (`district`) REFERENCES `districts` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_edited_counters_poribohons` FOREIGN KEY (`poribohon_id`) REFERENCES `poribohons` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_edited_counters_thanas` FOREIGN KEY (`thana`) REFERENCES `thanas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `edited_poribohons`
--
ALTER TABLE `edited_poribohons`
  ADD CONSTRAINT `FK_edited_poribohons_poribohons` FOREIGN KEY (`poribohon_id`) REFERENCES `poribohons` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_edited_poribohons_users` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `edited_routes`
--
ALTER TABLE `edited_routes`
  ADD CONSTRAINT `FK_edited_routes_districts` FOREIGN KEY (`from_district`) REFERENCES `districts` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_edited_routes_districts_2` FOREIGN KEY (`to_district`) REFERENCES `districts` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_edited_routes_poribohons` FOREIGN KEY (`poribohon_id`) REFERENCES `poribohons` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_edited_routes_routes` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_edited_routes_thanas` FOREIGN KEY (`from_thana`) REFERENCES `thanas` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_edited_routes_thanas_2` FOREIGN KEY (`to_thana`) REFERENCES `thanas` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_edited_routes_users` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `edited_stoppages`
--
ALTER TABLE `edited_stoppages`
  ADD CONSTRAINT `FK_edited_stoppages_edited_routes` FOREIGN KEY (`route_id`) REFERENCES `edited_routes` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `point_paid`
--
ALTER TABLE `point_paid`
  ADD CONSTRAINT `FK_verifications_routes` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `poribohons`
--
ALTER TABLE `poribohons`
  ADD CONSTRAINT `FK_poribohons_users` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `profiles`
--
ALTER TABLE `profiles`
  ADD CONSTRAINT `FK_profiles_districts` FOREIGN KEY (`district`) REFERENCES `districts` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_profiles_thanas` FOREIGN KEY (`thana`) REFERENCES `thanas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_profiles_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `routes`
--
ALTER TABLE `routes`
  ADD CONSTRAINT `FK_routes_districts` FOREIGN KEY (`from_district`) REFERENCES `districts` (`id`) ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_routes_districts_2` FOREIGN KEY (`to_district`) REFERENCES `districts` (`id`) ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_routes_poribohons` FOREIGN KEY (`poribohon_id`) REFERENCES `poribohons` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_routes_thanas` FOREIGN KEY (`from_thana`) REFERENCES `thanas` (`id`) ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_routes_thanas_2` FOREIGN KEY (`to_thana`) REFERENCES `thanas` (`id`) ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_routes_users` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON UPDATE NO ACTION;

--
-- Constraints for table `route_bn`
--
ALTER TABLE `route_bn`
  ADD CONSTRAINT `FK_route_translation_routes` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `route_complains`
--
ALTER TABLE `route_complains`
  ADD CONSTRAINT `FK__routes` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK__users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `route_points`
--
ALTER TABLE `route_points`
  ADD CONSTRAINT `FK_route_points_routes` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_route_points_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `stoppages`
--
ALTER TABLE `stoppages`
  ADD CONSTRAINT `FK_stoppages_routes` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `stoppage_bn`
--
ALTER TABLE `stoppage_bn`
  ADD CONSTRAINT `FK__stoppages` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `thanas`
--
ALTER TABLE `thanas`
  ADD CONSTRAINT `thanas_ibfk_1` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `transport_points`
--
ALTER TABLE `transport_points`
  ADD CONSTRAINT `FK_transport_points_poribohons` FOREIGN KEY (`transport_id`) REFERENCES `poribohons` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_transport_points_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
