--
-- Database: `web_poth`
--

DELIMITER $$
--
-- Functions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `levenshtein` (`s1` VARCHAR(255), `s2` VARCHAR(255)) RETURNS INT(11) BEGIN
DECLARE s1_len, s2_len, i, j, c, c_temp, cost INT;
DECLARE s1_char CHAR;
-- max strlen=255
DECLARE cv0, cv1 VARBINARY(256);
SET s1_len = CHAR_LENGTH(s1), s2_len = CHAR_LENGTH(s2), cv1 = 0x00, j = 1, i = 1, c = 0;
IF s1 = s2 THEN
RETURN 0;
ELSEIF s1_len = 0 THEN
RETURN s2_len;
ELSEIF s2_len = 0 THEN
RETURN s1_len;
ELSE
WHILE j <= s2_len DO
SET cv1 = CONCAT(cv1, UNHEX(HEX(j))), j = j + 1;
END WHILE;
WHILE i <= s1_len DO
SET s1_char = SUBSTRING(s1, i, 1), c = i, cv0 = UNHEX(HEX(i)), j = 1;
WHILE j <= s2_len DO
SET c = c + 1;
IF s1_char = SUBSTRING(s2, j, 1) THEN
SET cost = 0; ELSE SET cost = 1;
END IF;
SET c_temp = CONV(HEX(SUBSTRING(cv1, j, 1)), 16, 10) + cost;
IF c > c_temp THEN SET c = c_temp; END IF;
SET c_temp = CONV(HEX(SUBSTRING(cv1, j+1, 1)), 16, 10) + 1;
IF c > c_temp THEN
SET c = c_temp;
END IF;
SET cv0 = CONCAT(cv0, UNHEX(HEX(c))), j = j + 1;
END WHILE;
SET cv1 = cv0, i = i + 1;
END WHILE;
END IF;
RETURN c;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

CREATE TABLE `districts` (
  `id` int(2) UNSIGNED NOT NULL,
  `name` varchar(30) NOT NULL,
  `bn_name` varchar(50) NOT NULL,
  `lat` double NOT NULL,
  `lon` double NOT NULL,
  `website` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`id`, `name`, `bn_name`, `lat`, `lon`, `website`) VALUES
(1, 'Dhaka', 'ঢাকা', 23.7115253, 90.4111451, 'www.dhaka.gov.bd'),
(2, 'Faridpur', 'ফরিদপুর', 23.6070822, 89.8429406, 'www.faridpur.gov.bd'),
(3, 'Gazipur', 'গাজীপুর', 24.0022858, 90.4264283, 'www.gazipur.gov.bd'),
(4, 'Gopalganj', 'গোপালগঞ্জ', 23.0050857, 89.8266059, 'www.gopalganj.gov.bd'),
(5, 'Jamalpur', 'জামালপুর', 24.937533, 89.937775, 'www.jamalpur.gov.bd'),
(6, 'Kishoreganj', 'কিশোরগঞ্জ', 24.444937, 90.776575, 'www.kishoreganj.gov.bd'),
(7, 'Madaripur', 'মাদারীপুর', 23.164102, 90.1896805, 'www.madaripur.gov.bd'),
(8, 'Manikganj', 'মানিকগঞ্জ', 0, 0, 'www.manikganj.gov.bd'),
(9, 'Munshiganj', 'মুন্সিগঞ্জ', 0, 0, 'www.munshiganj.gov.bd'),
(10, 'Mymensingh', 'ময়মনসিং', 0, 0, 'www.mymensingh.gov.bd'),
(11, 'Narayanganj', 'নারায়াণগঞ্জ', 23.63366, 90.496482, 'www.narayanganj.gov.bd'),
(12, 'Narsingdi', 'নরসিংদী', 23.932233, 90.71541, 'www.narsingdi.gov.bd'),
(13, 'Netrokona', 'নেত্রকোনা', 24.870955, 90.727887, 'www.netrokona.gov.bd'),
(14, 'Rajbari', 'রাজবাড়ি', 23.7574305, 89.6444665, 'www.rajbari.gov.bd'),
(15, 'Shariatpur', 'শরীয়তপুর', 0, 0, 'www.shariatpur.gov.bd'),
(16, 'Sherpur', 'শেরপুর', 25.0204933, 90.0152966, 'www.sherpur.gov.bd'),
(17, 'Tangail', 'টাঙ্গাইল', 0, 0, 'www.tangail.gov.bd'),
(18, 'Bogra', 'বগুড়া', 24.8465228, 89.377755, 'www.bogra.gov.bd'),
(19, 'Joypurhat', 'জয়পুরহাট', 0, 0, 'www.joypurhat.gov.bd'),
(20, 'Naogaon', 'নওগাঁ', 0, 0, 'www.naogaon.gov.bd'),
(21, 'Natore', 'নাটোর', 24.420556, 89.000282, 'www.natore.gov.bd'),
(22, 'Nawabganj', 'নবাবগঞ্জ', 24.5965034, 88.2775122, 'www.chapainawabganj.gov.bd'),
(23, 'Pabna', 'পাবনা', 23.998524, 89.233645, 'www.pabna.gov.bd'),
(24, 'Rajshahi', 'রাজশাহী', 0, 0, 'www.rajshahi.gov.bd'),
(25, 'Sirajgonj', 'সিরাজগঞ্জ', 24.4533978, 89.7006815, 'www.sirajganj.gov.bd'),
(26, 'Dinajpur', 'দিনাজপুর', 25.6217061, 88.6354504, 'www.dinajpur.gov.bd'),
(27, 'Gaibandha', 'গাইবান্ধা', 25.328751, 89.528088, 'www.gaibandha.gov.bd'),
(28, 'Kurigram', 'কুড়িগ্রাম', 25.805445, 89.636174, 'www.kurigram.gov.bd'),
(29, 'Lalmonirhat', 'লালমনিরহাট', 0, 0, 'www.lalmonirhat.gov.bd'),
(30, 'Nilphamari', 'নীলফামারী', 25.931794, 88.856006, 'www.nilphamari.gov.bd'),
(31, 'Panchagarh', 'পঞ্চগড়', 26.3411, 88.5541606, 'www.panchagarh.gov.bd'),
(32, 'Rangpur', 'রংপুর', 25.7558096, 89.244462, 'www.rangpur.gov.bd'),
(33, 'Thakurgaon', 'ঠাকুরগাঁও', 26.0336945, 88.4616834, 'www.thakurgaon.gov.bd'),
(34, 'Barguna', 'বরগুনা', 0, 0, 'www.barguna.gov.bd'),
(35, 'Barisal', 'বরিশাল', 0, 0, 'www.barisal.gov.bd'),
(36, 'Bhola', 'ভোলা', 22.685923, 90.648179, 'www.bhola.gov.bd'),
(37, 'Jhalokati', 'ঝালকাঠি', 0, 0, 'www.jhalakathi.gov.bd'),
(38, 'Patuakhali', 'পটুয়াখালী', 22.3596316, 90.3298712, 'www.patuakhali.gov.bd'),
(39, 'Pirojpur', 'পিরোজপুর', 0, 0, 'www.pirojpur.gov.bd'),
(40, 'Bandarban', 'বান্দরবান', 22.1953275, 92.2183773, 'www.bandarban.gov.bd'),
(41, 'Brahmanbaria', 'ব্রাহ্মণবাড়িয়া', 23.9570904, 91.1119286, 'www.brahmanbaria.gov.bd'),
(42, 'Chandpur', 'চাঁদপুর', 23.2332585, 90.6712912, 'www.chandpur.gov.bd'),
(43, 'Chittagong', 'চট্টগ্রাম', 22.335109, 91.834073, 'www.chittagong.gov.bd'),
(44, 'Comilla', 'কুমিল্লা', 23.4682747, 91.1788135, 'www.comilla.gov.bd'),
(45, 'Cox''s Bazar', 'কক্স বাজার', 0, 0, 'www.coxsbazar.gov.bd'),
(46, 'Feni', 'ফেনী', 23.023231, 91.3840844, 'www.feni.gov.bd'),
(47, 'Khagrachari', 'খাগড়াছড়ি', 23.119285, 91.984663, 'www.khagrachhari.gov.bd'),
(48, 'Lakshmipur', 'লক্ষ্মীপুর', 22.942477, 90.841184, 'www.lakshmipur.gov.bd'),
(49, 'Noakhali', 'নোয়াখালী', 22.869563, 91.099398, 'www.noakhali.gov.bd'),
(50, 'Rangamati', 'রাঙ্গামাটি', 0, 0, 'www.rangamati.gov.bd'),
(51, 'Habiganj', 'হবিগঞ্জ', 24.374945, 91.41553, 'www.habiganj.gov.bd'),
(52, 'Maulvibazar', 'মৌলভীবাজার', 24.482934, 91.777417, 'www.moulvibazar.gov.bd'),
(53, 'Sunamganj', 'সুনামগঞ্জ', 25.0658042, 91.3950115, 'www.sunamganj.gov.bd'),
(54, 'Sylhet', 'সিলেট', 24.8897956, 91.8697894, 'www.sylhet.gov.bd'),
(55, 'Bagerhat', 'বাগেরহাট', 22.651568, 89.785938, 'www.bagerhat.gov.bd'),
(56, 'Chuadanga', 'চুয়াডাঙ্গা', 23.6401961, 88.841841, 'www.chuadanga.gov.bd'),
(57, 'Jessore', 'যশোর', 23.16643, 89.2081126, 'www.jessore.gov.bd'),
(58, 'Jhenaidah', 'ঝিনাইদহ', 23.5448176, 89.1539213, 'www.jhenaidah.gov.bd'),
(59, 'Khulna', 'খুলনা', 22.815774, 89.568679, 'www.khulna.gov.bd'),
(60, 'Kushtia', 'কুষ্টিয়া', 23.901258, 89.120482, 'www.kushtia.gov.bd'),
(61, 'Magura', 'মাগুরা', 23.487337, 89.419956, 'www.magura.gov.bd'),
(62, 'Meherpur', 'মেহেরপুর', 23.762213, 88.631821, 'www.meherpur.gov.bd'),
(63, 'Narail', 'নড়াইল', 23.172534, 89.512672, 'www.narail.gov.bd'),
(64, 'Satkhira', 'সাতক্ষীরা', 0, 0, 'www.satkhira.gov.bd');

-- --------------------------------------------------------

--
-- Table structure for table `drivers`
--

CREATE TABLE `drivers` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(250) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `edited_routes`
--

CREATE TABLE `edited_routes` (
  `id` int(10) UNSIGNED NOT NULL,
  `from_district` int(10) UNSIGNED NOT NULL,
  `from_thana` int(10) UNSIGNED NOT NULL,
  `from_place` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `to_district` int(10) UNSIGNED NOT NULL,
  `to_thana` int(10) UNSIGNED NOT NULL,
  `to_place` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `transport_type` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `departure_time` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `route_id` bigint(20) UNSIGNED NOT NULL,
  `poribohon_id` int(11) UNSIGNED NOT NULL,
  `rent` int(11) NOT NULL,
  `evidence` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `evidence2` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `added_by` bigint(20) UNSIGNED NOT NULL,
  `added` datetime NOT NULL,
  `lang_code` enum('bn','en') COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `edited_stoppages`
--

CREATE TABLE `edited_stoppages` (
  `id` int(10) UNSIGNED NOT NULL,
  `place_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `comments` text COLLATE utf8_unicode_ci NOT NULL,
  `rent` int(11) NOT NULL,
  `route_id` int(10) UNSIGNED NOT NULL,
  `position` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` int(11) UNSIGNED NOT NULL,
  `lang_code` varchar(2) NOT NULL,
  `lang_name` varchar(30) NOT NULL,
  `lang_flag` varchar(60) NOT NULL,
  `lang_order` int(11) NOT NULL,
  `lang_status` tinyint(4) NOT NULL DEFAULT '1',
  `lang_createDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `lang_code`, `lang_name`, `lang_flag`, `lang_order`, `lang_status`, `lang_createDate`) VALUES
(1, 'bn', 'bengali', 'Bangladesh', 0, 1, '0000-00-00 00:00:00'),
(2, 'en', 'english', 'England', 0, 1, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `poribohons`
--

CREATE TABLE `poribohons` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `bn_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `owner` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `total_vehicles` int(11) NOT NULL,
  `picture` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `added_by` bigint(20) UNSIGNED NOT NULL,
  `added` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `poribohons`
--

INSERT INTO `poribohons` (`id`, `name`, `bn_name`, `owner`, `total_vehicles`, `picture`, `added_by`, `added`) VALUES
(1, 'Tetulia Poribohon', 'তেতুলিয়া পরিবহন', '', 40, '', 4, '0000-00-00 00:00:00'),
(2, 'TR Poribohon', 'টিআর পরিবহন', '', 0, '', 4, '2016-11-30 11:25:31'),
(3, 'Dipon CNG', 'দীপন সিএনজি', '', 0, '', 4, '2016-11-30 11:25:17'),
(4, 'Haque Special', 'হক স্পেশাল', 'পনির মিয়া', 15, '', 4, '2016-11-11 10:35:59'),
(6, 'bikash poribohon', 'বিকাশ পরিবহন', '', 20, '828947-1_ll1.jpg', 4, '2016-11-30 11:25:40'),
(7, 'Projapoti Poribohon', 'প্রজাপতি পরিবহন', '', 0, '', 4, '2016-11-30 11:20:29'),
(8, 'Bhuyian Poribohon', 'ভূইয়া পরিবহন', '', 0, '', 4, '2017-01-02 17:10:12'),
(9, 'Bengal Motors', 'বেঙ্গল মটরস', '', 0, '', 4, '2017-01-03 01:19:49'),
(12, 'Sadhin Bangla', 'স্বাধীন বাংলা', '', 0, '', 4, '2017-01-03 14:41:11'),
(14, 'RangDhanu Poribohon', 'রংধনু পরিবহন', '', 0, '', 2, '2017-01-11 21:47:19'),
(15, 'Shohagh Poribohon', 'সোহাগ পরিবহন', '', 0, '', 4, '2017-01-12 17:25:54');

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `id` bigint(20) NOT NULL,
  `first_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `occupation` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `sex` enum('Male','Female','Other') COLLATE utf8_unicode_ci NOT NULL,
  `birth_date` datetime NOT NULL,
  `about` text COLLATE utf8_unicode_ci NOT NULL,
  `thana` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `district` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `routes`
--

CREATE TABLE `routes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `from_district` int(11) UNSIGNED NOT NULL,
  `from_thana` int(11) UNSIGNED NOT NULL,
  `from_place` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `from_latlong` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `to_district` int(11) UNSIGNED NOT NULL,
  `to_thana` int(11) UNSIGNED NOT NULL,
  `to_place` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `to_latlong` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `transport_type` enum('bus','train','leguna','biman','others') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'bus',
  `poribohon_id` int(11) UNSIGNED NOT NULL,
  `departure_time` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `rent` int(11) NOT NULL,
  `evidence` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `evidence2` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `added` datetime NOT NULL,
  `added_by` bigint(20) UNSIGNED NOT NULL,
  `is_publish` int(11) NOT NULL DEFAULT '0' COMMENT '0=not published,1=published',
  `distance` int(11) NOT NULL,
  `duration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `routes`
--

INSERT INTO `routes` (`id`, `from_district`, `from_thana`, `from_place`, `from_latlong`, `to_district`, `to_thana`, `to_place`, `to_latlong`, `transport_type`, `poribohon_id`, `departure_time`, `rent`, `evidence`, `evidence2`, `added`, `added_by`, `is_publish`, `distance`, `duration`) VALUES
(1, 1, 510, 'mirpur-1', '23.7956037,90.3536548', 1, 510, 'Jhigatola', '23.7414675,90.3702192', 'bus', 12, '1', 23, '1484199906test.jpg', '1484199906test.jpg', '2017-01-12 11:54:09', 2, 0, 8084, 1831),
(2, 1, 493, 'Japan Garden City', '23.7653461,90.3571495', 1, 537, 'AbdullahPur', '23.8932542,90.387477', 'bus', 8, '1', 40, '', '', '2017-01-11 17:10:26', 2, 0, 20439, 3149),
(3, 1, 520, 'Mirpur-1', '23.7956037,90.3536548', 1, 537, 'AbdullahPur', '23.8932542,90.387477', 'bus', 9, '1', 40, '', '', '2017-01-11 17:03:45', 2, 0, 15986, 2291),
(4, 28, 415, 'Ghosh Para', '25.7970092,89.6381096', 1, 493, 'asad gate', '23.7601309,90.3727895', 'bus', 4, 'Daily moring and night', 550, '', '', '2017-01-10 12:33:34', 2, 0, 343519, 27628),
(5, 1, 493, 'Japan Garden City', '23.7653461,90.3571495', 1, 509, 'AbdullahPur', '23.8932542,90.387477', 'bus', 1, '1', 40, '', '', '2017-01-11 21:36:11', 2, 0, 20439, 3149),
(6, 1, 493, 'Japan Garden City', '23.7653461,90.3571495', 1, 509, 'Motijheel', '23.7329724,90.417231', 'bus', 14, '1', 50, '', '', '2017-01-11 21:47:22', 2, 0, 9666, 1934),
(8, 1, 520, 'kallyanpur', '23.7822036,90.3595372', 57, 286, 'jessore', '23.3560954,89.3469894', 'bus', 15, '1', 550, '', '', '2017-01-17 14:51:10', 2, 0, 169492, 18449),
(9, 1, 493, 'Bossila', '23.754687,90.3589489', 1, 537, 'AbdullahPur', '23.8932542,90.387477', 'bus', 7, '1', 40, '', '', '2017-01-17 14:56:30', 2, 0, 21133, 3322);

-- --------------------------------------------------------

--
-- Table structure for table `route_bn`
--

CREATE TABLE `route_bn` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `route_id` bigint(20) UNSIGNED NOT NULL,
  `from_place` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `to_place` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `departure_time` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `translation_status` enum('1','2','3') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1' COMMENT '1=incomplete,2=partial,3=complete'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `route_bn`
--

INSERT INTO `route_bn` (`id`, `route_id`, `from_place`, `to_place`, `departure_time`, `translation_status`) VALUES
(1, 1, 'মিরপুর-১', 'ঝিগাতলা', '1', '1'),
(2, 2, 'জাপান গার্ডেন সিটি', 'আব্দুল্লাহপুর', '1', '1'),
(3, 3, 'মিরপুর-১', 'আব্দুল্লাহপুর', '1', '1'),
(4, 4, 'ঘোষপাড়া', 'আসাদ গেট', 'Daily moring and night', '1'),
(5, 5, 'জাপান গার্ডেন সিটি', 'আব্দুল্লাহপুর', '1', '1'),
(6, 6, 'জাপান গার্ডেন সিটি', 'মতিঝিল', '1', '1'),
(8, 8, 'কল্যানপুর', 'যশোর', '1', '1'),
(9, 9, 'বসিলা', 'আব্দুল্লাহপুর', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `stoppages`
--

CREATE TABLE `stoppages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `place_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `comments` text COLLATE utf8_unicode_ci NOT NULL,
  `rent` int(11) NOT NULL,
  `route_id` bigint(20) UNSIGNED NOT NULL,
  `position` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `stoppages`
--

INSERT INTO `stoppages` (`id`, `place_name`, `comments`, `rent`, `route_id`, `position`) VALUES
(58, 'Asulia', 'same rent', 500, 4, 1),
(59, 'Savar', '', 500, 4, 2),
(60, 'Technical', '', 500, 4, 3),
(76, 'Mohakhali', '', 20, 3, 1),
(77, 'Chairmenbari', '', 20, 3, 2),
(78, 'Sainik Club', '', 25, 3, 3),
(79, 'Kakoli', '', 25, 3, 4),
(80, 'Mohakhali', '', 20, 2, 1),
(81, 'Chairmenbari', '', 25, 2, 2),
(92, 'Mirpur  10', '', 10, 5, 1),
(93, 'Kalshi', '', 10, 5, 2),
(94, 'Matikata', '', 15, 5, 3),
(95, 'Rajlokhkhi', '', 20, 5, 4),
(96, 'HouseBuilding', '', 25, 5, 5),
(97, 'JashimUdiin mor', '', 25, 5, 6),
(102, 'Farmgate', '', 10, 6, 1),
(103, 'BanglaMotor', '', 10, 6, 2),
(104, 'ShahBag', '', 15, 6, 3),
(105, 'Motsha Vobon', '', 20, 6, 4),
(175, 'Technical', '', 5, 1, 1),
(176, 'darus salam', '', 5, 1, 2),
(177, 'Kallyanpur', '', 7, 1, 3),
(178, 'Shamoly', '', 8, 1, 4),
(179, 'Adabor', '', 10, 1, 5),
(186, 'New market bus stand', '', 550, 8, 1),
(197, 'Mohammadpur Tin rastar mor', '', 10, 9, 1),
(198, 'Mohammadpur Bus Stand', '', 15, 9, 2),
(199, 'Asad Gate', '', 15, 9, 3),
(200, 'Shamoly', '', 15, 9, 4),
(201, 'Darus Salam', '', 15, 9, 5),
(202, 'Mirpur - 1', '', 15, 9, 6),
(203, 'Mirpur - 10', '', 15, 9, 7),
(204, 'Kalshi', '', 20, 9, 8),
(205, 'Jashimuddin', '', 30, 9, 9),
(206, 'Rajlokhkhi', '', 35, 9, 10);

-- --------------------------------------------------------

--
-- Table structure for table `stoppage_bn`
--

CREATE TABLE `stoppage_bn` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `route_id` bigint(20) UNSIGNED NOT NULL,
  `place_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `comments` text COLLATE utf8_unicode_ci NOT NULL,
  `rent` int(11) NOT NULL,
  `position` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `stoppage_bn`
--

INSERT INTO `stoppage_bn` (`id`, `route_id`, `place_name`, `comments`, `rent`, `position`) VALUES
(4, 2, 'মহাখালী', '', 20, 1),
(5, 2, 'চেয়ারমেনবাড়ি', '', 25, 2),
(12, 3, 'মহাখালী', '', 20, 1),
(13, 3, 'চেয়ারম্যান বাড়ী', '', 20, 2),
(14, 3, 'সৈনিক ক্লাব', '', 25, 3),
(15, 3, 'কাকলী', '', 25, 4),
(27, 4, 'আশুলিয়া', 'same rent', 500, 1),
(28, 4, 'সাভার', '', 500, 2),
(29, 4, 'টেকনিকাল', '', 500, 3),
(30, 1, 'টেকনিকাল', '', 5, 1),
(31, 1, 'দারুসসালাম', '', 5, 2),
(32, 1, 'কল্যানপুর', '', 7, 3),
(33, 1, 'শ্যামলী', '', 8, 4),
(40, 5, 'মিরপুর ১০', '', 10, 1),
(41, 5, 'কালশী', '', 10, 2),
(42, 5, 'মাটিকাটা', '', 15, 3),
(43, 5, 'রাজলক্ষী', '', 20, 4),
(44, 5, 'হাউজবিল্ডিং', '', 25, 5),
(45, 5, 'জসিমউদ্দিন মোড়', '', 25, 6),
(46, 6, 'ফার্মগেইট', '', 10, 1),
(47, 6, 'বাংলামোটর', '', 10, 2),
(48, 6, 'শাহবাগ', '', 15, 3),
(49, 6, 'মৎস ভবন', '', 20, 4),
(56, 8, 'নিউ মার্কেট বাসস্টান্ড', '', 550, 1),
(67, 9, 'মোহাম্মদপুর তিন রাস্তার মোড়', '', 10, 1),
(68, 9, 'মোহাম্মদপুর বাস স্ট্রান্ড', '', 15, 2),
(69, 9, 'আসাদ গেট', '', 15, 3),
(70, 9, 'শ্যামলি', '', 15, 4),
(71, 9, 'দারুস সালাম', '', 15, 5),
(72, 9, 'মিরপুর - ১', '', 15, 6),
(73, 9, 'মিরপুর - ১০', '', 15, 7),
(74, 9, 'কালশী', '', 20, 8),
(75, 9, 'জসীমউদ্দিন', '', 30, 9),
(76, 9, 'রাজলক্ষী', '', 35, 10);

-- --------------------------------------------------------

--
-- Table structure for table `thanas`
--

CREATE TABLE `thanas` (
  `id` int(2) UNSIGNED NOT NULL,
  `district_id` int(2) UNSIGNED NOT NULL,
  `name` varchar(30) NOT NULL,
  `bn_name` varchar(50) NOT NULL,
  `guesture` varchar(250) NOT NULL,
  `bn_guesture` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `thanas`
--

INSERT INTO `thanas` (`id`, `district_id`, `name`, `bn_name`, `guesture`, `bn_guesture`) VALUES
(1, 34, 'Amtali', 'আমতলী', '', ''),
(2, 34, 'Bamna', 'বামনা', '', ''),
(3, 34, 'Barguna Sadar', 'বরগুনা সদর', '', ''),
(4, 34, 'Betagi', 'বেতাগি', '', ''),
(5, 34, 'Patharghata', 'পাথরঘাটা', '', ''),
(6, 34, 'Taltali', 'তালতলী', '', ''),
(7, 35, 'Muladi', 'মুলাদি', '', ''),
(8, 35, 'Babuganj', 'বাবুগঞ্জ', '', ''),
(9, 35, 'Agailjhara', 'আগাইলঝরা', '', ''),
(10, 35, 'Barisal Sadar', 'বরিশাল সদর', '', ''),
(11, 35, 'Bakerganj', 'বাকেরগঞ্জ', '', ''),
(12, 35, 'Banaripara', 'বানাড়িপারা', '', ''),
(13, 35, 'Gaurnadi', 'গৌরনদী', '', ''),
(14, 35, 'Hizla', 'হিজলা', '', ''),
(15, 35, 'Mehendiganj', 'মেহেদিগঞ্জ ', '', ''),
(16, 35, 'Wazirpur', 'ওয়াজিরপুর', '', ''),
(17, 36, 'Bhola Sadar', 'ভোলা সদর', '', ''),
(18, 36, 'Burhanuddin', 'বুরহানউদ্দিন', '', ''),
(19, 36, 'Char Fasson', 'চর ফ্যাশন', '', ''),
(20, 36, 'Daulatkhan', 'দৌলতখান', '', ''),
(21, 36, 'Lalmohan', 'লালমোহন', '', ''),
(22, 36, 'Manpura', 'মনপুরা', '', ''),
(23, 36, 'Tazumuddin', 'তাজুমুদ্দিন', '', ''),
(24, 37, 'Jhalokati Sadar', 'ঝালকাঠি সদর', '', ''),
(25, 37, 'Kathalia', 'কাঁঠালিয়া', '', ''),
(26, 37, 'Nalchity', 'নালচিতি', '', ''),
(27, 37, 'Rajapur', 'রাজাপুর', '', ''),
(28, 38, 'Bauphal', 'বাউফল', '', ''),
(29, 38, 'Dashmina', 'দশমিনা', '', ''),
(30, 38, 'Galachipa', 'গলাচিপা', '', ''),
(31, 38, 'Kalapara', 'কালাপারা', '', ''),
(32, 38, 'Mirzaganj', 'মির্জাগঞ্জ ', '', ''),
(33, 38, 'Patuakhali Sadar', 'পটুয়াখালী সদর', '', ''),
(34, 38, 'Dumki', 'ডুমকি', '', ''),
(35, 38, 'Rangabali', 'রাঙ্গাবালি', '', ''),
(36, 39, 'Bhandaria', 'ভ্যান্ডারিয়া', '', ''),
(37, 39, 'Kaukhali', 'কাউখালি', '', ''),
(38, 39, 'Mathbaria', 'মাঠবাড়িয়া', '', ''),
(39, 39, 'Nazirpur', 'নাজিরপুর', '', ''),
(40, 39, 'Nesarabad', 'নেসারাবাদ', '', ''),
(41, 39, 'Pirojpur Sadar', 'পিরোজপুর সদর', '', ''),
(42, 39, 'Zianagar', 'জিয়ানগর', '', ''),
(43, 40, 'Bandarban Sadar', 'বান্দরবন সদর', '', ''),
(44, 40, 'Thanchi', 'থানচি', '', ''),
(45, 40, 'Lama', 'লামা', '', ''),
(46, 40, 'Naikhongchhari', 'নাইখংছড়ি ', '', ''),
(47, 40, 'Ali kadam', 'আলী কদম', '', ''),
(48, 40, 'Rowangchhari', 'রউয়াংছড়ি ', '', ''),
(49, 40, 'Ruma', 'রুমা', '', ''),
(50, 41, 'Brahmanbaria Sadar', 'ব্রাহ্মণবাড়িয়া সদর', '', ''),
(51, 41, 'Ashuganj', 'আশুগঞ্জ', '', ''),
(52, 41, 'Nasirnagar', 'নাসির নগর', '', ''),
(53, 41, 'Nabinagar', 'নবীনগর', '', ''),
(54, 41, 'Sarail', 'সরাইল', '', ''),
(55, 41, 'Shahbazpur Town', 'শাহবাজপুর টাউন', '', ''),
(56, 41, 'Kasba', 'কসবা', '', ''),
(57, 41, 'Akhaura', 'আখাউরা', '', ''),
(58, 41, 'Bancharampur', 'বাঞ্ছারামপুর', '', ''),
(59, 41, 'Bijoynagar', 'বিজয় নগর', '', ''),
(60, 42, 'Chandpur Sadar', 'চাঁদপুর সদর', '', ''),
(61, 42, 'Faridganj', 'ফরিদগঞ্জ', '', ''),
(62, 42, 'Haimchar', 'হাইমচর', '', ''),
(63, 42, 'Haziganj', 'হাজীগঞ্জ', '', ''),
(64, 42, 'Kachua', 'কচুয়া', '', ''),
(65, 42, 'Matlab Uttar', 'মতলব উত্তর', '', ''),
(66, 42, 'Matlab Dakkhin', 'মতলব দক্ষিণ', '', ''),
(67, 42, 'Shahrasti', 'শাহরাস্তি', '', ''),
(68, 43, 'Anwara', 'আনোয়ারা', '', ''),
(69, 43, 'Banshkhali', 'বাশখালি', '', ''),
(70, 43, 'Boalkhali', 'বোয়ালখালি', '', ''),
(71, 43, 'Chandanaish', 'চন্দনাইশ', '', ''),
(72, 43, 'Fatikchhari', 'ফটিকছড়ি', '', ''),
(73, 43, 'Hathazari', 'হাঠহাজারী', '', ''),
(74, 43, 'Lohagara', 'লোহাগারা', '', ''),
(75, 43, 'Mirsharai', 'মিরসরাই', '', ''),
(76, 43, 'Patiya', 'পটিয়া', '', ''),
(77, 43, 'Rangunia', 'রাঙ্গুনিয়া', '', ''),
(78, 43, 'Raozan', 'রাউজান', '', ''),
(79, 43, 'Sandwip', 'সন্দ্বীপ', '', ''),
(80, 43, 'Satkania', 'সাতকানিয়া', '', ''),
(81, 43, 'Sitakunda', 'সীতাকুণ্ড', '', ''),
(82, 44, 'Barura', 'বড়ুরা', '', ''),
(83, 44, 'Brahmanpara', 'ব্রাহ্মণপাড়া', '', ''),
(84, 44, 'Burichong', 'বুড়িচং', '', ''),
(85, 44, 'Chandina', 'চান্দিনা', '', ''),
(86, 44, 'Chauddagram', 'চৌদ্দগ্রাম', '', ''),
(87, 44, 'Daudkandi', 'দাউদকান্দি', '', ''),
(88, 44, 'Debidwar', 'দেবীদ্বার', '', ''),
(89, 44, 'Homna', 'হোমনা', '', ''),
(90, 44, 'Comilla Sadar', 'কুমিল্লা সদর', '', ''),
(91, 44, 'Laksam', 'লাকসাম', '', ''),
(92, 44, 'Monohorgonj', 'মনোহরগঞ্জ', '', ''),
(93, 44, 'Meghna', 'মেঘনা', '', ''),
(94, 44, 'Muradnagar', 'মুরাদনগর', '', ''),
(95, 44, 'Nangalkot', 'নাঙ্গালকোট', '', ''),
(96, 44, 'Comilla Sadar South', 'কুমিল্লা সদর দক্ষিণ', '', ''),
(97, 44, 'Titas', 'তিতাস', '', ''),
(98, 45, 'Chakaria', 'চকরিয়া', '', ''),
(99, 45, 'Chakaria', 'চকরিয়া', '', ''),
(100, 45, 'Cox''s Bazar Sadar', 'কক্স বাজার সদর', '', ''),
(101, 45, 'Kutubdia', 'কুতুবদিয়া', '', ''),
(102, 45, 'Maheshkhali', 'মহেশখালী', '', ''),
(103, 45, 'Ramu', 'রামু', '', ''),
(104, 45, 'Teknaf', 'টেকনাফ', '', ''),
(105, 45, 'Ukhia', 'উখিয়া', '', ''),
(106, 45, 'Pekua', 'পেকুয়া', '', ''),
(107, 46, 'Feni Sadar', 'ফেনী সদর', '', ''),
(108, 46, 'Chagalnaiya', 'ছাগল নাইয়া', '', ''),
(109, 46, 'Daganbhyan', 'দাগানভিয়া', '', ''),
(110, 46, 'Parshuram', 'পরশুরাম', '', ''),
(111, 46, 'Fhulgazi', 'ফুলগাজি', '', ''),
(112, 46, 'Sonagazi', 'সোনাগাজি', '', ''),
(113, 47, 'Dighinala', 'দিঘিনালা ', '', ''),
(114, 47, 'Khagrachhari', 'খাগড়াছড়ি', '', ''),
(115, 47, 'Lakshmichhari', 'লক্ষ্মীছড়ি', '', ''),
(116, 47, 'Mahalchhari', 'মহলছড়ি', '', ''),
(117, 47, 'Manikchhari', 'মানিকছড়ি', '', ''),
(118, 47, 'Matiranga', 'মাটিরাঙ্গা', '', ''),
(119, 47, 'Panchhari', 'পানছড়ি', '', ''),
(120, 47, 'Ramgarh', 'রামগড়', '', ''),
(121, 48, 'Lakshmipur Sadar', 'লক্ষ্মীপুর সদর', '', ''),
(122, 48, 'Raipur', 'রায়পুর', '', ''),
(123, 48, 'Ramganj', 'রামগঞ্জ', '', ''),
(124, 48, 'Ramgati', 'রামগতি', '', ''),
(125, 48, 'Komol Nagar', 'কমল নগর', '', ''),
(126, 49, 'Noakhali Sadar', 'নোয়াখালী সদর', '', ''),
(127, 49, 'Begumganj', 'বেগমগঞ্জ', '', ''),
(128, 49, 'Chatkhil', 'চাটখিল', '', ''),
(129, 49, 'Companyganj', 'কোম্পানীগঞ্জ', '', ''),
(130, 49, 'Shenbag', 'শেনবাগ', '', ''),
(131, 49, 'Hatia', 'হাতিয়া', '', ''),
(132, 49, 'Kobirhat', 'কবিরহাট ', '', ''),
(133, 49, 'Sonaimuri', 'সোনাইমুরি', '', ''),
(134, 49, 'Suborno Char', 'সুবর্ণ চর ', '', ''),
(135, 50, 'Rangamati Sadar', 'রাঙ্গামাটি সদর', '', ''),
(136, 50, 'Belaichhari', 'বেলাইছড়ি', '', ''),
(137, 50, 'Bagaichhari', 'বাঘাইছড়ি', '', ''),
(138, 50, 'Barkal', 'বরকল', '', ''),
(139, 50, 'Juraichhari', 'জুরাইছড়ি', '', ''),
(140, 50, 'Rajasthali', 'রাজাস্থলি', '', ''),
(141, 50, 'Kaptai', 'কাপ্তাই', '', ''),
(142, 50, 'Langadu', 'লাঙ্গাডু', '', ''),
(143, 50, 'Nannerchar', 'নান্নেরচর ', '', ''),
(144, 50, 'Kaukhali', 'কাউখালি', '', ''),
(145, 1, 'Dhamrai', 'ধামরাই', '', ''),
(146, 1, 'Dohar', 'দোহার', '', ''),
(147, 1, 'Keraniganj', 'কেরানীগঞ্জ', '', ''),
(148, 1, 'Nawabganj', 'নবাবগঞ্জ', '', ''),
(149, 1, 'Savar', 'সাভার', '', ''),
(150, 2, 'Faridpur Sadar', 'ফরিদপুর সদর', '', ''),
(151, 2, 'Boalmari', 'বোয়ালমারী', '', ''),
(152, 2, 'Alfadanga', 'আলফাডাঙ্গা', '', ''),
(153, 2, 'Madhukhali', 'মধুখালি', '', ''),
(154, 2, 'Bhanga', 'ভাঙ্গা', '', ''),
(155, 2, 'Nagarkanda', 'নগরকান্ড', '', ''),
(156, 2, 'Charbhadrasan', 'চরভদ্রাসন ', '', ''),
(157, 2, 'Sadarpur', 'সদরপুর', '', ''),
(158, 2, 'Shaltha', 'শালথা', '', ''),
(159, 3, 'Gazipur Sadar-Joydebpur', 'গাজীপুর সদর', '', ''),
(160, 3, 'Kaliakior', 'কালিয়াকৈর', '', ''),
(161, 3, 'Kapasia', 'কাপাসিয়া', '', ''),
(162, 3, 'Sripur', 'শ্রীপুর', '', ''),
(163, 3, 'Kaliganj', 'কালীগঞ্জ', '', ''),
(164, 3, 'Tongi', 'টঙ্গি', '', ''),
(165, 4, 'Gopalganj Sadar', 'গোপালগঞ্জ সদর', '', ''),
(166, 4, 'Kashiani', 'কাশিয়ানি', '', ''),
(167, 4, 'Kotalipara', 'কোটালিপাড়া', '', ''),
(168, 4, 'Muksudpur', 'মুকসুদপুর', '', ''),
(169, 4, 'Tungipara', 'টুঙ্গিপাড়া', '', ''),
(170, 5, 'Dewanganj', 'দেওয়ানগঞ্জ', '', ''),
(171, 5, 'Baksiganj', 'বকসিগঞ্জ', '', ''),
(172, 5, 'Islampur', 'ইসলামপুর', '', ''),
(173, 5, 'Jamalpur Sadar', 'জামালপুর সদর', '', ''),
(174, 5, 'Madarganj', 'মাদারগঞ্জ', '', ''),
(175, 5, 'Melandaha', 'মেলানদাহা', '', ''),
(176, 5, 'Sarishabari', 'সরিষাবাড়ি ', '', ''),
(177, 5, 'Narundi Police I.C', 'নারুন্দি', '', ''),
(178, 6, 'Astagram', 'অষ্টগ্রাম', '', ''),
(179, 6, 'Bajitpur', 'বাজিতপুর', '', ''),
(180, 6, 'Bhairab', 'ভৈরব', '', ''),
(181, 6, 'Hossainpur', 'হোসেনপুর ', '', ''),
(182, 6, 'Itna', 'ইটনা', '', ''),
(183, 6, 'Karimganj', 'করিমগঞ্জ', '', ''),
(184, 6, 'Katiadi', 'কতিয়াদি', '', ''),
(185, 6, 'Kishoreganj Sadar', 'কিশোরগঞ্জ সদর', '', ''),
(186, 6, 'Kuliarchar', 'কুলিয়ারচর', '', ''),
(187, 6, 'Mithamain', 'মিঠামাইন', '', ''),
(188, 6, 'Nikli', 'নিকলি', '', ''),
(189, 6, 'Pakundia', 'পাকুন্ডা', '', ''),
(190, 6, 'Tarail', 'তাড়াইল', '', ''),
(191, 7, 'Madaripur Sadar', 'মাদারীপুর সদর', '', ''),
(192, 7, 'Kalkini', 'কালকিনি', '', ''),
(193, 7, 'Rajoir', 'রাজইর', '', ''),
(194, 7, 'Shibchar', 'শিবচর', '', ''),
(195, 8, 'Manikganj Sadar', 'মানিকগঞ্জ সদর', '', ''),
(196, 8, 'Singair', 'সিঙ্গাইর', '', ''),
(197, 8, 'Shibalaya', 'শিবালয়', '', ''),
(198, 8, 'Saturia', 'সাঠুরিয়া', '', ''),
(199, 8, 'Harirampur', 'হরিরামপুর', '', ''),
(200, 8, 'Ghior', 'ঘিওর', '', ''),
(201, 8, 'Daulatpur', 'দৌলতপুর', '', ''),
(202, 9, 'Lohajang', 'লোহাজং', '', ''),
(203, 9, 'Sreenagar', 'শ্রীনগর', '', ''),
(204, 9, 'Munshiganj Sadar', 'মুন্সিগঞ্জ সদর', '', ''),
(205, 9, 'Sirajdikhan', 'সিরাজদিখান', '', ''),
(206, 9, 'Tongibari', 'টঙ্গিবাড়ি', '', ''),
(207, 9, 'Gazaria', 'গজারিয়া', '', ''),
(208, 10, 'Bhaluka', 'ভালুকা', '', ''),
(209, 10, 'Trishal', 'ত্রিশাল', '', ''),
(210, 10, 'Haluaghat', 'হালুয়াঘাট', '', ''),
(211, 10, 'Muktagachha', 'মুক্তাগাছা', '', ''),
(212, 10, 'Dhobaura', 'ধবারুয়া', '', ''),
(213, 10, 'Fulbaria', 'ফুলবাড়িয়া', '', ''),
(214, 10, 'Gaffargaon', 'গফরগাঁও', '', ''),
(215, 10, 'Gauripur', 'গৌরিপুর', '', ''),
(216, 10, 'Ishwarganj', 'ঈশ্বরগঞ্জ', '', ''),
(217, 10, 'Mymensingh Sadar', 'ময়মনসিং সদর', '', ''),
(218, 10, 'Nandail', 'নন্দাইল', '', ''),
(219, 10, 'Phulpur', 'ফুলপুর', '', ''),
(220, 11, 'Araihazar', 'আড়াইহাজার', '', ''),
(221, 11, 'Sonargaon', 'সোনারগাঁও', '', ''),
(222, 11, 'Bandar', 'বান্দার', '', ''),
(223, 11, 'Naryanganj Sadar', 'নারায়ানগঞ্জ সদর', '', ''),
(224, 11, 'Rupganj', 'রূপগঞ্জ', '', ''),
(225, 11, 'Siddirgonj', 'সিদ্ধিরগঞ্জ', '', ''),
(226, 12, 'Belabo', 'বেলাবো', '', ''),
(227, 12, 'Monohardi', 'মনোহরদি', '', ''),
(228, 12, 'Narsingdi Sadar', 'নরসিংদী সদর', '', ''),
(229, 12, 'Palash', 'পলাশ', '', ''),
(230, 12, 'Raipura, Narsingdi', 'রায়পুর', '', ''),
(231, 12, 'Shibpur', 'শিবপুর', '', ''),
(232, 13, 'Kendua Upazilla', 'কেন্দুয়া', '', ''),
(233, 13, 'Atpara Upazilla', 'আটপাড়া', '', ''),
(234, 13, 'Barhatta Upazilla', 'বরহাট্টা', '', ''),
(235, 13, 'Durgapur Upazilla', 'দুর্গাপুর', '', ''),
(236, 13, 'Kalmakanda Upazilla', 'কলমাকান্দা', '', ''),
(237, 13, 'Madan Upazilla', 'মদন', '', ''),
(238, 13, 'Mohanganj Upazilla', 'মোহনগঞ্জ', '', ''),
(239, 13, 'Netrakona-S Upazilla', 'নেত্রকোনা সদর', '', ''),
(240, 13, 'Purbadhala Upazilla', 'পূর্বধলা', '', ''),
(241, 13, 'Khaliajuri Upazilla', 'খালিয়াজুরি', '', ''),
(242, 14, 'Baliakandi', 'বালিয়াকান্দি', '', ''),
(243, 14, 'Goalandaghat', 'গোয়ালন্দ ঘাট', '', ''),
(244, 14, 'Pangsha', 'পাংশা', '', ''),
(245, 14, 'Kalukhali', 'কালুখালি', '', ''),
(246, 14, 'Rajbari Sadar', 'রাজবাড়ি সদর', '', ''),
(247, 15, 'Shariatpur Sadar -Palong', 'শরীয়তপুর সদর ', '', ''),
(248, 15, 'Damudya', 'দামুদিয়া', '', ''),
(249, 15, 'Naria', 'নড়িয়া', '', ''),
(250, 15, 'Jajira', 'জাজিরা', '', ''),
(251, 15, 'Bhedarganj', 'ভেদারগঞ্জ', '', ''),
(252, 15, 'Gosairhat', 'গোসাইর হাট ', '', ''),
(253, 16, 'Jhenaigati', 'ঝিনাইগাতি', '', ''),
(254, 16, 'Nakla', 'নাকলা', '', ''),
(255, 16, 'Nalitabari', 'নালিতাবাড়ি', '', ''),
(256, 16, 'Sherpur Sadar', 'শেরপুর সদর', '', ''),
(257, 16, 'Sreebardi', 'শ্রীবরদি', '', ''),
(258, 17, 'Tangail Sadar', 'টাঙ্গাইল সদর', '', ''),
(259, 17, 'Sakhipur', 'সখিপুর', '', ''),
(260, 17, 'Basail', 'বসাইল', '', ''),
(261, 17, 'Madhupur', 'মধুপুর', '', ''),
(262, 17, 'Ghatail', 'ঘাটাইল', '', ''),
(263, 17, 'Kalihati', 'কালিহাতি', '', ''),
(264, 17, 'Nagarpur', 'নগরপুর', '', ''),
(265, 17, 'Mirzapur', 'মির্জাপুর', '', ''),
(266, 17, 'Gopalpur', 'গোপালপুর', '', ''),
(267, 17, 'Delduar', 'দেলদুয়ার', '', ''),
(268, 17, 'Bhuapur', 'ভুয়াপুর', '', ''),
(269, 17, 'Dhanbari', 'ধানবাড়ি', '', ''),
(270, 55, 'Bagerhat Sadar', 'বাগেরহাট সদর', '', ''),
(271, 55, 'Chitalmari', 'চিতলমাড়ি', '', ''),
(272, 55, 'Fakirhat', 'ফকিরহাট', '', ''),
(273, 55, 'Kachua', 'কচুয়া', '', ''),
(274, 55, 'Mollahat', 'মোল্লাহাট ', '', ''),
(275, 55, 'Mongla', 'মংলা', '', ''),
(276, 55, 'Morrelganj', 'মরেলগঞ্জ', '', ''),
(277, 55, 'Rampal', 'রামপাল', '', ''),
(278, 55, 'Sarankhola', 'স্মরণখোলা', '', ''),
(279, 56, 'Damurhuda', 'দামুরহুদা', '', ''),
(280, 56, 'Chuadanga-S', 'চুয়াডাঙ্গা সদর', '', ''),
(281, 56, 'Jibannagar', 'জীবন নগর ', '', ''),
(282, 56, 'Alamdanga', 'আলমডাঙ্গা', '', ''),
(283, 57, 'Abhaynagar', 'অভয়নগর', '', ''),
(284, 57, 'Keshabpur', 'কেশবপুর', '', ''),
(285, 57, 'Bagherpara', 'বাঘের পাড়া ', '', ''),
(286, 57, 'Jessore Sadar', 'যশোর সদর', '', ''),
(287, 57, 'Chaugachha', 'চৌগাছা', '', ''),
(288, 57, 'Manirampur', 'মনিরামপুর ', '', ''),
(289, 57, 'Jhikargachha', 'ঝিকরগাছা', '', ''),
(290, 57, 'Sharsha', 'সারশা', '', ''),
(291, 58, 'Jhenaidah Sadar', 'ঝিনাইদহ সদর', '', ''),
(292, 58, 'Maheshpur', 'মহেশপুর', '', ''),
(293, 58, 'Kaliganj', 'কালীগঞ্জ', '', ''),
(294, 58, 'Kotchandpur', 'কোট চাঁদপুর ', '', ''),
(295, 58, 'Shailkupa', 'শৈলকুপা', '', ''),
(296, 58, 'Harinakunda', 'হাড়িনাকুন্দা', '', ''),
(297, 59, 'Terokhada', 'তেরোখাদা', '', ''),
(298, 59, 'Batiaghata', 'বাটিয়াঘাটা ', '', ''),
(299, 59, 'Dacope', 'ডাকপে', '', ''),
(300, 59, 'Dumuria', 'ডুমুরিয়া', '', ''),
(301, 59, 'Dighalia', 'দিঘলিয়া', '', ''),
(302, 59, 'Koyra', 'কয়ড়া', '', ''),
(303, 59, 'Paikgachha', 'পাইকগাছা', '', ''),
(304, 59, 'Phultala', 'ফুলতলা', '', ''),
(305, 59, 'Rupsa', 'রূপসা', '', ''),
(306, 60, 'Kushtia Sadar', 'কুষ্টিয়া সদর', '', ''),
(307, 60, 'Kumarkhali', 'কুমারখালি', '', ''),
(308, 60, 'Daulatpur', 'দৌলতপুর', 'Dowlatpur,Doulatpur', ''),
(309, 60, 'Mirpur', 'মিরপুর', '', ''),
(310, 60, 'Bheramara', 'ভেরামারা', 'Veramara', ''),
(311, 60, 'Khoksa', 'খোকসা', '', ''),
(312, 61, 'Magura Sadar', 'মাগুরা সদর', '', ''),
(313, 61, 'Mohammadpur', 'মোহাম্মাদপুর', 'Muhammadpur', ''),
(314, 61, 'Shalikha', 'শালিখা', 'Salikha', ''),
(315, 61, 'Sreepur', 'শ্রীপুর', 'Sripur', ''),
(316, 62, 'angni', 'আংনি', '', ''),
(317, 62, 'Mujib Nagar', 'মুজিব নগর', '', ''),
(318, 62, 'Meherpur-S', 'মেহেরপুর সদর', '', ''),
(319, 63, 'Narail-S Upazilla', 'নড়াইল সদর', 'Norail Sadar', ''),
(320, 63, 'Lohagara Upazilla', 'লোহাগাড়া', '', ''),
(321, 63, 'Kalia Upazilla', 'কালিয়া', '', ''),
(322, 64, 'Satkhira Sadar', 'সাতক্ষীরা সদর', '', ''),
(323, 64, 'Assasuni', 'আসসাশুনি ', '', ''),
(324, 64, 'Debhata', 'দেভাটা', '', ''),
(325, 64, 'Tala', 'তালা', '', ''),
(326, 64, 'Kalaroa', 'কলরোয়া', 'Koloroa', ''),
(327, 64, 'Kaliganj', 'কালীগঞ্জ', '', ''),
(328, 64, 'Shyamnagar', 'শ্যামনগর', 'Shamnogor, Shamnagar,Shamnogar', ''),
(329, 18, 'Adamdighi', 'আদমদিঘী', '', ''),
(330, 18, 'Bogra Sadar', 'বগুড়া সদর', '', ''),
(331, 18, 'Sherpur', 'শেরপুর', '', ''),
(332, 18, 'Dhunat', 'ধুনট', '', ''),
(333, 18, 'Dhupchanchia', 'দুপচাচিয়া', '', ''),
(334, 18, 'Gabtali', 'গাবতলি', '', ''),
(335, 18, 'Kahaloo', 'কাহালু', '', ''),
(336, 18, 'Nandigram', 'নন্দিগ্রাম', '', ''),
(337, 18, 'Sahajanpur', 'শাহজাহানপুর', '', ''),
(338, 18, 'Sariakandi', 'সারিয়াকান্দি', '', ''),
(339, 18, 'Shibganj', 'শিবগঞ্জ', '', ''),
(340, 18, 'Sonatala', 'সোনাতলা', '', ''),
(341, 19, 'Joypurhat S', 'জয়পুরহাট সদর', '', ''),
(342, 19, 'Akkelpur', 'আক্কেলপুর', '', ''),
(343, 19, 'Kalai', 'কালাই', '', ''),
(344, 19, 'Khetlal', 'খেতলাল', '', ''),
(345, 19, 'Panchbibi', 'পাঁচবিবি', '', ''),
(346, 20, 'Naogaon Sadar', 'নওগাঁ সদর', '', ''),
(347, 20, 'Mohadevpur', 'মহাদেবপুর', '', ''),
(348, 20, 'Manda', 'মান্দা', '', ''),
(349, 20, 'Niamatpur', 'নিয়ামতপুর', '', ''),
(350, 20, 'Atrai', 'আত্রাই', '', ''),
(351, 20, 'Raninagar', 'রাণীনগর', '', ''),
(352, 20, 'Patnitala', 'পত্নীতলা', '', ''),
(353, 20, 'Dhamoirhat', 'ধামইরহাট ', '', ''),
(354, 20, 'Sapahar', 'সাপাহার', '', ''),
(355, 20, 'Porsha', 'পোরশা', '', ''),
(356, 20, 'Badalgachhi', 'বদলগাছি', '', ''),
(357, 21, 'Natore Sadar', 'নাটোর সদর', '', ''),
(358, 21, 'Baraigram', 'বড়াইগ্রাম', '', ''),
(359, 21, 'Bagatipara', 'বাগাতিপাড়া', '', ''),
(360, 21, 'Lalpur', 'লালপুর', '', ''),
(361, 21, 'Natore Sadar', 'নাটোর সদর', '', ''),
(362, 21, 'Baraigram', 'বড়াই গ্রাম', '', ''),
(363, 22, 'Bholahat', 'ভোলাহাট', '', ''),
(364, 22, 'Gomastapur', 'গোমস্তাপুর', '', ''),
(365, 22, 'Nachole', 'নাচোল', '', ''),
(366, 22, 'Nawabganj Sadar', 'নবাবগঞ্জ সদর', '', ''),
(367, 22, 'Shibganj', 'শিবগঞ্জ', '', ''),
(368, 23, 'Atgharia', 'আটঘরিয়া', '', ''),
(369, 23, 'Bera', 'বেড়া', '', ''),
(370, 23, 'Bhangura', 'ভাঙ্গুরা', '', ''),
(371, 23, 'Chatmohar', 'চাটমোহর', '', ''),
(372, 23, 'Faridpur', 'ফরিদপুর', '', ''),
(373, 23, 'Ishwardi', 'ঈশ্বরদী', '', ''),
(374, 23, 'Pabna Sadar', 'পাবনা সদর', '', ''),
(375, 23, 'Santhia', 'সাথিয়া', '', ''),
(376, 23, 'Sujanagar', 'সুজানগর', '', ''),
(377, 24, 'Bagha', 'বাঘা', '', ''),
(378, 24, 'Bagmara', 'বাগমারা', '', ''),
(379, 24, 'Charghat', 'চারঘাট', '', ''),
(380, 24, 'Durgapur', 'দুর্গাপুর', '', ''),
(381, 24, 'Godagari', 'গোদাগারি', '', ''),
(382, 24, 'Mohanpur', 'মোহনপুর', '', ''),
(383, 24, 'Paba', 'পবা', '', ''),
(384, 24, 'Puthia', 'পুঠিয়া', '', ''),
(385, 24, 'Tanore', 'তানোর', '', ''),
(386, 25, 'Sirajganj Sadar', 'সিরাজগঞ্জ সদর', '', ''),
(387, 25, 'Belkuchi', 'বেলকুচি', '', ''),
(388, 25, 'Chauhali', 'চৌহালি', '', ''),
(389, 25, 'Kamarkhanda', 'কামারখান্দা', '', ''),
(390, 25, 'Kazipur', 'কাজীপুর', '', ''),
(391, 25, 'Raiganj', 'রায়গঞ্জ', '', ''),
(392, 25, 'Shahjadpur', 'শাহজাদপুর', '', ''),
(393, 25, 'Tarash', 'তারাশ', '', ''),
(394, 25, 'Ullahpara', 'উল্লাপাড়া', '', ''),
(395, 26, 'Birampur', 'বিরামপুর', '', ''),
(396, 26, 'Birganj', 'বীরগঞ্জ', '', ''),
(397, 26, 'Biral', 'বিড়াল', '', ''),
(398, 26, 'Bochaganj', 'বোচাগঞ্জ', '', ''),
(399, 26, 'Chirirbandar', 'চিরিরবন্দর', '', ''),
(400, 26, 'Phulbari', 'ফুলবাড়ি', '', ''),
(401, 26, 'Ghoraghat', 'ঘোড়াঘাট', '', ''),
(402, 26, 'Hakimpur', 'হাকিমপুর', '', ''),
(403, 26, 'Kaharole', 'কাহারোল', '', ''),
(404, 26, 'Khansama', 'খানসামা', '', ''),
(405, 26, 'Dinajpur Sadar', 'দিনাজপুর সদর', '', ''),
(406, 26, 'Nawabganj', 'নবাবগঞ্জ', '', ''),
(407, 26, 'Parbatipur', 'পার্বতীপুর', '', ''),
(408, 27, 'Fulchhari', 'ফুলছড়ি', '', ''),
(409, 27, 'Gaibandha sadar', 'গাইবান্ধা সদর', '', ''),
(410, 27, 'Gobindaganj', 'গোবিন্দগঞ্জ', '', ''),
(411, 27, 'Palashbari', 'পলাশবাড়ী', '', ''),
(412, 27, 'Sadullapur', 'সাদুল্যাপুর', '', ''),
(413, 27, 'Saghata', 'সাঘাটা', '', ''),
(414, 27, 'Sundarganj', 'সুন্দরগঞ্জ', '', ''),
(415, 28, 'Kurigram Sadar', 'কুড়িগ্রাম সদর', '', ''),
(416, 28, 'Nageshwari', 'নাগেশ্বরী', '', ''),
(417, 28, 'Bhurungamari', 'ভুরুঙ্গামারি', '', ''),
(418, 28, 'Phulbari', 'ফুলবাড়ি', '', ''),
(419, 28, 'Rajarhat', 'রাজারহাট', '', ''),
(420, 28, 'Ulipur', 'উলিপুর', '', ''),
(421, 28, 'Chilmari', 'চিলমারি', '', ''),
(422, 28, 'Rowmari', 'রউমারি', '', ''),
(423, 28, 'Char Rajibpur', 'চর রাজিবপুর', '', ''),
(424, 29, 'Lalmanirhat Sadar', 'লালমনিরহাট সদর', '', ''),
(425, 29, 'Aditmari', 'আদিতমারি', '', ''),
(426, 29, 'Kaliganj', 'কালীগঞ্জ', '', ''),
(427, 29, 'Hatibandha', 'হাতিবান্ধা', '', ''),
(428, 29, 'Patgram', 'পাটগ্রাম', '', ''),
(429, 30, 'Nilphamari Sadar', 'নীলফামারী সদর', '', ''),
(430, 30, 'Saidpur', 'সৈয়দপুর', '', ''),
(431, 30, 'Jaldhaka', 'জলঢাকা', '', ''),
(432, 30, 'Kishoreganj', 'কিশোরগঞ্জ', '', ''),
(433, 30, 'Domar', 'ডোমার', '', ''),
(434, 30, 'Dimla', 'ডিমলা', '', ''),
(435, 31, 'Panchagarh Sadar', 'পঞ্চগড় সদর', '', ''),
(436, 31, 'Debiganj', 'দেবীগঞ্জ', '', ''),
(437, 31, 'Boda', 'বোদা', '', ''),
(438, 31, 'Atwari', 'আটোয়ারি', '', ''),
(439, 31, 'Tetulia', 'তেতুলিয়া', '', ''),
(440, 32, 'Badarganj', 'বদরগঞ্জ', '', ''),
(441, 32, 'Mithapukur', 'মিঠাপুকুর', '', ''),
(442, 32, 'Gangachara', 'গঙ্গাচরা', '', ''),
(443, 32, 'Kaunia', 'কাউনিয়া', '', ''),
(444, 32, 'Rangpur Sadar', 'রংপুর সদর', '', ''),
(445, 32, 'Pirgachha', 'পীরগাছা', '', ''),
(446, 32, 'Pirganj', 'পীরগঞ্জ', '', ''),
(447, 32, 'Taraganj', 'তারাগঞ্জ', '', ''),
(448, 33, 'Thakurgaon Sadar', 'ঠাকুরগাঁও সদর', '', ''),
(449, 33, 'Pirganj', 'পীরগঞ্জ', '', ''),
(450, 33, 'Baliadangi', 'বালিয়াডাঙ্গি', '', ''),
(451, 33, 'Haripur', 'হরিপুর', '', ''),
(452, 33, 'Ranisankail', 'রাণীসংকইল', '', ''),
(453, 51, 'Ajmiriganj', 'আজমিরিগঞ্জ', '', ''),
(454, 51, 'Baniachang', 'বানিয়াচং', '', ''),
(455, 51, 'Bahubal', 'বাহুবল', '', ''),
(456, 51, 'Chunarughat', 'চুনারুঘাট', '', ''),
(457, 51, 'Habiganj Sadar', 'হবিগঞ্জ সদর', '', ''),
(458, 51, 'Lakhai', 'লাক্ষাই', '', ''),
(459, 51, 'Madhabpur', 'মাধবপুর', '', ''),
(460, 51, 'Nabiganj', 'নবীগঞ্জ', '', ''),
(461, 51, 'Shaistagonj', 'শায়েস্তাগঞ্জ', '', ''),
(462, 52, 'Moulvibazar Sadar', 'মৌলভীবাজার', '', ''),
(463, 52, 'Barlekha', 'বড়লেখা', '', ''),
(464, 52, 'Juri', 'জুড়ি', '', ''),
(465, 52, 'Kamalganj', 'কামালগঞ্জ', '', ''),
(466, 52, 'Kulaura', 'কুলাউরা', '', ''),
(467, 52, 'Rajnagar', 'রাজনগর', '', ''),
(468, 52, 'Sreemangal', 'শ্রীমঙ্গল', 'Srimangal,Srimongol,Srimangol', ''),
(469, 53, 'Bishwamvarpur', 'বিসশম্ভারপুর', '', ''),
(470, 53, 'Chhatak', 'ছাতক', 'Satak,Satok', ''),
(471, 53, 'Derai', 'দেড়াই', '', ''),
(472, 53, 'Dharampasha', 'ধরমপাশা', '', ''),
(473, 53, 'Dowarabazar', 'দোয়ারাবাজার', '', ''),
(474, 53, 'Jagannathpur', 'জগন্নাথপুর', '', ''),
(475, 53, 'Jamalganj', 'জামালগঞ্জ', '', ''),
(476, 53, 'Sulla', 'সুল্লা', '', ''),
(477, 53, 'Sunamganj Sadar', 'সুনামগঞ্জ সদর', '', ''),
(478, 53, 'Shanthiganj', 'শান্তিগঞ্জ', '', ''),
(479, 53, 'Tahirpur', 'তাহিরপুর', '', ''),
(480, 54, 'Sylhet Sadar', 'সিলেট সদর', '', ''),
(481, 54, 'Beanibazar', 'বেয়ানিবাজার', '', ''),
(482, 54, 'Bishwanath', 'বিশ্বনাথ', '', ''),
(483, 54, 'Dakshin Surma', 'দক্ষিণ সুরমা', '', ''),
(484, 54, 'Balaganj', 'বালাগঞ্জ', '', ''),
(485, 54, 'Companiganj', 'কোম্পানিগঞ্জ', '', ''),
(486, 54, 'Fenchuganj', 'ফেঞ্চুগঞ্জ', '', ''),
(487, 54, 'Golapganj', 'গোলাপগঞ্জ', '', ''),
(488, 54, 'Gowainghat', 'গোয়াইনঘাট', '', ''),
(489, 54, 'Jaintiapur', 'জয়ন্তপুর', '', ''),
(490, 54, 'Kanaighat', 'কানাইঘাট', '', ''),
(491, 54, 'Zakiganj', 'জাকিগঞ্জ', '', ''),
(492, 54, 'Nobigonj', 'নবীগঞ্জ', '', ''),
(493, 1, 'Mohammadpur', 'মোহাম্মাদপুর', '', ''),
(496, 1, 'Adabor', 'আদাবর', '', ''),
(497, 1, 'Badda', 'বাড্ডা', '', ''),
(499, 1, 'Bongsal', 'বংশাল', '', ''),
(500, 1, 'Bimanbandar', 'বিমানবন্দর', '', ''),
(501, 1, 'Cantonment', 'ক্যান্টনমেন্ট', '', ''),
(502, 1, 'Chak Bazar', 'চকবাজার', '', ''),
(503, 1, 'Dakshinkhan', 'দক্ষিনখান', '', ''),
(504, 1, 'Darus Salam', 'দারস সালাম', '', ''),
(506, 1, 'Demra ', 'ডেমরা', '', ''),
(507, 1, 'Dhanmondi', 'ধানমন্ডি', '', ''),
(508, 1, 'Gendaria', 'গেন্ডারিয়া', '', ''),
(509, 1, 'Gulshan', 'গুলশান', '', ''),
(510, 1, 'Hazaribagh', 'হাজারীবাগ', '', ''),
(511, 1, 'Jatrabari', 'যাত্রাবাড়ি', '', ''),
(512, 1, 'Kadamtali', 'কদমতলী', 'Kodomtoli,Kadomtoli,Kodamtoli', ''),
(513, 1, 'Kafrul', 'কাফরুল', 'Kafrool', ''),
(514, 1, 'Kalabagan', 'কলাবাগান', 'Kolabagan', ''),
(515, 1, 'Kamrangirchar', 'কামরাঙ্গীরচর', 'Kamrangirchor', ''),
(516, 1, 'Khilgaon', 'খিলগাও', '', ''),
(517, 1, 'khilkhet', 'খিলক্ষেত', '', ''),
(518, 1, 'Kotwali', 'কোতয়ালী', 'Kotoali,Kotowali', ''),
(519, 1, 'Lalbagh', 'লালবাগ', 'Lalbag', ''),
(520, 1, 'Mirpur', 'মিরপুর', '', ''),
(521, 1, 'Motijheel', 'মতিঝিল', 'Matijhil', ''),
(522, 1, 'Nawabganj', 'নবাবগন্জ', 'Nababganj,Nobabganj,Nababgonj', ''),
(523, 1, 'Newmarket', 'নিউমার্কেট', '', ''),
(524, 1, 'Pallabi', 'পল্লবী', 'Pollobi', ''),
(525, 1, 'Paltan', 'পল্টন', 'Polton', ''),
(526, 1, 'Ramna', 'রমনা', 'Romna', ''),
(527, 1, 'Rampura', 'রামপুরা', '', ''),
(528, 1, 'Sabujbagh', 'সবুজবাগ', '', ''),
(529, 1, 'Shah Ali', 'শাহআলী', '', ''),
(530, 1, 'Shahbag', 'শাহবাগ', '', ''),
(531, 1, 'Sher-e-Bangla Nagar', 'শের-ই-বাংলা', '', ''),
(532, 1, 'Shyampur', 'শ্যামপুর', '', ''),
(533, 1, 'Tejgaon', 'তেজগাও', '', ''),
(534, 1, 'Mohakhali', 'মহাখালি', '', ''),
(535, 1, 'Tejgaon Industrial Area', 'তেজগাও শিল্প এলাকা', '', ''),
(536, 1, 'Turag', 'তুরাগ', '', ''),
(537, 1, 'Uttara', 'উত্তরা', '', ''),
(538, 1, 'Uttar Khan', 'উত্তরখান', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `mobile` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `reg_date` datetime NOT NULL,
  `last_logged` datetime NOT NULL,
  `user_type` enum('admin','manager','supervisor','user') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'user',
  `reputation` int(11) NOT NULL,
  `avatar` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `mobile`, `reg_date`, `last_logged`, `user_type`, `reputation`, `avatar`, `status`) VALUES
(1, 'রেজওয়ান', '81dc9bdb52d04dc20036dbd8313ed055', 'rejoan.er@gmail.com', '', '2015-12-03 10:07:24', '0000-00-00 00:00:00', 'user', 0, '', 1),
(2, 'rejoan', '81dc9bdb52d04dc20036dbd8313ed055', 'rejoan.epr@gmail.com', '01961349181', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'admin', 0, '', 1),
(4, 'anonymus', '81dc9bdb52d04dc20036dbd8313ed055', 'anonymus@gmail.com', '01961349181', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'user', 0, '', 1),
(6, '', '', 'refatju@yahoo.com', '', '2016-12-31 12:51:48', '0000-00-00 00:00:00', 'user', 0, '', 1),
(7, 'mirza', '81dc9bdb52d04dc20036dbd8313ed055', 'mirza@yahoo.com', '01961349181', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'user', 0, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `verifications`
--

CREATE TABLE `verifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `route_id` bigint(20) UNSIGNED NOT NULL,
  `verified_by` bigint(20) UNSIGNED NOT NULL,
  `verified_at` datetime NOT NULL,
  `comments` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `districts`
--
ALTER TABLE `districts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `drivers`
--
ALTER TABLE `drivers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `edited_routes`
--
ALTER TABLE `edited_routes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_edited_routes_routes` (`route_id`),
  ADD KEY `FK_edited_routes_users` (`added_by`),
  ADD KEY `FK_edited_routes_poribohons` (`poribohon_id`),
  ADD KEY `FK_edited_routes_districts` (`from_district`),
  ADD KEY `FK_edited_routes_thanas` (`from_thana`),
  ADD KEY `FK_edited_routes_districts_2` (`to_district`),
  ADD KEY `FK_edited_routes_thanas_2` (`to_thana`);

--
-- Indexes for table `edited_stoppages`
--
ALTER TABLE `edited_stoppages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK__routes` (`route_id`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `poribohons`
--
ALTER TABLE `poribohons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `bn_name` (`bn_name`),
  ADD KEY `FK_poribohons_users` (`added_by`);

--
-- Indexes for table `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_profiles_users` (`user_id`);

--
-- Indexes for table `routes`
--
ALTER TABLE `routes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_routes_users` (`added_by`),
  ADD KEY `from_place` (`from_place`),
  ADD KEY `to_place` (`to_place`),
  ADD KEY `FK_routes_districts` (`from_district`),
  ADD KEY `FK_routes_thanas` (`from_thana`),
  ADD KEY `FK_routes_districts_2` (`to_district`),
  ADD KEY `FK_routes_thanas_2` (`to_thana`),
  ADD KEY `FK_routes_poribohons` (`poribohon_id`);

--
-- Indexes for table `route_bn`
--
ALTER TABLE `route_bn`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_route_translation_routes` (`route_id`);

--
-- Indexes for table `stoppages`
--
ALTER TABLE `stoppages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_stopages_routes` (`route_id`);

--
-- Indexes for table `stoppage_bn`
--
ALTER TABLE `stoppage_bn`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK__stoppages` (`route_id`);

--
-- Indexes for table `thanas`
--
ALTER TABLE `thanas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `district_id` (`district_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `type` (`user_type`);

--
-- Indexes for table `verifications`
--
ALTER TABLE `verifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_verifications_routes` (`route_id`),
  ADD KEY `FK_verifications_users` (`verified_by`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `districts`
--
ALTER TABLE `districts`
  MODIFY `id` int(2) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;
--
-- AUTO_INCREMENT for table `drivers`
--
ALTER TABLE `drivers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `edited_routes`
--
ALTER TABLE `edited_routes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `edited_stoppages`
--
ALTER TABLE `edited_stoppages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `poribohons`
--
ALTER TABLE `poribohons`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `routes`
--
ALTER TABLE `routes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `route_bn`
--
ALTER TABLE `route_bn`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `stoppages`
--
ALTER TABLE `stoppages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=207;
--
-- AUTO_INCREMENT for table `stoppage_bn`
--
ALTER TABLE `stoppage_bn`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;
--
-- AUTO_INCREMENT for table `thanas`
--
ALTER TABLE `thanas`
  MODIFY `id` int(2) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=539;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `verifications`
--
ALTER TABLE `verifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `edited_routes`
--
ALTER TABLE `edited_routes`
  ADD CONSTRAINT `FK_edited_routes_districts` FOREIGN KEY (`from_district`) REFERENCES `districts` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_edited_routes_districts_2` FOREIGN KEY (`to_district`) REFERENCES `districts` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_edited_routes_poribohons` FOREIGN KEY (`poribohon_id`) REFERENCES `poribohons` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_edited_routes_routes` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_edited_routes_thanas` FOREIGN KEY (`from_thana`) REFERENCES `thanas` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_edited_routes_thanas_2` FOREIGN KEY (`to_thana`) REFERENCES `thanas` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_edited_routes_users` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `edited_stoppages`
--
ALTER TABLE `edited_stoppages`
  ADD CONSTRAINT `FK_edited_stoppages_edited_routes` FOREIGN KEY (`route_id`) REFERENCES `edited_routes` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `poribohons`
--
ALTER TABLE `poribohons`
  ADD CONSTRAINT `FK_poribohons_users` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `profiles`
--
ALTER TABLE `profiles`
  ADD CONSTRAINT `FK_profiles_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `routes`
--
ALTER TABLE `routes`
  ADD CONSTRAINT `FK_routes_districts` FOREIGN KEY (`from_district`) REFERENCES `districts` (`id`) ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_routes_districts_2` FOREIGN KEY (`to_district`) REFERENCES `districts` (`id`) ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_routes_poribohons` FOREIGN KEY (`poribohon_id`) REFERENCES `poribohons` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_routes_thanas` FOREIGN KEY (`from_thana`) REFERENCES `thanas` (`id`) ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_routes_thanas_2` FOREIGN KEY (`to_thana`) REFERENCES `thanas` (`id`) ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_routes_users` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`) ON UPDATE NO ACTION;

--
-- Constraints for table `route_bn`
--
ALTER TABLE `route_bn`
  ADD CONSTRAINT `FK_route_translation_routes` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `stoppages`
--
ALTER TABLE `stoppages`
  ADD CONSTRAINT `FK_stoppages_routes` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `stoppage_bn`
--
ALTER TABLE `stoppage_bn`
  ADD CONSTRAINT `FK__stoppages` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `thanas`
--
ALTER TABLE `thanas`
  ADD CONSTRAINT `thanas_ibfk_1` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `verifications`
--
ALTER TABLE `verifications`
  ADD CONSTRAINT `FK_verifications_routes` FOREIGN KEY (`route_id`) REFERENCES `routes` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `FK_verifications_users` FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
