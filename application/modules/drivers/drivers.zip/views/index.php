<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<div class="col-xs-12 col-md-6">
    <div class="box box-poth">
        <div class="box-header with-border">
            <p></p>
        </div>
        <div class="box-body">
            Driver Search and Requirement System in Progress
            <?php foreach ($drivers as $n): ?>
                <div class="row custom_margin">
                    
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
